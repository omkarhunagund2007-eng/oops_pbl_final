package com.gmu.smartcampus.dto;

import java.util.Map;

public class DashboardStatsDTO {
    private long totalStudents;
    private long approvedStudents;
    private long pendingRequests;
    private long totalFaculty;
    private long totalCourses;
    private long totalClassrooms;
    private long totalLaboratories;
    private long totalEquipmentItems;
    private long upcomingActivities;
    private long activeBookings;
    private Map<String, Long> studentsByDepartment;
    private Map<String, Long> bookingsByStatus;

    public long getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(long totalStudents) {
        this.totalStudents = totalStudents;
    }

    public long getApprovedStudents() {
        return approvedStudents;
    }

    public void setApprovedStudents(long approvedStudents) {
        this.approvedStudents = approvedStudents;
    }

    public long getPendingRequests() {
        return pendingRequests;
    }

    public void setPendingRequests(long pendingRequests) {
        this.pendingRequests = pendingRequests;
    }

    public long getTotalFaculty() {
        return totalFaculty;
    }

    public void setTotalFaculty(long totalFaculty) {
        this.totalFaculty = totalFaculty;
    }

    public long getTotalCourses() {
        return totalCourses;
    }

    public void setTotalCourses(long totalCourses) {
        this.totalCourses = totalCourses;
    }

    public long getTotalClassrooms() {
        return totalClassrooms;
    }

    public void setTotalClassrooms(long totalClassrooms) {
        this.totalClassrooms = totalClassrooms;
    }

    public long getTotalLaboratories() {
        return totalLaboratories;
    }

    public void setTotalLaboratories(long totalLaboratories) {
        this.totalLaboratories = totalLaboratories;
    }

    public long getTotalEquipmentItems() {
        return totalEquipmentItems;
    }

    public void setTotalEquipmentItems(long totalEquipmentItems) {
        this.totalEquipmentItems = totalEquipmentItems;
    }

    public long getUpcomingActivities() {
        return upcomingActivities;
    }

    public void setUpcomingActivities(long upcomingActivities) {
        this.upcomingActivities = upcomingActivities;
    }

    public long getActiveBookings() {
        return activeBookings;
    }

    public void setActiveBookings(long activeBookings) {
        this.activeBookings = activeBookings;
    }

    public Map<String, Long> getStudentsByDepartment() {
        return studentsByDepartment;
    }

    public void setStudentsByDepartment(Map<String, Long> studentsByDepartment) {
        this.studentsByDepartment = studentsByDepartment;
    }

    public Map<String, Long> getBookingsByStatus() {
        return bookingsByStatus;
    }

    public void setBookingsByStatus(Map<String, Long> bookingsByStatus) {
        this.bookingsByStatus = bookingsByStatus;
    }
}
