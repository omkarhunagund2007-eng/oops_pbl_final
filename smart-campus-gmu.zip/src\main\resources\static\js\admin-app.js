(function () {
  const csrfToken = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
  const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content') || 'X-XSRF-TOKEN';

  let currentSection = 'overview';
  let currentRows = [];
  let currentPage = 1;
  const pageSize = 8;
  let deptChart = null;
  let bookingChart = null;

  const crudModalEl = document.getElementById('crudModal');
  const crudModal = crudModalEl ? new bootstrap.Modal(crudModalEl) : null;
  const confirmModalEl = document.getElementById('confirmModal');
  const confirmModal = confirmModalEl ? new bootstrap.Modal(confirmModalEl) : null;

  // Theme initialization
  function applyTheme(theme) {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('gmu-theme', theme);
    const btn = document.getElementById('theme-toggle-btn');
    if (btn) btn.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
  }
  applyTheme(localStorage.getItem('gmu-theme') || 'light');

  async function toggleTheme() {
    const next = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    applyTheme(next);
    await api('/api/user/theme', 'POST', { theme: next }).catch(() => {});
  }
  document.getElementById('theme-toggle-btn')?.addEventListener('click', toggleTheme);
  document.getElementById('settings-theme-btn')?.addEventListener('click', toggleTheme);

  document.getElementById('mobile-sidebar-btn')?.addEventListener('click', () => {
    document.getElementById('admin-sidebar')?.classList.toggle('open');
  });

  function showToast(msg, isError = false) {
    const stack = document.getElementById('toast-stack');
    if (!stack) return;
    const el = document.createElement('div');
    el.className = 'gmu-toast';
    if (isError) el.style.borderColor = '#EF4444';
    el.textContent = msg;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  async function api(url, method = 'GET', body = null) {
    const headers = {};
    if (body !== null) headers['Content-Type'] = 'application/json';
    if (csrfToken && method !== 'GET') headers[csrfHeader] = csrfToken;

    const res = await fetch(url, {
      method,
      headers,
      body: body !== null ? JSON.stringify(body) : undefined
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Operation failed');
    }
    return json.data;
  }

  function askConfirm(message, withReasonInput = false) {
    return new Promise((resolve) => {
      document.getElementById('confirm-message').textContent = message;
      const reasonInput = document.getElementById('confirm-reason-input');
      reasonInput.value = '';
      reasonInput.classList.toggle('d-none', !withReasonInput);

      const proceedBtn = document.getElementById('confirm-proceed-btn');
      const onProceed = () => {
        proceedBtn.removeEventListener('click', onProceed);
        confirmModal.hide();
        resolve({ confirmed: true, reason: reasonInput.value });
      };
      proceedBtn.addEventListener('click', onProceed, { once: true });
      confirmModalEl.addEventListener('hidden.bs.modal', () => {
        proceedBtn.removeEventListener('click', onProceed);
        resolve({ confirmed: false });
      }, { once: true });

      confirmModal.show();
    });
  }

  function animateCount(el, target) {
    if (!el) return;
    const goal = Number(target) || 0;
    const start = performance.now();
    const duration = 520;
    function step(now) {
      const p = Math.min(1, (now - start) / duration);
      el.textContent = Math.round(goal * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  async function loadOverview() {
    const stats = await api('/api/admin/stats');
    animateCount(document.getElementById('kpi-total-students'), stats.totalStudents);
    animateCount(document.getElementById('kpi-approved-students'), stats.approvedStudents);
    animateCount(document.getElementById('kpi-pending-requests'), stats.pendingRequests);
    document.getElementById('pending-nav-count').textContent = stats.pendingRequests;
    animateCount(document.getElementById('kpi-faculty'), stats.totalFaculty);
    animateCount(document.getElementById('kpi-courses'), stats.totalCourses);
    animateCount(document.getElementById('kpi-classrooms'), stats.totalClassrooms);
    animateCount(document.getElementById('kpi-labs'), stats.totalLaboratories);
    animateCount(document.getElementById('kpi-equipment'), stats.totalEquipmentItems);
    animateCount(document.getElementById('kpi-events'), stats.upcomingActivities);
    animateCount(document.getElementById('kpi-bookings'), stats.activeBookings);

    const deptCtx = document.getElementById('deptChart');
    if (deptCtx && window.Chart) {
      deptChart?.destroy();
      deptChart = new Chart(deptCtx, {
        type: 'bar',
        data: {
          labels: Object.keys(stats.studentsByDepartment || {}),
          datasets: [{
            label: 'Students',
            data: Object.values(stats.studentsByDepartment || {}),
            backgroundColor: '#0B1D3A',
            borderColor: '#C89B3C',
            borderWidth: 1,
            borderRadius: 6
          }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
      });
    }

    const bkCtx = document.getElementById('bookingChart');
    if (bkCtx && window.Chart) {
      bookingChart?.destroy();
      bookingChart = new Chart(bkCtx, {
        type: 'doughnut',
        data: {
          labels: Object.keys(stats.bookingsByStatus || {}),
          datasets: [{
            data: Object.values(stats.bookingsByStatus || {}),
            backgroundColor: ['#15803D', '#C89B3C', '#B91C1C', '#64748B']
          }]
        }
      });
    }

    const pending = await api('/api/admin/students?status=PENDING');
    const container = document.getElementById('overview-pending-list');
    container.innerHTML = pending.length
      ? pending.slice(0, 5).map(s =>
          `<div class="d-flex justify-content-between align-items-center py-2 border-bottom">
             <div><strong>${escHtml(s.name)}</strong> <span class="text-muted">(${escHtml(s.studentId)})</span><div class="text-muted">${escHtml(s.departmentCode)} · Sem ${s.semester}</div></div>
             <button class="btn btn-sm btn-gmu-primary" onclick="window.__approveStudent(${s.id})">Approve</button>
           </div>`).join('')
      : '<div class="text-muted py-3">No pending student registration requests.</div>';
  }

  function escHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  window.__approveStudent = async (id) => {
    try {
      await api(`/api/admin/approvals/students/${id}/approve`, 'POST', {});
      showToast('Student registration approved.');
      switchSection(currentSection);
    } catch (e) { showToast(e.message, true); }
  };

  window.__rejectStudent = async (id) => {
    const res = await askConfirm('Provide an optional rejection reason:', true);
    if (!res.confirmed) return;
    try {
      await api(`/api/admin/approvals/students/${id}/reject`, 'POST', { reason: res.reason });
      showToast('Student registration rejected.');
      switchSection(currentSection);
    } catch (e) { showToast(e.message, true); }
  };

  window.__reviewBooking = async (id, approve) => {
    const res = approve ? { confirmed: true, reason: 'Approved' } : await askConfirm('Reject this booking?', true);
    if (!res.confirmed) return;
    try {
      await api(`/api/admin/bookings/${id}/${approve ? 'approve' : 'reject'}`, 'POST', { reason: res.reason });
      showToast(`Booking ${approve ? 'approved' : 'rejected'}.`);
      switchSection(currentSection);
    } catch (e) { showToast(e.message, true); }
  };

  window.__deleteRecord = async (endpoint, label) => {
    const res = await askConfirm(`Delete ${label}? This action cannot be undone.`);
    if (!res.confirmed) return;
    try {
      await api(endpoint, 'DELETE');
      showToast(`${label} deleted.`);
      switchSection(currentSection);
    } catch (e) { showToast(e.message, true); }
  };

  const sectionConfig = {
    students: {
      title: 'Student Management',
      endpoint: '/api/admin/students',
      headers: ['Student ID', 'Name', 'Dept / Branch', 'Sem · Sec', 'Phone', 'Status', 'Actions'],
      rowHtml: s => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(s.studentId)}</td>
        <td>${escHtml(s.name)}</td>
        <td>${escHtml(s.departmentCode)} · ${escHtml(s.branch)}</td>
        <td class="tabular-nums">Sem ${s.semester} · ${escHtml(s.section)}</td>
        <td class="tabular-nums">${escHtml(s.phone)}</td>
        <td><span class="status-label status-${s.accountStatus.toLowerCase()}">${escHtml(s.accountStatus)}</span></td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/students/${s.id}','Student ${escHtml(s.studentId)}')">Delete</button></td>
      </tr>`
    },
    approvals: {
      title: 'Pending Student Registration Approvals',
      endpoint: '/api/admin/students?status=PENDING',
      headers: ['Student ID', 'Applicant Name', 'Username', 'Department', 'Sem · Year', 'Phone', 'Decision'],
      rowHtml: s => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(s.studentId)}</td>
        <td>${escHtml(s.name)}</td>
        <td>${escHtml(s.username)}</td>
        <td>${escHtml(s.departmentCode)}</td>
        <td class="tabular-nums">Sem ${s.semester} · ${s.admissionYear}</td>
        <td class="tabular-nums">${escHtml(s.phone)}</td>
        <td class="d-flex gap-1">
          <button class="btn btn-sm btn-gmu-primary" onclick="window.__approveStudent(${s.id})">Approve</button>
          <button class="btn btn-sm btn-outline-danger" onclick="window.__rejectStudent(${s.id})">Reject</button>
        </td>
      </tr>`
    },
    faculty: {
      title: 'Faculty Management',
      endpoint: '/api/admin/faculty',
      addLabel: '+ Add Faculty',
      headers: ['Faculty ID', 'Name', 'Department', 'Designation', 'Email', 'Specialization', 'Actions'],
      rowHtml: f => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(f.facultyId)}</td>
        <td>${escHtml(f.name)}</td>
        <td>${escHtml(f.departmentCode)}</td>
        <td>${escHtml(f.designation)}</td>
        <td>${escHtml(f.email)}</td>
        <td>${escHtml(f.specialization)}</td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/faculty/${f.id}','Faculty')">Delete</button></td>
      </tr>`
    },
    courses: {
      title: 'Course Management',
      endpoint: '/api/admin/courses',
      addLabel: '+ Add Course',
      headers: ['Code', 'Course Title', 'Dept', 'Sem', 'Credits', 'Assigned Faculty', 'Actions'],
      rowHtml: c => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(c.courseCode)}</td>
        <td>${escHtml(c.courseName)}</td>
        <td>${escHtml(c.departmentCode)}</td>
        <td class="tabular-nums">${c.semester}</td>
        <td class="tabular-nums">${c.credits}</td>
        <td>${escHtml(c.assignedFacultyName || 'Unassigned')}</td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/courses/${c.id}','Course')">Delete</button></td>
      </tr>`
    },
    classrooms: {
      title: 'Classroom Management',
      endpoint: '/api/admin/classrooms',
      addLabel: '+ Add Classroom',
      headers: ['Room ID', 'Building', 'Room #', 'Capacity', 'Equipment', 'Availability', 'Actions'],
      rowHtml: r => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(r.roomId)}</td>
        <td>${escHtml(r.building)}</td>
        <td class="tabular-nums">${escHtml(r.roomNumber)}</td>
        <td class="tabular-nums">${r.capacity}</td>
        <td>${escHtml(r.equipmentSummary)}</td>
        <td><span class="status-label status-${r.availabilityStatus.toLowerCase()}">${escHtml(r.availabilityStatus)}</span></td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/classrooms/${r.id}','Classroom')">Delete</button></td>
      </tr>`
    },
    laboratories: {
      title: 'Laboratory Management',
      endpoint: '/api/admin/laboratories',
      addLabel: '+ Add Laboratory',
      headers: ['Lab ID', 'Name', 'Location', 'Type', 'Capacity', 'Availability', 'Actions'],
      rowHtml: l => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(l.labId)}</td>
        <td>${escHtml(l.name)}</td>
        <td>${escHtml(l.location)}</td>
        <td>${escHtml(l.labType)}</td>
        <td class="tabular-nums">${l.capacity}</td>
        <td><span class="status-label status-${l.availabilityStatus.toLowerCase()}">${escHtml(l.availabilityStatus)}</span></td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/laboratories/${l.id}','Laboratory')">Delete</button></td>
      </tr>`
    },
    equipment: {
      title: 'Equipment Management',
      endpoint: '/api/admin/equipment',
      addLabel: '+ Add Equipment',
      headers: ['Equip ID', 'Name', 'Category', 'Available / Total', 'Condition', 'Location', 'Actions'],
      rowHtml: eq => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(eq.equipmentId)}</td>
        <td>${escHtml(eq.name)}</td>
        <td>${escHtml(eq.category)}</td>
        <td class="tabular-nums">${eq.availableQuantity} / ${eq.quantity}</td>
        <td>${escHtml(eq.itemCondition)}</td>
        <td>${escHtml(eq.location)}</td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/equipment/${eq.id}','Equipment')">Delete</button></td>
      </tr>`
    },
    activities: {
      title: 'Campus Activity Management',
      endpoint: '/api/admin/events',
      addLabel: '+ Publish Event',
      headers: ['Title', 'Category', 'Date', 'Location', 'Registrations', 'Status', 'Actions'],
      rowHtml: ev => `<tr>
        <td class="fw-semibold">${escHtml(ev.title)}</td>
        <td>${escHtml(ev.category)}</td>
        <td class="tabular-nums">${escHtml(ev.eventDate)}</td>
        <td>${escHtml(ev.location)}</td>
        <td class="tabular-nums">${ev.registeredCount} / ${ev.capacity}</td>
        <td><span class="status-label status-${ev.status.toLowerCase()}">${escHtml(ev.status)}</span></td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="window.__deleteRecord('/api/admin/events/${ev.id}','Event')">Delete</button></td>
      </tr>`
    },
    bookings: {
      title: 'Resource Booking Management',
      endpoint: '/api/admin/bookings',
      headers: ['Code', 'Resource', 'Requester', 'Date & Slot', 'Purpose', 'Status', 'Actions'],
      rowHtml: b => `<tr>
        <td class="tabular-nums fw-semibold">${escHtml(b.bookingCode)}</td>
        <td>${escHtml(b.resourceType)} · ${escHtml(b.resourceName)}</td>
        <td>${escHtml(b.requesterName)}</td>
        <td class="tabular-nums">${escHtml(b.bookingDate)} (${escHtml(b.startTime)}-${escHtml(b.endTime)})</td>
        <td>${escHtml(b.purpose)}</td>
        <td><span class="status-label status-${b.status.toLowerCase()}">${escHtml(b.status)}</span></td>
        <td class="d-flex gap-1">
          ${b.status === 'PENDING' ? `<button class="btn btn-sm btn-gmu-primary" onclick="window.__reviewBooking(${b.id}, true)">Approve</button>
          <button class="btn btn-sm btn-outline-danger" onclick="window.__reviewBooking(${b.id}, false)">Reject</button>` : ''}
        </td>
      </tr>`
    }
  };

  function renderTable() {
    const cfg = sectionConfig[currentSection];
    if (!cfg) return;
    const term = (document.getElementById('dynamic-search').value || '').toLowerCase();
    const filtered = currentRows.filter(r => JSON.stringify(r).toLowerCase().includes(term));
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    currentPage = Math.min(currentPage, totalPages);
    const slice = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    document.getElementById('dynamic-thead').innerHTML = `<tr>${cfg.headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
    document.getElementById('dynamic-tbody').innerHTML = slice.length
      ? slice.map(cfg.rowHtml).join('')
      : `<tr><td colspan="${cfg.headers.length}" class="text-center text-muted py-4">No matching records found.</td></tr>`;
    document.getElementById('dynamic-count').textContent = `${filtered.length} records`;
    document.getElementById('page-indicator').textContent = `${currentPage} / ${totalPages}`;
  }

  document.getElementById('dynamic-search')?.addEventListener('input', () => { currentPage = 1; renderTable(); });
  document.getElementById('prev-page-btn')?.addEventListener('click', () => { if (currentPage > 1) { currentPage--; renderTable(); } });
  document.getElementById('next-page-btn')?.addEventListener('click', () => { currentPage++; renderTable(); });

  function openAddModal(section) {
    const form = document.getElementById('crud-modal-form');
    const body = document.getElementById('crud-modal-body');
    const deptOpts = (window.GMU_DEPARTMENTS || []).map(d => `<option value="${d.id}">${d.code} - ${d.name}</option>`).join('');

    const templates = {
      faculty: `
        <div class="col-6"><label class="form-label small">Faculty ID</label><input name="facultyId" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Name</label><input name="name" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Department</label><select name="departmentId" class="form-select form-select-sm">${deptOpts}</select></div>
        <div class="col-6"><label class="form-label small">Designation</label><input name="designation" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Email</label><input name="email" type="email" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Phone</label><input name="phone" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Specialization</label><input name="specialization" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Joining Date</label><input name="joiningDate" type="date" class="form-control form-control-sm" required /></div>`,
      courses: `
        <div class="col-4"><label class="form-label small">Course Code</label><input name="courseCode" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Course Name</label><input name="courseName" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Department</label><select name="departmentId" class="form-select form-select-sm">${deptOpts}</select></div>
        <div class="col-3"><label class="form-label small">Semester</label><input name="semester" type="number" value="3" class="form-control form-control-sm" required /></div>
        <div class="col-3"><label class="form-label small">Credits</label><input name="credits" type="number" value="4" class="form-control form-control-sm" required /></div>
        <div class="col-12"><label class="form-label small">Description</label><textarea name="description" class="form-control form-control-sm" rows="2"></textarea></div>`,
      classrooms: `
        <div class="col-4"><label class="form-label small">Room ID</label><input name="roomId" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Building</label><input name="building" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Room Number</label><input name="roomNumber" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Capacity</label><input name="capacity" type="number" value="60" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Availability</label><select name="availabilityStatus" class="form-select form-select-sm"><option>AVAILABLE</option><option>MAINTENANCE</option></select></div>
        <div class="col-12"><label class="form-label small">Equipment</label><input name="equipmentSummary" class="form-control form-control-sm" required /></div>`,
      laboratories: `
        <div class="col-4"><label class="form-label small">Lab ID</label><input name="labId" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Lab Name</label><input name="name" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Location</label><input name="location" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Type</label><input name="labType" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Capacity</label><input name="capacity" type="number" value="35" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Availability</label><select name="availabilityStatus" class="form-select form-select-sm"><option>AVAILABLE</option><option>MAINTENANCE</option></select></div>
        <div class="col-12"><label class="form-label small">Equipment</label><input name="equipmentSummary" class="form-control form-control-sm" required /></div>`,
      equipment: `
        <div class="col-4"><label class="form-label small">Equipment ID</label><input name="equipmentId" class="form-control form-control-sm" required /></div>
        <div class="col-8"><label class="form-label small">Name</label><input name="name" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Category</label><input name="category" class="form-control form-control-sm" required /></div>
        <div class="col-3"><label class="form-label small">Quantity</label><input name="quantity" type="number" value="5" class="form-control form-control-sm" required /></div>
        <div class="col-3"><label class="form-label small">Available</label><input name="availableQuantity" type="number" value="5" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Condition</label><select name="itemCondition" class="form-select form-select-sm"><option>GOOD</option><option>EXCELLENT</option><option>FAIR</option></select></div>
        <div class="col-4"><label class="form-label small">Location</label><input name="location" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Purchase Date</label><input name="purchaseDate" type="date" class="form-control form-control-sm" required /></div>`,
      activities: `
        <div class="col-8"><label class="form-label small">Event Title</label><input name="title" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Category</label><input name="category" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Date</label><input name="eventDate" type="date" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">Start Time</label><input name="startTime" type="time" value="10:00" class="form-control form-control-sm" required /></div>
        <div class="col-4"><label class="form-label small">End Time</label><input name="endTime" type="time" value="16:00" class="form-control form-control-sm" required /></div>
        <div class="col-6"><label class="form-label small">Location</label><input name="location" class="form-control form-control-sm" required /></div>
        <div class="col-3"><label class="form-label small">Capacity</label><input name="capacity" type="number" value="100" class="form-control form-control-sm" required /></div>
        <div class="col-3"><label class="form-label small">Status</label><select name="status" class="form-select form-select-sm"><option>PUBLISHED</option><option>DRAFT</option></select></div>
        <div class="col-12"><label class="form-label small">Description</label><textarea name="description" class="form-control form-control-sm" rows="2" required></textarea></div>`
    };

    document.getElementById('crud-modal-title').textContent = sectionConfig[section].addLabel;
    body.innerHTML = templates[section] || '';
    form.onsubmit = async (e) => {
      e.preventDefault();
      const raw = Object.fromEntries(new FormData(form).entries());
      ['departmentId', 'semester', 'credits', 'capacity', 'quantity', 'availableQuantity'].forEach(k => {
        if (raw[k] !== undefined) raw[k] = Number(raw[k]);
      });
      try {
        await api(sectionConfig[section].endpoint, 'POST', raw);
        crudModal.hide();
        showToast('Record created successfully.');
        switchSection(section);
      } catch (err) {
        showToast(err.message, true);
      }
    };
    crudModal.show();
  }

  async function switchSection(section) {
    currentSection = section;
    currentPage = 1;
    document.querySelectorAll('.campus-nav-btn[data-section]').forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-section') === section);
    });
    document.querySelectorAll('.admin-section').forEach(s => s.classList.add('d-none'));

    if (section === 'overview') {
      document.getElementById('topbar-title').textContent = 'Dashboard Overview';
      document.getElementById('sec-overview').classList.remove('d-none');
      await loadOverview();
    } else if (section === 'reports') {
      document.getElementById('topbar-title').textContent = 'Analytics & CSV Reports';
      document.getElementById('sec-reports').classList.remove('d-none');
    } else if (section === 'settings') {
      document.getElementById('topbar-title').textContent = 'System Settings & Announcements';
      document.getElementById('sec-settings').classList.remove('d-none');
    } else {
      const cfg = sectionConfig[section];
      document.getElementById('topbar-title').textContent = cfg.title;
      document.getElementById('sec-dynamic').classList.remove('d-none');
      const raceBox = document.getElementById('booking-race-box');
      if (raceBox) raceBox.classList.toggle('d-none', section !== 'bookings');
      const addBtn = document.getElementById('dynamic-add-btn');
      if (cfg.addLabel) {
        addBtn.classList.remove('d-none');
        addBtn.textContent = cfg.addLabel;
        addBtn.onclick = () => openAddModal(section);
      } else {
        addBtn.classList.add('d-none');
      }
      document.getElementById('dynamic-tbody').innerHTML = '<tr><td colspan="7"><div class="skeleton-row"></div><div class="skeleton-row"></div></td></tr>';
      currentRows = await api(cfg.endpoint);
      renderTable();
    }
  }

  document.getElementById('run-race-sim-btn')?.addEventListener('click', async () => {
    const out = document.getElementById('race-sim-results');
    const btn = document.getElementById('run-race-sim-btn');
    if (btn) btn.disabled = true;
    try {
      const res = await api('/api/admin/bookings/simulate-race', 'POST', { resourceType: 'LABORATORY', resourceId: 1 });
      if (out) {
        out.classList.remove('d-none');
        out.innerHTML = res.traces.map(t => `
          <div class="col-md-4 col-lg">
            <div class="p-2 rounded border ${t.outcome === 'BOOKED' ? 'border-success bg-dark text-success' : 'border-danger bg-dark text-danger'} small">
              <div class="fw-bold d-flex justify-content-between"><span>${escHtml(t.thread)}</span><span class="tabular-nums">${t.durationMs}ms</span></div>
              <div class="fw-semibold">${t.outcome === 'BOOKED' ? 'WON (' + escHtml(t.bookingCode) + ')' : 'BLOCKED (409)'}</div>
              <div style="font-size:0.72rem;" class="text-light opacity-75">${escHtml(t.detail)}</div>
            </div>
          </div>`).join('');
      }
      showToast(`Race finished: ${res.bookedCount} booked, ${res.conflictCount} conflicts blocked.`);
      switchSection('bookings');
    } catch (e) {
      showToast(e.message, true);
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.querySelectorAll('.campus-nav-btn[data-section]').forEach(btn => {
    btn.addEventListener('click', () => switchSection(btn.getAttribute('data-section')));
  });
  document.querySelectorAll('[data-jump]').forEach(btn => {
    btn.addEventListener('click', () => switchSection(btn.getAttribute('data-jump')));
  });

  document.getElementById('announcement-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const raw = Object.fromEntries(new FormData(e.target).entries());
    try {
      await api('/api/admin/announcements', 'POST', raw);
      e.target.reset();
      showToast('Announcement published.');
    } catch (err) { showToast(err.message, true); }
  });

  switchSection('overview');
})();
