package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.CampusEvent;
import com.gmu.smartcampus.model.EventRegistration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class EventRepository {

    private final JdbcTemplate jdbcTemplate;

    public EventRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<CampusEvent> eventMapper = (rs, rowNum) -> {
        CampusEvent e = new CampusEvent();
        e.setId(rs.getLong("id"));
        e.setTitle(rs.getString("title"));
        e.setCategory(rs.getString("category"));
        e.setDescription(rs.getString("description"));
        Date ed = rs.getDate("event_date");
        if (ed != null) e.setEventDate(ed.toLocalDate());
        Time st = rs.getTime("start_time");
        if (st != null) e.setStartTime(st.toLocalTime());
        Time et = rs.getTime("end_time");
        if (et != null) e.setEndTime(et.toLocalTime());
        e.setLocation(rs.getString("location"));
        e.setCapacity(rs.getInt("capacity"));
        e.setRegisteredCount(rs.getInt("registered_count"));
        e.setStatus(rs.getString("status"));
        long cb = rs.getLong("created_by");
        if (!rs.wasNull()) e.setCreatedBy(cb);
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) e.setCreatedAt(ts.toLocalDateTime());
        return e;
    };

    private final RowMapper<EventRegistration> regMapper = (rs, rowNum) -> {
        EventRegistration er = new EventRegistration();
        er.setId(rs.getLong("id"));
        er.setEventId(rs.getLong("event_id"));
        er.setEventTitle(rs.getString("event_title"));
        er.setEventLocation(rs.getString("event_location"));
        er.setEventDate(rs.getString("event_date"));
        er.setStudentId(rs.getLong("student_id"));
        er.setStudentCode(rs.getString("student_code"));
        er.setStudentName(rs.getString("student_name"));
        er.setStatus(rs.getString("status"));
        Timestamp ts = rs.getTimestamp("registered_at");
        if (ts != null) er.setRegisteredAt(ts.toLocalDateTime());
        return er;
    };

    private static final String BASE_EVENT_SELECT =
            "SELECT e.*, (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id AND er.status = 'REGISTERED') AS registered_count " +
            "FROM campus_events e ";

    public List<CampusEvent> findAll() {
        return jdbcTemplate.query(BASE_EVENT_SELECT + "ORDER BY e.event_date ASC, e.start_time ASC", eventMapper);
    }

    public List<CampusEvent> findPublished() {
        return jdbcTemplate.query(BASE_EVENT_SELECT + "WHERE e.status = 'PUBLISHED' ORDER BY e.event_date ASC", eventMapper);
    }

    public Optional<CampusEvent> findById(Long id) {
        return jdbcTemplate.query(BASE_EVENT_SELECT + "WHERE e.id = ?", eventMapper, id).stream().findFirst();
    }

    public Long save(CampusEvent event) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO campus_events (title, category, description, event_date, start_time, end_time, location, capacity, status, created_by) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, event.getTitle());
            ps.setString(2, event.getCategory());
            ps.setString(3, event.getDescription());
            ps.setDate(4, Date.valueOf(event.getEventDate()));
            ps.setTime(5, Time.valueOf(event.getStartTime()));
            ps.setTime(6, Time.valueOf(event.getEndTime()));
            ps.setString(7, event.getLocation());
            ps.setInt(8, event.getCapacity());
            ps.setString(9, event.getStatus());
            if (event.getCreatedBy() != null) {
                ps.setLong(10, event.getCreatedBy());
            } else {
                ps.setNull(10, java.sql.Types.BIGINT);
            }
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(CampusEvent event) {
        return jdbcTemplate.update(
                "UPDATE campus_events SET title = ?, category = ?, description = ?, event_date = ?, start_time = ?, end_time = ?, location = ?, capacity = ?, status = ? WHERE id = ?",
                event.getTitle(), event.getCategory(), event.getDescription(),
                Date.valueOf(event.getEventDate()), Time.valueOf(event.getStartTime()), Time.valueOf(event.getEndTime()),
                event.getLocation(), event.getCapacity(), event.getStatus(), event.getId());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM campus_events WHERE id = ?", id);
    }

    public boolean isStudentRegistered(Long eventId, Long studentDbId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM event_registrations WHERE event_id = ? AND student_id = ? AND status = 'REGISTERED'",
                Integer.class, eventId, studentDbId);
        return count != null && count > 0;
    }

    public void registerStudent(Long eventId, Long studentDbId) {
        Integer anyRow = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM event_registrations WHERE event_id = ? AND student_id = ?",
                Integer.class, eventId, studentDbId);
        if (anyRow != null && anyRow > 0) {
            jdbcTemplate.update(
                    "UPDATE event_registrations SET status = 'REGISTERED', registered_at = CURRENT_TIMESTAMP WHERE event_id = ? AND student_id = ?",
                    eventId, studentDbId);
        } else {
            jdbcTemplate.update(
                    "INSERT INTO event_registrations (event_id, student_id, status) VALUES (?, ?, 'REGISTERED')",
                    eventId, studentDbId);
        }
    }

    public int cancelRegistration(Long eventId, Long studentDbId) {
        return jdbcTemplate.update(
                "UPDATE event_registrations SET status = 'CANCELLED' WHERE event_id = ? AND student_id = ? AND status = 'REGISTERED'",
                eventId, studentDbId);
    }

    public List<EventRegistration> findRegistrationsByStudent(Long studentDbId) {
        return jdbcTemplate.query(
                "SELECT er.*, e.title AS event_title, e.location AS event_location, CAST(e.event_date AS CHAR) AS event_date, " +
                "s.student_id AS student_code, s.name AS student_name " +
                "FROM event_registrations er " +
                "JOIN campus_events e ON er.event_id = e.id " +
                "JOIN students s ON er.student_id = s.id " +
                "WHERE er.student_id = ? ORDER BY er.registered_at DESC",
                regMapper, studentDbId);
    }

    public List<EventRegistration> findRegistrationsByEvent(Long eventId) {
        return jdbcTemplate.query(
                "SELECT er.*, e.title AS event_title, e.location AS event_location, CAST(e.event_date AS CHAR) AS event_date, " +
                "s.student_id AS student_code, s.name AS student_name " +
                "FROM event_registrations er " +
                "JOIN campus_events e ON er.event_id = e.id " +
                "JOIN students s ON er.student_id = s.id " +
                "WHERE er.event_id = ? AND er.status = 'REGISTERED' ORDER BY er.registered_at DESC",
                regMapper, eventId);
    }
}
