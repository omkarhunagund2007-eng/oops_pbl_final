package com.gmu.smartcampus.model;

/**
 * Classroom extending CampusResource (Inheritance + Method Overriding).
 */
public class Classroom extends CampusResource {

    private String roomId;
    private String building;
    private String roomNumber;
    private int capacity;
    private String equipmentSummary;

    @Override
    public String getEntityType() {
        return "CLASSROOM";
    }

    @Override
    public String getAuditIdentifier() {
        return roomId;
    }

    @Override
    public String getResourceCode() {
        return roomId;
    }

    @Override
    public String getResourceTitle() {
        return building + " · Room " + roomNumber;
    }

    @Override
    public String getResourceType() {
        return "CLASSROOM";
    }

    @Override
    public String getAvailabilitySummary() {
        return String.format("%s (%s) · %d Seats · %s", roomId, building, capacity, availabilityStatus);
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getEquipmentSummary() {
        return equipmentSummary;
    }

    public void setEquipmentSummary(String equipmentSummary) {
        this.equipmentSummary = equipmentSummary;
    }
}
