# GM University Smart Campus Integrated Management System
**Project Report (UE25CS2303 — Object Oriented Programming with Java, Semester 3)**

---

## 1. Cover Page

- **University:** GM University
- **Program & Semester:** B.Tech Computer Science & Engineering — Semester 3
- **Course Code & Title:** UE25CS2303 — Object Oriented Programming with Java (Project-Based Learning)
- **Project Title:** Smart Campus Integrated Management System
- **Submitted By:** [Student Name 1] (`[USN 1]`), [Student Name 2] (`[USN 2]`), [Student Name 3] (`[USN 3]`)
- **Course Faculty / Guide:** [Faculty Guide Name], Department of CSE, GM University
- **Academic Term:** 2026–2027 (Odd Semester)

---

## 2. Abstract

Modern university campuses manage thousands of interdependent academic records, facility schedules, laboratory inventories, student registrations, and campus activities. Fragmented spreadsheets and manual approval desks create scheduling conflicts, opaque approval queues, and poor user experience. This project delivers a full-stack **Smart Campus Integrated Management System** for GM University engineered with **Java 21, Spring Boot 3.3, Spring Security, pure JDBC (`JdbcTemplate`), MySQL 8, Thymeleaf, Bootstrap 5, and Chart.js**. The system enforces end-to-end Object Oriented Programming principles across Units 1–6—including inheritance hierarchies, polymorphic `Bookable` resources, typed exception handling, `ExecutorService` + `ReentrantLock` booking concurrency control, Java Streams analytics, and `BufferedWriter` CSV exports—paired with a memorable 3-scene cinematic campus arrival and interactive pull-chain lamp login experience.

---

## 3. Introduction

Universities operate as complex ecosystems combining academic administration (students, faculty, departments, courses) with physical infrastructure (classrooms, specialized laboratories, audio-visual/research equipment) and co-curricular events. The **GM University Smart Campus Integrated Management System** unifies these workflows inside a single role-secured web portal. Students can self-register, await registrar verification, browse courses, register for campus symposiums, and reserve rooms or labs without double-booking, while administrators exercise complete oversight via real-time KPIs, approval queues, charts, and downloadable CSV audits.

---

## 4. Problem Statement

Traditional campus portals suffer from four core limitations:
1. **Unverified or Disconnected Onboarding:** Lack of structured registration approval workflows leads to unauthorized portal access or manual paper bottlenecks.
2. **Simultaneous Resource Booking Conflicts:** Without backend locking and transactional overlap detection, two users requesting the same laboratory or auditorium for overlapping hours can trigger double-bookings.
3. **Siloed Academic & Facility Data:** Student records, faculty-course assignments, equipment inventory, and event registrations are rarely normalized under referential integrity.
4. **Generic, Unengaging Interfaces:** Static legacy forms lack dark/light accessibility, responsive design, and clear visual feedback.

---

## 5. Project Objectives

1. Design a 15-table normalized MySQL 8 schema (`smart_campus_db`) using pure parameterized JDBC (`JdbcTemplate`) without ORM overhead.
2. Implement genuine BCrypt-secured authentication, student self-registration (`PENDING` -> `APPROVED`/`REJECTED`), and strict role-based access control (`ROLE_ADMIN` vs `ROLE_STUDENT`).
3. Build complete CRUD workflows for Students, Faculty, Courses, Classrooms, Laboratories, Equipment, Campus Activities, Announcements, and Resource Bookings.
4. Demonstrate all Units 1–6 Java OOP concepts in live production modules, including thread-safe concurrent booking via `ExecutorService` and `ReentrantLock`.
5. Deliver a cinematic 3-scene campus arrival & interactive lamp login with reduced-motion accessibility and dual light/dark themes.
6. Validate every layer with automated JUnit 5 and `MockMvc` integration tests.

---

## 6. Methodology / System Design

### 6.1 Layered Architecture
- **Presentation Layer:** Thymeleaf server-rendered templates (`login.html`, `admin/dashboard.html`, `student/dashboard.html`), Bootstrap 5.3, Chart.js 4.4, and modular vanilla JavaScript.
- **Controller Layer:** Spring MVC & REST controllers (`AuthController`, `AdminDashboardController`, `StudentDashboardController`) secured with `@PreAuthorize` and CSRF tokens.
- **Service Layer:** `AuthRegistrationService`, `CampusManagementService`, `BookingConcurrencyService`, `AnalyticsStreamService`, and `CsvExportService`.
- **Repository Layer:** 12 pure JDBC repositories (`JdbcTemplate`, `RowMapper<T>`, `GeneratedKeyHolder`) executing parameterized SQL queries.
- **Database Layer:** MySQL 8 (`smart_campus_db`) enforcing foreign keys, unique constraints, and composite indexes (`idx_bookings_slot`).

### 6.2 OOP Hierarchy Design
- `AuditableResource` and `Bookable` interfaces define behavioral contracts.
- `BaseEntity` provides encapsulated identity and timestamp fields.
- `Person` specializes into `Student` and `Faculty` (overriding `getAcademicSummary()`).
- `CampusResource` specializes into `Classroom`, `Laboratory`, and `Equipment` (overriding `isCurrentlyBookable()` and `getAvailabilitySummary()`, plus overloaded `buildLockKey()`).

---

## 7. Implementation

1. **Cinematic 3-Scene Login:** Scene 1 animates a student walking along the GM University avenue with *"Every Great Journey Begins Here."* Scene 2 renders a hanging brass lamp with pointer/touch drag physics on its pull chain that swings the lamp, illuminates radial warm light, and transitions into Scene 3's role-switched login and registration modal.
2. **Registration & Admin Approval:** Registrations hash passwords via `BCryptPasswordEncoder(10)` and store `PENDING` state. `CustomUserDetails` blocks `PENDING` and `REJECTED` accounts at the Spring Security provider level while `CampusAuthFailureHandler` returns explicit status reasons. Admins approve or reject via `/api/admin/approvals/**`, logging every decision in `approval_history`.
3. **Concurrency-Safe Resource Booking:** `BookingConcurrencyService` combines an 8-thread `ExecutorService`, per-resource `ReentrantLock` in a `ConcurrentHashMap`, and `@Transactional(isolation = Isolation.SERIALIZABLE)` overlap queries (`start_time < requestedEnd AND end_time > requestedStart`).
4. **Streams & CSV Reporting:** `AnalyticsStreamService` computes department and booking breakdowns using Java Streams (`groupingBy`, `counting`, `filter`, `sorted`) and `HashSet`/`HashMap`. `CsvExportService` streams and archives sanitized CSV reports via `BufferedWriter`.

---

## 8. Results & Discussion

The complete Maven project was compiled under OpenJDK 21 and verified through an automated JUnit 5 + `MockMvc` suite (`SmartCampusIntegrationTests`):
- **Authentication & Status Enforcement:** Verified admin/student login routing, invalid password rejection, and blocking of `PENDING` and `REJECTED` accounts until admin approval.
- **RBAC Security:** Verified student sessions receive `403 Forbidden` on `/admin/**` and `/api/admin/**` endpoints.
- **Concurrency Race Verification:** Verified with 5 simultaneous threads competing via `CountDownLatch` for the identical classroom and time slot: strictly **1 thread** succeeded while **4 threads** cleanly received `BookingConflictException`.
- **CRUD & Export:** Verified Faculty, Classroom, Laboratory, Equipment, Event registration, and CSV file generation.

---

## 9. Conclusion & Future Scope

The GM University Smart Campus Integrated Management System successfully bridges rigorous Java OOP engineering with a refined, responsive university web portal. Every module—from pure JDBC persistence to thread-safe scheduling—operates deterministically and is backed by automated tests.

**Future Scope:** QR-code event attendance check-ins, automated timetable clash detection per semester section, and campus IoT smart-meter telemetry integration for classroom energy optimization.

---

## 10. References

1. Herbert Schildt, *Java: The Complete Reference*, 13th Edition, McGraw-Hill Education.
2. Craig Walls, *Spring in Action*, 6th Edition, Manning Publications.
3. Spring Boot 3.3 & Spring Security 6 Official Reference Documentation (`spring.io`).
4. MySQL 8.0 Reference Manual (`dev.mysql.com/doc/`).
5. GM University UE25CS2303 Course Syllabus & PBL Guidelines.

---

## 11. Individual Contribution Declaration

| Sl. No. | Student Name | USN / Student ID | Role | Specific Contribution | Percentage (%) | Signature |
| :---: | :--- | :--- | :--- | :--- | :---: | :--- |
| 1 | `[Enter Student Name 1]` | `[Enter USN 1]` | `[Backend & JDBC Architect]` | `[Schema, JDBC repositories, Security & Concurrency Service]` | `[__%]` | `____________` |
| 2 | `[Enter Student Name 2]` | `[Enter USN 2]` | `[OOP & Service Engineer]` | `[Domain hierarchy, Streams analytics, CSV export & JUnit tests]` | `[__%]` | `____________` |
| 3 | `[Enter Student Name 3]` | `[Enter USN 3]` | `[UI/UX & Frontend Developer]` | `[Cinematic 3-scene intro, Thymeleaf dashboards, Charts & Dark mode]` | `[__%]` | `____________` |
