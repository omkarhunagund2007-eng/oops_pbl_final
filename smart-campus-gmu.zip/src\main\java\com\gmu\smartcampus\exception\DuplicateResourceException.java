package com.gmu.smartcampus.exception;

import org.springframework.http.HttpStatus;

public class DuplicateResourceException extends CampusException {
    public DuplicateResourceException(String message) {
        super(message, HttpStatus.CONFLICT, "DUPLICATE_RESOURCE");
    }
}
