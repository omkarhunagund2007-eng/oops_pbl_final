package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.ApprovalHistory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public class ApprovalHistoryRepository {

    private final JdbcTemplate jdbcTemplate;

    public ApprovalHistoryRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<ApprovalHistory> rowMapper = (rs, rowNum) -> {
        ApprovalHistory ah = new ApprovalHistory();
        ah.setId(rs.getLong("id"));
        ah.setTargetType(rs.getString("target_type"));
        ah.setTargetId(rs.getLong("target_id"));
        ah.setAction(rs.getString("action"));
        ah.setAdminUserId(rs.getLong("admin_user_id"));
        ah.setAdminUsername(rs.getString("admin_username"));
        ah.setReason(rs.getString("reason"));
        Timestamp ts = rs.getTimestamp("decision_date");
        if (ts != null) ah.setDecisionDate(ts.toLocalDateTime());
        return ah;
    };

    public void record(String targetType, Long targetId, String action, Long adminUserId, String adminUsername, String reason) {
        jdbcTemplate.update(
                "INSERT INTO approval_history (target_type, target_id, action, admin_user_id, admin_username, reason) VALUES (?, ?, ?, ?, ?, ?)",
                targetType, targetId, action, adminUserId, adminUsername, reason);
    }

    public List<ApprovalHistory> findAllRecent() {
        return jdbcTemplate.query("SELECT * FROM approval_history ORDER BY decision_date DESC LIMIT 50", rowMapper);
    }
}
