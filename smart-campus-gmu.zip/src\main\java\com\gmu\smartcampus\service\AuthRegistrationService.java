package com.gmu.smartcampus.service;

import com.gmu.smartcampus.dto.RegistrationRequest;
import com.gmu.smartcampus.exception.DuplicateResourceException;
import com.gmu.smartcampus.exception.ResourceNotFoundException;
import com.gmu.smartcampus.model.ApprovalHistory;
import com.gmu.smartcampus.model.Student;
import com.gmu.smartcampus.model.UserAccount;
import com.gmu.smartcampus.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuthRegistrationService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final DepartmentRepository departmentRepository;
    private final CourseRepository courseRepository;
    private final ApprovalHistoryRepository approvalHistoryRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthRegistrationService(UserRepository userRepository,
                                   StudentRepository studentRepository,
                                   DepartmentRepository departmentRepository,
                                   CourseRepository courseRepository,
                                   ApprovalHistoryRepository approvalHistoryRepository,
                                   PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.departmentRepository = departmentRepository;
        this.courseRepository = courseRepository;
        this.approvalHistoryRepository = approvalHistoryRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public Student registerStudent(RegistrationRequest req) {
        String cleanUsername = req.getUsername().trim().toLowerCase();
        String cleanStudentId = req.getStudentId().trim().toUpperCase();

        if (userRepository.existsByUsername(cleanUsername)) {
            throw new DuplicateResourceException("Username '" + cleanUsername + "' is already registered.");
        }
        if (studentRepository.existsByStudentId(cleanStudentId)) {
            throw new DuplicateResourceException("Student ID '" + cleanStudentId + "' is already registered.");
        }
        departmentRepository.findById(req.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Selected department does not exist."));

        UserAccount user = new UserAccount();
        user.setUsername(cleanUsername);
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setFullName(req.getName().trim());
        user.setEmail(cleanUsername + "@student.gmu.edu.in");
        user.setRole("STUDENT");
        user.setAccountStatus("PENDING");
        user.setThemePreference("light");
        Long userId = userRepository.save(user);

        Student student = new Student();
        student.setUserId(userId);
        student.setUsername(cleanUsername);
        student.setStudentId(cleanStudentId);
        student.setName(req.getName().trim());
        student.setDepartmentId(req.getDepartmentId());
        student.setBranch(req.getBranch().trim());
        student.setSemester(req.getSemester());
        student.setSection(req.getSection().trim().toUpperCase());
        student.setPhone(req.getPhone().trim());
        student.setAdmissionYear(req.getAdmissionYear());
        student.setAccountStatus("PENDING");

        Long studentDbId = studentRepository.save(student);
        return studentRepository.findById(studentDbId).orElse(student);
    }

    @Transactional
    public Student approveStudent(Long studentDbId, Long adminUserId, String adminUsername) {
        Student student = studentRepository.findById(studentDbId)
                .orElseThrow(() -> new ResourceNotFoundException("Student record not found."));

        studentRepository.updateStatus(studentDbId, "APPROVED");
        userRepository.updateAccountStatus(student.getUserId(), "APPROVED");
        approvalHistoryRepository.record(
                "STUDENT_REGISTRATION", studentDbId, "APPROVED",
                adminUserId, adminUsername, "Verified student credentials and academic batch.");

        // Auto-enroll approved student into matching department/semester courses
        courseRepository.findAll().stream()
                .filter(c -> c.isActive() && c.getSemester() == student.getSemester()
                        && c.getDepartmentId().equals(student.getDepartmentId()))
                .forEach(c -> courseRepository.enrollStudent(studentDbId, c.getId()));

        return studentRepository.findById(studentDbId).orElseThrow();
    }

    @Transactional
    public Student rejectStudent(Long studentDbId, Long adminUserId, String adminUsername, String reason) {
        Student student = studentRepository.findById(studentDbId)
                .orElseThrow(() -> new ResourceNotFoundException("Student record not found."));

        String cleanReason = (reason != null && !reason.isBlank())
                ? reason.trim()
                : "Registration details could not be verified by registrar.";

        studentRepository.updateStatus(studentDbId, "REJECTED");
        userRepository.updateAccountStatus(student.getUserId(), "REJECTED");
        approvalHistoryRepository.record(
                "STUDENT_REGISTRATION", studentDbId, "REJECTED",
                adminUserId, adminUsername, cleanReason);

        return studentRepository.findById(studentDbId).orElseThrow();
    }

    public List<ApprovalHistory> getRecentApprovalHistory() {
        return approvalHistoryRepository.findAllRecent();
    }

    public void updateThemePreference(Long userId, String theme) {
        String normalized = "dark".equalsIgnoreCase(theme) ? "dark" : "light";
        userRepository.updateThemePreference(userId, normalized);
    }
}
