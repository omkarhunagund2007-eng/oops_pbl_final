package com.gmu.smartcampus.service;

import com.gmu.smartcampus.exception.DuplicateResourceException;
import com.gmu.smartcampus.exception.ResourceNotFoundException;
import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CampusManagementService {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;
    private final FacultyRepository facultyRepository;
    private final CourseRepository courseRepository;
    private final ClassroomRepository classroomRepository;
    private final LaboratoryRepository laboratoryRepository;
    private final EquipmentRepository equipmentRepository;
    private final EventRepository eventRepository;
    private final AnnouncementRepository announcementRepository;
    private final DepartmentRepository departmentRepository;

    public CampusManagementService(StudentRepository studentRepository,
                                   UserRepository userRepository,
                                   FacultyRepository facultyRepository,
                                   CourseRepository courseRepository,
                                   ClassroomRepository classroomRepository,
                                   LaboratoryRepository laboratoryRepository,
                                   EquipmentRepository equipmentRepository,
                                   EventRepository eventRepository,
                                   AnnouncementRepository announcementRepository,
                                   DepartmentRepository departmentRepository) {
        this.studentRepository = studentRepository;
        this.userRepository = userRepository;
        this.facultyRepository = facultyRepository;
        this.courseRepository = courseRepository;
        this.classroomRepository = classroomRepository;
        this.laboratoryRepository = laboratoryRepository;
        this.equipmentRepository = equipmentRepository;
        this.eventRepository = eventRepository;
        this.announcementRepository = announcementRepository;
        this.departmentRepository = departmentRepository;
    }

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // --- Students ---
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public List<Student> getPendingStudents() {
        return studentRepository.findByStatus("PENDING");
    }

    public Student getStudentByUserId(Long userId) {
        return studentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found."));
    }

    @Transactional
    public Student updateStudent(Long id, Student updated) {
        Student existing = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found."));
        existing.setName(updated.getName());
        existing.setDepartmentId(updated.getDepartmentId());
        existing.setBranch(updated.getBranch());
        existing.setSemester(updated.getSemester());
        existing.setSection(updated.getSection());
        existing.setPhone(updated.getPhone());
        existing.setAdmissionYear(updated.getAdmissionYear());
        if (updated.getAccountStatus() != null) {
            existing.setAccountStatus(updated.getAccountStatus());
            userRepository.updateAccountStatus(existing.getUserId(), updated.getAccountStatus());
        }
        studentRepository.update(existing);
        return studentRepository.findById(id).orElseThrow();
    }

    public void deleteStudent(Long id) {
        if (studentRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Student not found.");
        }
    }

    // --- Faculty ---
    public List<Faculty> getAllFaculty() {
        return facultyRepository.findAll();
    }

    public Faculty createFaculty(Faculty faculty) {
        if (facultyRepository.existsByFacultyId(faculty.getFacultyId())) {
            throw new DuplicateResourceException("Faculty ID already exists: " + faculty.getFacultyId());
        }
        Long id = facultyRepository.save(faculty);
        return facultyRepository.findById(id).orElse(faculty);
    }

    public Faculty updateFaculty(Long id, Faculty updated) {
        Faculty existing = facultyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Faculty member not found."));
        updated.setId(existing.getId());
        facultyRepository.update(updated);
        return facultyRepository.findById(id).orElseThrow();
    }

    public void deleteFaculty(Long id) {
        if (facultyRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Faculty member not found.");
        }
    }

    // --- Courses ---
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public List<Course> getStudentCourses(Long studentDbId) {
        return courseRepository.findByStudentId(studentDbId);
    }

    @Transactional
    public Course createCourse(Course course) {
        if (courseRepository.existsByCourseCode(course.getCourseCode())) {
            throw new DuplicateResourceException("Course code already exists: " + course.getCourseCode());
        }
        Long id = courseRepository.save(course);
        if (course.getAssignedFacultyId() != null) {
            courseRepository.assignFaculty(id, course.getAssignedFacultyId());
        }
        return courseRepository.findById(id).orElse(course);
    }

    @Transactional
    public Course updateCourse(Long id, Course updated) {
        courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found."));
        updated.setId(id);
        courseRepository.update(updated);
        courseRepository.assignFaculty(id, updated.getAssignedFacultyId());
        return courseRepository.findById(id).orElseThrow();
    }

    public void assignFacultyToCourse(Long courseId, Long facultyId) {
        courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found."));
        courseRepository.assignFaculty(courseId, facultyId);
    }

    public void enrollStudentInCourse(Long studentDbId, Long courseId) {
        courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found."));
        courseRepository.enrollStudent(studentDbId, courseId);
    }

    public void unenrollStudentFromCourse(Long studentDbId, Long courseId) {
        courseRepository.unenrollStudent(studentDbId, courseId);
    }

    public void deleteCourse(Long id) {
        if (courseRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Course not found.");
        }
    }

    // --- Classrooms ---
    public List<Classroom> getAllClassrooms() {
        return classroomRepository.findAll();
    }

    public Classroom createClassroom(Classroom classroom) {
        if (classroomRepository.existsByRoomId(classroom.getRoomId())) {
            throw new DuplicateResourceException("Classroom ID already exists: " + classroom.getRoomId());
        }
        Long id = classroomRepository.save(classroom);
        return classroomRepository.findById(id).orElse(classroom);
    }

    public Classroom updateClassroom(Long id, Classroom updated) {
        classroomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Classroom not found."));
        updated.setId(id);
        classroomRepository.update(updated);
        return classroomRepository.findById(id).orElseThrow();
    }

    public void deleteClassroom(Long id) {
        if (classroomRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Classroom not found.");
        }
    }

    // --- Laboratories ---
    public List<Laboratory> getAllLaboratories() {
        return laboratoryRepository.findAll();
    }

    public Laboratory createLaboratory(Laboratory lab) {
        if (laboratoryRepository.existsByLabId(lab.getLabId())) {
            throw new DuplicateResourceException("Lab ID already exists: " + lab.getLabId());
        }
        Long id = laboratoryRepository.save(lab);
        return laboratoryRepository.findById(id).orElse(lab);
    }

    public Laboratory updateLaboratory(Long id, Laboratory updated) {
        laboratoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratory not found."));
        updated.setId(id);
        laboratoryRepository.update(updated);
        return laboratoryRepository.findById(id).orElseThrow();
    }

    public void deleteLaboratory(Long id) {
        if (laboratoryRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Laboratory not found.");
        }
    }

    // --- Equipment ---
    public List<Equipment> getAllEquipment() {
        return equipmentRepository.findAll();
    }

    public Equipment createEquipment(Equipment eq) {
        if (equipmentRepository.existsByEquipmentId(eq.getEquipmentId())) {
            throw new DuplicateResourceException("Equipment ID already exists: " + eq.getEquipmentId());
        }
        Long id = equipmentRepository.save(eq);
        return equipmentRepository.findById(id).orElse(eq);
    }

    public Equipment updateEquipment(Long id, Equipment updated) {
        equipmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Equipment item not found."));
        updated.setId(id);
        equipmentRepository.update(updated);
        return equipmentRepository.findById(id).orElseThrow();
    }

    public void deleteEquipment(Long id) {
        if (equipmentRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Equipment item not found.");
        }
    }

    // --- Campus Events ---
    public List<CampusEvent> getAllEvents() {
        return eventRepository.findAll();
    }

    public List<CampusEvent> getPublishedEvents() {
        return eventRepository.findPublished();
    }

    public CampusEvent createEvent(CampusEvent event, Long creatorUserId) {
        event.setCreatedBy(creatorUserId);
        Long id = eventRepository.save(event);
        return eventRepository.findById(id).orElse(event);
    }

    public CampusEvent updateEvent(Long id, CampusEvent updated) {
        eventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found."));
        updated.setId(id);
        eventRepository.update(updated);
        return eventRepository.findById(id).orElseThrow();
    }

    public void deleteEvent(Long id) {
        if (eventRepository.deleteById(id) == 0) {
            throw new ResourceNotFoundException("Event not found.");
        }
    }

    @Transactional
    public void registerStudentForEvent(Long eventId, Long studentDbId) {
        CampusEvent event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Campus event not found."));
        if (eventRepository.isStudentRegistered(eventId, studentDbId)) {
            throw new DuplicateResourceException("You are already registered for this campus event.");
        }
        if (!event.hasAvailableSeats()) {
            throw new IllegalArgumentException("This event is full or no longer accepting registrations.");
        }
        eventRepository.registerStudent(eventId, studentDbId);
    }

    public void cancelEventRegistration(Long eventId, Long studentDbId) {
        if (eventRepository.cancelRegistration(eventId, studentDbId) == 0) {
            throw new ResourceNotFoundException("Active event registration not found.");
        }
    }

    public List<EventRegistration> getStudentEventRegistrations(Long studentDbId) {
        return eventRepository.findRegistrationsByStudent(studentDbId);
    }

    public List<EventRegistration> getEventRegistrations(Long eventId) {
        return eventRepository.findRegistrationsByEvent(eventId);
    }

    // --- Announcements ---
    public List<Announcement> getAllAnnouncements() {
        return announcementRepository.findAll();
    }

    public List<Announcement> getStudentAnnouncements() {
        return announcementRepository.findForStudents();
    }

    public Announcement createAnnouncement(Announcement a, Long adminUserId) {
        a.setPostedBy(adminUserId);
        Long id = announcementRepository.save(a);
        a.setId(id);
        return a;
    }

    public void deleteAnnouncement(Long id) {
        announcementRepository.deleteById(id);
    }
}
