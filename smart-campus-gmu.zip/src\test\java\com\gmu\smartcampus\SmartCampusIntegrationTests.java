package com.gmu.smartcampus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmu.smartcampus.dto.BookingRequest;
import com.gmu.smartcampus.dto.RegistrationRequest;
import com.gmu.smartcampus.exception.BookingConflictException;
import com.gmu.smartcampus.exception.DuplicateResourceException;
import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.repository.ApprovalHistoryRepository;
import com.gmu.smartcampus.service.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.logout;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SmartCampusIntegrationTests {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private AuthRegistrationService authService;
    @Autowired private CampusManagementService campusService;
    @Autowired private BookingConcurrencyService bookingService;
    @Autowired private AnalyticsStreamService analyticsService;
    @Autowired private CsvExportService csvExportService;
    @Autowired private ApprovalHistoryRepository approvalHistoryRepository;

    @Test
    void testAdminAndStudentLoginAndInvalidCredentials() throws Exception {
        mockMvc.perform(formLogin("/perform-login").user("admin").password("Admin@GMU2026"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/dashboard"));

        mockMvc.perform(formLogin("/perform-login").user("aarav.patel").password("Student@2026"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/student/dashboard"));

        mockMvc.perform(formLogin("/perform-login").user("aarav.patel").password("WrongPass!"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/login?error=*&status=INVALID"));
    }

    @Test
    void testPendingAndRejectedAccountsCannotLogin() throws Exception {
        mockMvc.perform(formLogin("/perform-login").user("meera.nair").password("Student@2026"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/login?error=*&status=PENDING"));

        mockMvc.perform(formLogin("/perform-login").user("test.rejected").password("Student@2026"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/login?error=*&status=REJECTED"));
    }

    @Test
    void testStudentRegistrationDuplicatePreventionAndAdminApprovalWorkflow() throws Exception {
        RegistrationRequest req = new RegistrationRequest();
        req.setName("Kiran Hegde");
        req.setStudentId("GMU25CS777");
        req.setUsername("kiran.hegde");
        req.setPassword("Pass@1234");
        req.setDepartmentId(1L);
        req.setBranch("Computer Science & Engg");
        req.setSemester(3);
        req.setSection("B");
        req.setPhone("9880998877");
        req.setAdmissionYear(2025);

        mockMvc.perform(post("/api/auth/register")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.accountStatus").value("PENDING"));

        // Duplicate prevention
        assertThrows(DuplicateResourceException.class, () -> authService.registerStudent(req));

        // Still PENDING -> login rejected
        mockMvc.perform(formLogin("/perform-login").user("kiran.hegde").password("Pass@1234"))
                .andExpect(redirectedUrlPattern("/login?error=*&status=PENDING"));

        // Admin approves student
        Student pending = campusService.getAllStudents().stream()
                .filter(s -> "GMU25CS777".equals(s.getStudentId()))
                .findFirst().orElseThrow();

        Student approved = authService.approveStudent(pending.getId(), 1L, "admin");
        assertEquals("APPROVED", approved.getAccountStatus());
        assertFalse(approvalHistoryRepository.findAllRecent().isEmpty());

        // Now student can log in
        mockMvc.perform(formLogin("/perform-login").user("kiran.hegde").password("Pass@1234"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/student/dashboard"));
    }

    @Test
    @WithUserDetails("aarav.patel")
    void testStudentAccessRestrictionsAndLogout() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isForbidden());

        mockMvc.perform(get("/api/admin/students"))
                .andExpect(status().isForbidden());

        mockMvc.perform(get("/api/student/profile"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.studentId").value("GMU25CS001"));

        mockMvc.perform(logout("/logout"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?logout=true"));
    }

    @Test
    @WithUserDetails("admin")
    void testCrudOperationsAcrossModules() throws Exception {
        // Faculty CRUD
        Faculty fac = new Faculty();
        fac.setFacultyId("GMU-FAC-901");
        fac.setName("Dr. Test Faculty");
        fac.setDepartmentId(1L);
        fac.setDesignation("Assistant Professor");
        fac.setEmail("test.fac901@gmu.edu.in");
        fac.setPhone("9845099901");
        fac.setSpecialization("Compilers");
        fac.setJoiningDate(LocalDate.of(2023, 8, 1));
        Faculty savedFac = campusService.createFaculty(fac);
        assertNotNull(savedFac.getId());

        // Classroom CRUD
        Classroom cr = new Classroom();
        cr.setRoomId("CR-TEST-901");
        cr.setBuilding("Turing Block");
        cr.setRoomNumber("901");
        cr.setCapacity(50);
        cr.setAvailabilityStatus("AVAILABLE");
        cr.setEquipmentSummary("Projector");
        Classroom savedCr = campusService.createClassroom(cr);
        assertTrue(savedCr.isCurrentlyBookable());

        // Lab CRUD
        Laboratory lab = new Laboratory();
        lab.setLabId("LAB-TEST-901");
        lab.setName("Test Systems Lab");
        lab.setLocation("Floor 3");
        lab.setCapacity(30);
        lab.setLabType("Systems");
        lab.setEquipmentSummary("Linux Terminals");
        lab.setAvailabilityStatus("AVAILABLE");
        Laboratory savedLab = campusService.createLaboratory(lab);
        assertNotNull(savedLab.getId());

        // Equipment CRUD
        Equipment eq = new Equipment();
        eq.setEquipmentId("EQ-TEST-901");
        eq.setName("Logic Analyzer");
        eq.setCategory("Electronics");
        eq.setQuantity(4);
        eq.setAvailableQuantity(4);
        eq.setItemCondition("GOOD");
        eq.setLocation("ECE Store");
        eq.setPurchaseDate(LocalDate.of(2025, 1, 10));
        Equipment savedEq = campusService.createEquipment(eq);
        assertNotNull(savedEq.getId());

        // Cleanup
        campusService.deleteEquipment(savedEq.getId());
        campusService.deleteLaboratory(savedLab.getId());
        campusService.deleteClassroom(savedCr.getId());
        campusService.deleteFaculty(savedFac.getId());
    }

    @Test
    void testCourseAndEventRegistrationAndDuplicatePrevention() {
        Student student = campusService.getAllStudents().stream()
                .filter(s -> "GMU25CS001".equals(s.getStudentId()))
                .findFirst().orElseThrow();
        CampusEvent event = campusService.getPublishedEvents().get(0);

        campusService.registerStudentForEvent(event.getId(), student.getId());
        assertThrows(DuplicateResourceException.class,
                () -> campusService.registerStudentForEvent(event.getId(), student.getId()));

        campusService.cancelEventRegistration(event.getId(), student.getId());
        assertTrue(campusService.getStudentEventRegistrations(student.getId()).stream()
                .anyMatch(r -> r.getEventId().equals(event.getId()) && "CANCELLED".equals(r.getStatus())));
    }

    @Test
    void testOverlappingAndSimultaneousConcurrentBookings() throws Exception {
        Classroom room = campusService.getAllClassrooms().get(0);
        LocalDate targetDate = LocalDate.now().plusDays(20);

        // First sequential booking
        BookingRequest baseReq = new BookingRequest();
        baseReq.setResourceType("CLASSROOM");
        baseReq.setResourceId(room.getId());
        baseReq.setBookingDate(targetDate);
        baseReq.setStartTime(LocalTime.of(9, 0));
        baseReq.setEndTime(LocalTime.of(11, 0));
        baseReq.setPurpose("Sequential Slot");

        ResourceBooking first = bookingService.createBooking(baseReq, 1L, "Admin");
        assertNotNull(first.getId());

        // Overlapping check
        BookingRequest overlapReq = new BookingRequest();
        overlapReq.setResourceType("CLASSROOM");
        overlapReq.setResourceId(room.getId());
        overlapReq.setBookingDate(targetDate);
        overlapReq.setStartTime(LocalTime.of(10, 0));
        overlapReq.setEndTime(LocalTime.of(12, 0));
        overlapReq.setPurpose("Overlapping Slot");

        assertThrows(BookingConflictException.class,
                () -> bookingService.createBooking(overlapReq, 1L, "Admin"));

        // Simultaneous multithreaded race condition check for identical slot on a different hour
        LocalDate raceDate = LocalDate.now().plusDays(25);
        int threads = 5;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch start = new CountDownLatch(1);
        AtomicInteger successes = new AtomicInteger(0);
        AtomicInteger conflicts = new AtomicInteger(0);

        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            final int idx = i;
            futures.add(pool.submit(() -> {
                ready.countDown();
                start.await();
                BookingRequest raceReq = new BookingRequest();
                raceReq.setResourceType("CLASSROOM");
                raceReq.setResourceId(room.getId());
                raceReq.setBookingDate(raceDate);
                raceReq.setStartTime(LocalTime.of(14, 0));
                raceReq.setEndTime(LocalTime.of(16, 0));
                raceReq.setPurpose("Concurrent Thread #" + idx);
                try {
                    bookingService.createBooking(raceReq, 1L, "Thread-" + idx);
                    successes.incrementAndGet();
                } catch (BookingConflictException ex) {
                    conflicts.incrementAndGet();
                }
                return null;
            }));
        }

        ready.await();
        start.countDown();
        for (Future<?> f : futures) {
            f.get(10, TimeUnit.SECONDS);
        }
        pool.shutdown();

        assertEquals(1, successes.get(), "Exactly ONE concurrent thread must win the booking slot");
        assertEquals(threads - 1, conflicts.get(), "All competing simultaneous requests must receive BookingConflictException");
    }

    @Test
    void testStreamsAnalyticsAndCsvFileExport() throws Exception {
        var stats = analyticsService.computeDashboardStats();
        assertTrue(stats.getTotalCourses() >= 5);
        assertFalse(analyticsService.getUniqueEquipmentCategories().isEmpty());

        String csv = csvExportService.exportReportCsv("students");
        assertTrue(csv.contains("Student ID,Name,Username"));
        assertTrue(csv.contains("GMU25CS001"));
    }
}
