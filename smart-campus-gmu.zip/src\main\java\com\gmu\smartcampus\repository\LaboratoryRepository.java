package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Laboratory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class LaboratoryRepository {

    private final JdbcTemplate jdbcTemplate;

    public LaboratoryRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Laboratory> rowMapper = (rs, rowNum) -> {
        Laboratory l = new Laboratory();
        l.setId(rs.getLong("id"));
        l.setLabId(rs.getString("lab_id"));
        l.setName(rs.getString("name"));
        l.setLocation(rs.getString("location"));
        l.setCapacity(rs.getInt("capacity"));
        l.setLabType(rs.getString("lab_type"));
        l.setEquipmentSummary(rs.getString("equipment_summary"));
        l.setAvailabilityStatus(rs.getString("availability_status"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) l.setCreatedAt(ts.toLocalDateTime());
        return l;
    };

    public List<Laboratory> findAll() {
        return jdbcTemplate.query("SELECT * FROM laboratories ORDER BY lab_id ASC", rowMapper);
    }

    public Optional<Laboratory> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM laboratories WHERE id = ?", rowMapper, id).stream().findFirst();
    }

    public boolean existsByLabId(String labId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM laboratories WHERE LOWER(lab_id) = LOWER(?)", Integer.class, labId);
        return count != null && count > 0;
    }

    public Long save(Laboratory lab) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO laboratories (lab_id, name, location, capacity, lab_type, equipment_summary, availability_status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, lab.getLabId());
            ps.setString(2, lab.getName());
            ps.setString(3, lab.getLocation());
            ps.setInt(4, lab.getCapacity());
            ps.setString(5, lab.getLabType());
            ps.setString(6, lab.getEquipmentSummary());
            ps.setString(7, lab.getAvailabilityStatus());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Laboratory lab) {
        return jdbcTemplate.update(
                "UPDATE laboratories SET name = ?, location = ?, capacity = ?, lab_type = ?, equipment_summary = ?, availability_status = ? WHERE id = ?",
                lab.getName(), lab.getLocation(), lab.getCapacity(), lab.getLabType(),
                lab.getEquipmentSummary(), lab.getAvailabilityStatus(), lab.getId());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM laboratories WHERE id = ?", id);
    }
}
