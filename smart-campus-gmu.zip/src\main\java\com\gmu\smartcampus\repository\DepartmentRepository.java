package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Department;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class DepartmentRepository {

    private final JdbcTemplate jdbcTemplate;

    public DepartmentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Department> rowMapper = (rs, rowNum) -> {
        Department d = new Department();
        d.setId(rs.getLong("id"));
        d.setCode(rs.getString("code"));
        d.setName(rs.getString("name"));
        d.setHodName(rs.getString("hod_name"));
        d.setBuilding(rs.getString("building"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) d.setCreatedAt(ts.toLocalDateTime());
        return d;
    };

    public List<Department> findAll() {
        return jdbcTemplate.query("SELECT * FROM departments ORDER BY code ASC", rowMapper);
    }

    public Optional<Department> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM departments WHERE id = ?", rowMapper, id)
                .stream().findFirst();
    }

    public Optional<Department> findByCode(String code) {
        return jdbcTemplate.query("SELECT * FROM departments WHERE code = ?", rowMapper, code)
                .stream().findFirst();
    }
}
