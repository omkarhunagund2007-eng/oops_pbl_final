(function () {
  const csrfToken = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
  const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content') || 'X-XSRF-TOKEN';
  let resourcesCache = { classrooms: [], laboratories: [], equipment: [] };
  let facultyCache = [];

  function applyTheme(theme) {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('gmu-theme', theme);
    const btn = document.getElementById('theme-toggle-btn');
    if (btn) btn.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
  }
  applyTheme(localStorage.getItem('gmu-theme') || 'light');

  async function toggleTheme() {
    const next = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    applyTheme(next);
    await api('/api/user/theme', 'POST', { theme: next }).catch(() => {});
  }
  document.getElementById('theme-toggle-btn')?.addEventListener('click', toggleTheme);
  document.getElementById('st-settings-theme')?.addEventListener('click', toggleTheme);

  document.getElementById('mobile-sidebar-btn')?.addEventListener('click', () => {
    document.getElementById('student-sidebar')?.classList.toggle('open');
  });

  function showToast(msg, isError = false) {
    const stack = document.getElementById('toast-stack');
    if (!stack) return;
    const el = document.createElement('div');
    el.className = 'gmu-toast';
    if (isError) el.style.borderColor = '#EF4444';
    el.textContent = msg;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  function esc(str) {
    return String(str ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  async function api(url, method = 'GET', body = null) {
    const headers = {};
    if (body !== null) headers['Content-Type'] = 'application/json';
    if (csrfToken && method !== 'GET') headers[csrfHeader] = csrfToken;

    const res = await fetch(url, {
      method,
      headers,
      body: body !== null ? JSON.stringify(body) : undefined
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Request failed');
    }
    return json.data;
  }

  function animateCount(el, target) {
    if (!el) return;
    const goal = Number(target) || 0;
    const start = performance.now();
    const duration = 480;
    function step(now) {
      const p = Math.min(1, (now - start) / duration);
      el.textContent = Math.round(goal * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  async function loadDashboard() {
    const [coursesData, eventsData, bookings, announcements] = await Promise.all([
      api('/api/student/courses'),
      api('/api/student/events'),
      api('/api/student/bookings'),
      api('/api/student/announcements')
    ]);
    animateCount(document.getElementById('st-kpi-courses'), coursesData.enrolled.length);
    animateCount(document.getElementById('st-kpi-events'), eventsData.registrations.filter(r => r.status === 'REGISTERED').length);
    animateCount(document.getElementById('st-kpi-bookings'), bookings.length);

    document.getElementById('st-home-announcements').innerHTML = announcements.length
      ? announcements.slice(0, 4).map(a => `<div class="py-2 border-bottom"><strong>${esc(a.title)}</strong><div class="text-muted">${esc(a.content)}</div></div>`).join('')
      : '<div class="text-muted">No announcements.</div>';

    document.getElementById('st-home-events').innerHTML = eventsData.events.length
      ? eventsData.events.slice(0, 4).map(e => `<div class="py-2 border-bottom"><strong>${esc(e.title)}</strong><div class="text-muted">${esc(e.eventDate)} · ${esc(e.location)}</div></div>`).join('')
      : '<div class="text-muted">No upcoming events.</div>';
  }

  async function loadCourses() {
    const data = await api('/api/student/courses');
    const enrolledIds = new Set(data.enrolled.map(c => c.id));
    document.getElementById('st-enrolled-courses').innerHTML = data.enrolled.length
      ? `<table class="table table-hover mb-0"><thead><tr><th>Code</th><th>Name</th><th>Credits</th><th>Faculty</th><th>Action</th></tr></thead><tbody>` +
        data.enrolled.map(c => `<tr><td class="tabular-nums fw-semibold">${esc(c.courseCode)}</td><td>${esc(c.courseName)}</td><td class="tabular-nums">${c.credits}</td><td>${esc(c.assignedFacultyName || 'TBA')}</td><td><button class="btn btn-sm btn-outline-danger" onclick="window.__dropCourse(${c.id})">Drop</button></td></tr>`).join('') +
        `</tbody></table>`
      : '<div class="text-muted small">You are not enrolled in any courses yet.</div>';

    document.getElementById('st-catalog-courses').innerHTML = `<table class="table table-hover mb-0"><thead><tr><th>Code</th><th>Name</th><th>Dept</th><th>Sem</th><th>Credits</th><th>Action</th></tr></thead><tbody>` +
      data.catalog.map(c => `<tr><td class="tabular-nums fw-semibold">${esc(c.courseCode)}</td><td>${esc(c.courseName)}</td><td>${esc(c.departmentCode)}</td><td class="tabular-nums">${c.semester}</td><td class="tabular-nums">${c.credits}</td><td>${enrolledIds.has(c.id) ? '<span class="small text-success fw-semibold">Enrolled</span>' : `<button class="btn btn-sm btn-gmu-primary" onclick="window.__enrollCourse(${c.id})">Enroll</button>`}</td></tr>`).join('') +
      `</tbody></table>`;
  }

  window.__enrollCourse = async (id) => {
    try { await api(`/api/student/courses/${id}/enroll`, 'POST', {}); showToast('Course enrolled.'); loadCourses(); }
    catch (e) { showToast(e.message, true); }
  };
  window.__dropCourse = async (id) => {
    try { await api(`/api/student/courses/${id}/enroll`, 'DELETE'); showToast('Course dropped.'); loadCourses(); }
    catch (e) { showToast(e.message, true); }
  };

  async function loadFaculty() {
    facultyCache = await api('/api/student/faculty');
    renderFaculty();
  }
  function renderFaculty() {
    const q = (document.getElementById('st-faculty-search').value || '').toLowerCase();
    const list = facultyCache.filter(f => JSON.stringify(f).toLowerCase().includes(q));
    document.getElementById('st-faculty-list').innerHTML = list.map(f =>
      `<div class="col-md-6"><div class="gmu-stat-card campus-interactive-card">
         <div class="fw-bold">${esc(f.name)}</div>
         <div class="small text-muted">${esc(f.designation)} · ${esc(f.departmentCode)}</div>
         <div class="small mt-1">${esc(f.specialization)}</div>
         <div class="small text-muted mt-1">${esc(f.email)} · ${esc(f.phone)}</div>
       </div></div>`).join('');
  }
  document.getElementById('st-faculty-search')?.addEventListener('input', renderFaculty);

  async function loadEvents() {
    const data = await api('/api/student/events');
    const regMap = new Set(data.registrations.filter(r => r.status === 'REGISTERED').map(r => r.eventId));
    document.getElementById('st-events-grid').innerHTML = data.events.map(e => {
      const fillPct = Math.max(4, Math.min(100, Math.round((e.registeredCount / Math.max(1, e.capacity)) * 100)));
      return `<div class="col-md-6"><div class="gmu-stat-card campus-interactive-card h-100 d-flex flex-column justify-content-between">
         <div>
           <div class="fw-bold">${esc(e.title)}</div>
           <div class="small text-muted mb-2">${esc(e.category)} · ${esc(e.eventDate)} · ${esc(e.location)}</div>
           <p class="small mb-2">${esc(e.description)}</p>
         </div>
         <div>
           <div class="progress mb-2" style="height:6px;"><div class="progress-bar" style="width:${fillPct}%; background-color:#C89B3C;"></div></div>
           <div class="d-flex justify-content-between align-items-center">
             <span class="small tabular-nums">${e.registeredCount} / ${e.capacity} Registered</span>
             ${regMap.has(e.id)
               ? `<button class="btn btn-sm btn-outline-danger" onclick="window.__cancelEvent(${e.id})">Cancel</button>`
               : `<button class="btn btn-sm btn-gmu-primary" onclick="window.__regEvent(${e.id})">Register</button>`}
           </div>
         </div>
       </div></div>`;
    }).join('');

    document.getElementById('st-my-registrations').innerHTML = data.registrations.length
      ? `<table class="table mb-0"><thead><tr><th>Event</th><th>Date</th><th>Location</th><th>Status</th><th>Action</th></tr></thead><tbody>` +
        data.registrations.map(r => `<tr><td>${esc(r.eventTitle)}</td><td class="tabular-nums">${esc(r.eventDate)}</td><td>${esc(r.eventLocation)}</td><td><span class="status-label status-${r.status.toLowerCase()}">${esc(r.status)}</span></td><td>${r.status === 'REGISTERED' ? `<button class="btn btn-sm btn-outline-danger" onclick="window.__cancelEvent(${r.eventId})">Cancel</button>` : ''}</td></tr>`).join('') +
        `</tbody></table>`
      : '<div class="text-muted small">No event registrations yet.</div>';
  }
  window.__regEvent = async (id) => {
    try { await api(`/api/student/events/${id}/register`, 'POST', {}); showToast('Registered for event.'); loadEvents(); }
    catch (e) { showToast(e.message, true); }
  };
  window.__cancelEvent = async (id) => {
    try { await api(`/api/student/events/${id}/cancel`, 'POST', {}); showToast('Registration cancelled.'); loadEvents(); }
    catch (e) { showToast(e.message, true); }
  };

  async function loadBookResources() {
    resourcesCache = await api('/api/student/resources');
    populateResourceDropdown();
    const dateInput = document.getElementById('bk-date');
    if (dateInput && !dateInput.value) {
      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      dateInput.value = tomorrow;
    }
  }
  function populateResourceDropdown() {
    const type = document.getElementById('bk-type').value;
    const select = document.getElementById('bk-resource');
    const items = type === 'CLASSROOM' ? resourcesCache.classrooms
      : type === 'LABORATORY' ? resourcesCache.laboratories
      : resourcesCache.equipment;
    select.innerHTML = items.map(i =>
      `<option value="${i.id}">${esc(i.resourceTitle || i.name)} (${esc(i.availabilityStatus)})</option>`
    ).join('');
  }
  document.getElementById('bk-type')?.addEventListener('change', populateResourceDropdown);

  async function checkSlotAvailability() {
    const type = document.getElementById('bk-type')?.value;
    const resourceId = document.getElementById('bk-resource')?.value;
    const date = document.getElementById('bk-date')?.value;
    const startTime = document.getElementById('bk-start')?.value;
    const endTime = document.getElementById('bk-end')?.value;
    const out = document.getElementById('slot-status-text');
    if (!type || !resourceId || !date || !startTime || !endTime || !out) return;
    try {
      const res = await api(`/api/student/bookings/availability?resourceType=${type}&resourceId=${resourceId}&date=${date}&startTime=${startTime}&endTime=${endTime}`);
      out.className = res.available ? 'small fw-semibold text-success' : 'small fw-semibold text-danger';
      out.textContent = res.available ? 'Slot is available.' : 'Slot conflicts with an existing booking.';
    } catch (e) { showToast(e.message, true); }
  }

  document.getElementById('check-slot-btn')?.addEventListener('click', checkSlotAvailability);
  ['bk-type', 'bk-resource', 'bk-date', 'bk-start', 'bk-end'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', checkSlotAvailability);
  });

  document.getElementById('st-booking-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const raw = Object.fromEntries(new FormData(e.target).entries());
    raw.resourceId = Number(raw.resourceId);
    try {
      await api('/api/student/bookings', 'POST', raw);
      showToast('Resource booking request submitted.');
      e.target.reset();
      switchSection('bookings');
    } catch (err) { showToast(err.message, true); }
  });

  async function loadMyBookings() {
    const list = await api('/api/student/bookings');
    document.getElementById('st-bookings-table').innerHTML = list.length
      ? `<table class="table mb-0"><thead><tr><th>Code</th><th>Resource</th><th>Date &amp; Time</th><th>Purpose</th><th>Status</th><th>Action</th></tr></thead><tbody>` +
        list.map(b => `<tr><td class="tabular-nums fw-semibold">${esc(b.bookingCode)}</td><td>${esc(b.resourceType)} · ${esc(b.resourceName)}</td><td class="tabular-nums">${esc(b.bookingDate)} (${esc(b.startTime)}-${esc(b.endTime)})</td><td>${esc(b.purpose)}</td><td><span class="status-label status-${b.status.toLowerCase()}">${esc(b.status)}</span></td><td>${(b.status === 'PENDING' || b.status === 'APPROVED') ? `<button class="btn btn-sm btn-outline-danger" onclick="window.__cancelMyBooking(${b.id})">Cancel</button>` : ''}</td></tr>`).join('') +
        `</tbody></table>`
      : '<div class="text-muted small">No bookings found.</div>';
  }
  window.__cancelMyBooking = async (id) => {
    try { await api(`/api/student/bookings/${id}/cancel`, 'POST', {}); showToast('Booking cancelled.'); loadMyBookings(); }
    catch (e) { showToast(e.message, true); }
  };

  async function loadAnnouncements() {
    const list = await api('/api/student/announcements');
    document.getElementById('st-all-announcements').innerHTML = list.length
      ? list.map(a => `<div class="gmu-stat-card"><div class="d-flex justify-content-between"><strong>${esc(a.title)}</strong><span class="status-label status-${a.priority.toLowerCase()}">${esc(a.priority)}</span></div><p class="small mb-1 mt-1">${esc(a.content)}</p><div class="small text-muted">Posted by ${esc(a.postedByName)}</div></div>`).join('')
      : '<div class="text-muted small">No announcements.</div>';
  }

  const titles = {
    dashboard: 'My Campus Dashboard',
    profile: 'My Profile',
    courses: 'My Courses & Catalog',
    faculty: 'Faculty Directory',
    events: 'Campus Events',
    book: 'Resource Booking',
    bookings: 'My Bookings',
    announcements: 'Announcements',
    settings: 'Portal Settings'
  };

  async function switchSection(sec) {
    document.querySelectorAll('.campus-nav-btn[data-section]').forEach(b => b.classList.toggle('active', b.getAttribute('data-section') === sec));
    document.querySelectorAll('.st-section').forEach(el => el.classList.add('d-none'));
    document.getElementById('st-sec-' + sec)?.classList.remove('d-none');
    document.getElementById('student-topbar-title').textContent = titles[sec] || 'Student Portal';

    if (sec === 'dashboard') await loadDashboard();
    else if (sec === 'courses') await loadCourses();
    else if (sec === 'faculty') await loadFaculty();
    else if (sec === 'events') await loadEvents();
    else if (sec === 'book') await loadBookResources();
    else if (sec === 'bookings') await loadMyBookings();
    else if (sec === 'announcements') await loadAnnouncements();
  }

  document.querySelectorAll('.campus-nav-btn[data-section]').forEach(b => b.addEventListener('click', () => switchSection(b.getAttribute('data-section'))));
  document.querySelectorAll('[data-jump]').forEach(b => b.addEventListener('click', () => switchSection(b.getAttribute('data-jump'))));

  switchSection('dashboard');
})();
