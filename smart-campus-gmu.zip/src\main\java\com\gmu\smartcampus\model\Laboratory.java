package com.gmu.smartcampus.model;

/**
 * Laboratory extending CampusResource (Inheritance + Method Overriding).
 */
public class Laboratory extends CampusResource {

    private String labId;
    private String name;
    private String location;
    private int capacity;
    private String labType;
    private String equipmentSummary;

    @Override
    public String getEntityType() {
        return "LABORATORY";
    }

    @Override
    public String getAuditIdentifier() {
        return labId;
    }

    @Override
    public String getResourceCode() {
        return labId;
    }

    @Override
    public String getResourceTitle() {
        return name + " (" + location + ")";
    }

    @Override
    public String getResourceType() {
        return "LABORATORY";
    }

    @Override
    public String getAvailabilitySummary() {
        return String.format("%s · %s · %d Stations · %s", labId, labType, capacity, availabilityStatus);
    }

    public String getLabId() {
        return labId;
    }

    public void setLabId(String labId) {
        this.labId = labId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getLabType() {
        return labType;
    }

    public void setLabType(String labType) {
        this.labType = labType;
    }

    public String getEquipmentSummary() {
        return equipmentSummary;
    }

    public void setEquipmentSummary(String equipmentSummary) {
        this.equipmentSummary = equipmentSummary;
    }
}
