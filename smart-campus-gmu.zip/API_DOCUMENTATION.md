# REST API Documentation — GM University Smart Campus

All authenticated endpoints use Spring Security session cookies + CSRF protection (`X-XSRF-TOKEN`). Responses follow the generic `ApiResponse<T>` envelope:
```json
{
  "success": true,
  "message": "Operation completed",
  "errorCode": null,
  "data": {},
  "timestamp": "2026-11-21T22:30:00"
}
```

## Public & Auth Endpoints
- `GET /login` — 3-Scene Cinematic Campus Arrival, Interactive Lamp & Login Portal
- `POST /perform-login` — Form login (`username`, `password`, `remember-me`)
- `POST /logout` — Invalidate session & clear cookies
- `GET /api/public/departments` — List university departments
- `POST /api/auth/register` — Register student (`PENDING` approval status, BCrypt hashed)

## Admin Endpoints (`ROLE_ADMIN` required)
- `GET /admin/dashboard` — Admin Portal UI
- `GET /api/admin/stats` — Dashboard KPI counts & Stream aggregations
- `GET /api/admin/students?status=PENDING` — List/filter students
- `PUT /api/admin/students/{id}` / `DELETE /api/admin/students/{id}`
- `POST /api/admin/approvals/students/{id}/approve` — Approve registration & record audit trail
- `POST /api/admin/approvals/students/{id}/reject` — Reject registration with reason
- `GET /api/admin/approvals/history` — Recent approval decisions
- `GET/POST/PUT/DELETE /api/admin/faculty` — Faculty CRUD
- `GET/POST/PUT/DELETE /api/admin/courses` & `POST /api/admin/courses/{id}/assign-faculty`
- `GET/POST/PUT/DELETE /api/admin/classrooms`
- `GET/POST/PUT/DELETE /api/admin/laboratories`
- `GET/POST/PUT/DELETE /api/admin/equipment`
- `GET/POST/PUT/DELETE /api/admin/events` & `GET /api/admin/events/{id}/registrations`
- `GET/POST /api/admin/bookings` & `POST /api/admin/bookings/{id}/{approve|reject|cancel}`
- `GET/POST/DELETE /api/admin/announcements`
- `GET /api/admin/reports/export/{students|faculty|bookings|events|equipment}` — Download CSV

## Student Endpoints (`ROLE_STUDENT` required)
- `GET /student/dashboard` — Student Portal UI
- `GET /api/student/profile` — Authenticated student's own profile
- `GET /api/student/courses`, `POST /api/student/courses/{id}/enroll`, `DELETE /api/student/courses/{id}/enroll`
- `GET /api/student/faculty` — Searchable faculty directory
- `GET /api/student/events`, `POST /api/student/events/{id}/register`, `POST /api/student/events/{id}/cancel`
- `GET /api/student/resources` — Bookable classrooms, labs, equipment
- `GET /api/student/bookings/availability` — Real-time slot conflict check
- `GET/POST /api/student/bookings`, `POST /api/student/bookings/{id}/cancel`
- `GET /api/student/announcements`
