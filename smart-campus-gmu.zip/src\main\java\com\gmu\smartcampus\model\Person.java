package com.gmu.smartcampus.model;

import java.time.LocalDateTime;

/**
 * Abstract Person superclass shared by Student and Faculty domain models.
 */
public abstract class Person extends BaseEntity {

    protected String name;
    protected Long departmentId;
    protected String departmentCode;
    protected String departmentName;
    protected String phone;

    protected Person() {
        super();
    }

    protected Person(Long id, String name, Long departmentId, String phone, LocalDateTime createdAt) {
        super(id, createdAt);
        this.name = name;
        this.departmentId = departmentId;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Polymorphic profile summary overridden by Student and Faculty subclasses.
     */
    public abstract String getAcademicSummary();
}
