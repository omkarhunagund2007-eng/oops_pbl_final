@echo off
setlocal enabledelayedexpansion
title GM University - Smart Campus Launcher
echo =========================================================
echo    GM UNIVERSITY — SMART CAMPUS MANAGEMENT SYSTEM
echo =========================================================

REM Detect Maven executable
where mvn >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set "MVN_EXEC=mvn"
) else if exist "%USERPROFILE%\.maven\apache-maven-3.10.0\bin\mvn.cmd" (
    set "MVN_EXEC=%USERPROFILE%\.maven\apache-maven-3.10.0\bin\mvn.cmd"
) else (
    echo [ERROR] Maven (mvn) was not found in PATH or in %USERPROFILE%\.maven\apache-maven-3.10.0\bin.
    echo Please ensure Apache Maven is installed.
    pause
    exit /b 1
)

echo.
echo [1/2] Running automated test verification suite (JUnit 5 + Spring Security)...
call "%MVN_EXEC%" test
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Automated tests failed. Please review test output above.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [2/2] Launching GM University Smart Campus on http://localhost:8080 ...
echo [INFO] Application is starting in zero-setup standalone mode with full demo data.
echo [INFO] Open your browser at: http://localhost:8080
echo.
call "%MVN_EXEC%" spring-boot:run "-Dspring-boot.run.profiles=standalone"
pause
