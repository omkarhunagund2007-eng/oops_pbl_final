package com.gmu.smartcampus.model;

public class Course extends BaseEntity {
    private String courseCode;
    private String courseName;
    private Long departmentId;
    private String departmentCode;
    private String departmentName;
    private int semester;
    private int credits;
    private String description;
    private boolean active = true;
    private String assignedFacultyName;
    private Long assignedFacultyId;

    @Override
    public String getEntityType() {
        return "COURSE";
    }

    @Override
    public String getAuditIdentifier() {
        return courseCode;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getAssignedFacultyName() {
        return assignedFacultyName;
    }

    public void setAssignedFacultyName(String assignedFacultyName) {
        this.assignedFacultyName = assignedFacultyName;
    }

    public Long getAssignedFacultyId() {
        return assignedFacultyId;
    }

    public void setAssignedFacultyId(Long assignedFacultyId) {
        this.assignedFacultyId = assignedFacultyId;
    }
}
