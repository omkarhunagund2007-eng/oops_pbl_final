package com.gmu.smartcampus.exception;

import org.springframework.http.HttpStatus;

public class UnauthorizedActionException extends CampusException {
    public UnauthorizedActionException(String message) {
        super(message, HttpStatus.FORBIDDEN, "UNAUTHORIZED_ACTION");
    }
}
