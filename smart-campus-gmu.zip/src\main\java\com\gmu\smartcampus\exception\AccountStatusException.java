package com.gmu.smartcampus.exception;

import org.springframework.http.HttpStatus;

public class AccountStatusException extends CampusException {
    public AccountStatusException(String message) {
        super(message, HttpStatus.FORBIDDEN, "ACCOUNT_STATUS_BLOCKED");
    }
}
