package com.gmu.smartcampus.exception;

import org.springframework.http.HttpStatus;

public class ResourceNotFoundException extends CampusException {
    public ResourceNotFoundException(String message) {
        super(message, HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND");
    }
}
