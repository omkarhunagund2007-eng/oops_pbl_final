package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Classroom;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class ClassroomRepository {

    private final JdbcTemplate jdbcTemplate;

    public ClassroomRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Classroom> rowMapper = (rs, rowNum) -> {
        Classroom c = new Classroom();
        c.setId(rs.getLong("id"));
        c.setRoomId(rs.getString("room_id"));
        c.setBuilding(rs.getString("building"));
        c.setRoomNumber(rs.getString("room_number"));
        c.setCapacity(rs.getInt("capacity"));
        c.setAvailabilityStatus(rs.getString("availability_status"));
        c.setEquipmentSummary(rs.getString("equipment_summary"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) c.setCreatedAt(ts.toLocalDateTime());
        return c;
    };

    public List<Classroom> findAll() {
        return jdbcTemplate.query("SELECT * FROM classrooms ORDER BY room_id ASC", rowMapper);
    }

    public Optional<Classroom> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM classrooms WHERE id = ?", rowMapper, id).stream().findFirst();
    }

    public boolean existsByRoomId(String roomId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM classrooms WHERE LOWER(room_id) = LOWER(?)", Integer.class, roomId);
        return count != null && count > 0;
    }

    public Long save(Classroom classroom) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO classrooms (room_id, building, room_number, capacity, availability_status, equipment_summary) VALUES (?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, classroom.getRoomId());
            ps.setString(2, classroom.getBuilding());
            ps.setString(3, classroom.getRoomNumber());
            ps.setInt(4, classroom.getCapacity());
            ps.setString(5, classroom.getAvailabilityStatus());
            ps.setString(6, classroom.getEquipmentSummary());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Classroom classroom) {
        return jdbcTemplate.update(
                "UPDATE classrooms SET building = ?, room_number = ?, capacity = ?, availability_status = ?, equipment_summary = ? WHERE id = ?",
                classroom.getBuilding(), classroom.getRoomNumber(), classroom.getCapacity(),
                classroom.getAvailabilityStatus(), classroom.getEquipmentSummary(), classroom.getId());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM classrooms WHERE id = ?", id);
    }
}
