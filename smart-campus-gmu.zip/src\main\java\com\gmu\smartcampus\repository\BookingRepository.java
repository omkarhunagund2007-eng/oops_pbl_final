package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.ResourceBooking;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public class BookingRepository {

    private final JdbcTemplate jdbcTemplate;

    public BookingRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<ResourceBooking> rowMapper = (rs, rowNum) -> {
        ResourceBooking b = new ResourceBooking();
        b.setId(rs.getLong("id"));
        b.setBookingCode(rs.getString("booking_code"));
        b.setResourceType(rs.getString("resource_type"));
        b.setResourceId(rs.getLong("resource_id"));
        b.setResourceName(rs.getString("resource_name"));
        b.setRequestedByUserId(rs.getLong("requested_by_user_id"));
        b.setRequesterName(rs.getString("requester_name"));
        Date bd = rs.getDate("booking_date");
        if (bd != null) b.setBookingDate(bd.toLocalDate());
        Time st = rs.getTime("start_time");
        if (st != null) b.setStartTime(st.toLocalTime());
        Time et = rs.getTime("end_time");
        if (et != null) b.setEndTime(et.toLocalTime());
        b.setPurpose(rs.getString("purpose"));
        b.setStatus(rs.getString("status"));
        long adm = rs.getLong("reviewed_by_admin_id");
        if (!rs.wasNull()) b.setReviewedByAdminId(adm);
        b.setReviewNote(rs.getString("review_note"));
        Timestamp created = rs.getTimestamp("created_at");
        if (created != null) b.setCreatedAt(created.toLocalDateTime());
        Timestamp updated = rs.getTimestamp("updated_at");
        if (updated != null) b.setUpdatedAt(updated.toLocalDateTime());
        return b;
    };

    public List<ResourceBooking> findAll() {
        return jdbcTemplate.query("SELECT * FROM resource_bookings ORDER BY created_at DESC", rowMapper);
    }

    public List<ResourceBooking> findByUserId(Long userId) {
        return jdbcTemplate.query(
                "SELECT * FROM resource_bookings WHERE requested_by_user_id = ? ORDER BY booking_date DESC, start_time DESC",
                rowMapper, userId);
    }

    public Optional<ResourceBooking> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM resource_bookings WHERE id = ?", rowMapper, id).stream().findFirst();
    }

    /**
     * Checks for overlapping active (PENDING or APPROVED) bookings on the exact same resource and date.
     * Interval overlap rule: existing.start_time < requestedEnd AND existing.end_time > requestedStart.
     */
    public boolean existsOverlappingBooking(String resourceType, Long resourceId, LocalDate date,
                                            LocalTime startTime, LocalTime endTime) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM resource_bookings " +
                "WHERE resource_type = ? AND resource_id = ? AND booking_date = ? " +
                "AND status IN ('PENDING', 'APPROVED') " +
                "AND start_time < ? AND end_time > ?",
                Integer.class,
                resourceType, resourceId, Date.valueOf(date),
                Time.valueOf(endTime), Time.valueOf(startTime));
        return count != null && count > 0;
    }

    public Long save(ResourceBooking booking) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO resource_bookings (booking_code, resource_type, resource_id, resource_name, requested_by_user_id, requester_name, booking_date, start_time, end_time, purpose, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, booking.getBookingCode());
            ps.setString(2, booking.getResourceType());
            ps.setLong(3, booking.getResourceId());
            ps.setString(4, booking.getResourceName());
            ps.setLong(5, booking.getRequestedByUserId());
            ps.setString(6, booking.getRequesterName());
            ps.setDate(7, Date.valueOf(booking.getBookingDate()));
            ps.setTime(8, Time.valueOf(booking.getStartTime()));
            ps.setTime(9, Time.valueOf(booking.getEndTime()));
            ps.setString(10, booking.getPurpose());
            ps.setString(11, booking.getStatus());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int updateReviewStatus(Long id, String status, Long adminUserId, String note) {
        return jdbcTemplate.update(
                "UPDATE resource_bookings SET status = ?, reviewed_by_admin_id = ?, review_note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                status, adminUserId, note, id);
    }

    public int cancelById(Long id) {
        return jdbcTemplate.update(
                "UPDATE resource_bookings SET status = 'CANCELLED', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                id);
    }
}
