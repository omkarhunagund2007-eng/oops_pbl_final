package com.gmu.smartcampus.model;

public class Announcement extends BaseEntity {
    private String title;
    private String content;
    private String audience; // ALL, STUDENTS, FACULTY
    private String priority; // NORMAL, IMPORTANT, URGENT
    private Long postedBy;
    private String postedByName;

    @Override
    public String getEntityType() {
        return "ANNOUNCEMENT";
    }

    @Override
    public String getAuditIdentifier() {
        return "ANN-" + id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public Long getPostedBy() {
        return postedBy;
    }

    public void setPostedBy(Long postedBy) {
        this.postedBy = postedBy;
    }

    public String getPostedByName() {
        return postedByName;
    }

    public void setPostedByName(String postedByName) {
        this.postedByName = postedByName;
    }
}
