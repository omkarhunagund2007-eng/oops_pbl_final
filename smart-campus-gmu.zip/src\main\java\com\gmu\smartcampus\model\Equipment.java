package com.gmu.smartcampus.model;

import java.time.LocalDate;

/**
 * Equipment extending CampusResource with stock-aware booking logic.
 */
public class Equipment extends CampusResource {

    private String equipmentId;
    private String name;
    private String category;
    private int quantity;
    private int availableQuantity;
    private String itemCondition;
    private String location;
    private LocalDate purchaseDate;

    @Override
    public String getEntityType() {
        return "EQUIPMENT";
    }

    @Override
    public String getAuditIdentifier() {
        return equipmentId;
    }

    @Override
    public String getResourceCode() {
        return equipmentId;
    }

    @Override
    public String getResourceTitle() {
        return name + " (" + category + ")";
    }

    @Override
    public String getResourceType() {
        return "EQUIPMENT";
    }

    @Override
    public boolean isCurrentlyBookable() {
        return availableQuantity > 0 && !"DAMAGED".equalsIgnoreCase(itemCondition);
    }

    @Override
    public String getAvailabilitySummary() {
        return String.format("%s · %d/%d Available · Condition: %s",
                name, availableQuantity, quantity, itemCondition);
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(int availableQuantity) {
        this.availableQuantity = availableQuantity;
        this.availabilityStatus = availableQuantity > 0 ? "AVAILABLE" : "UNAVAILABLE";
    }

    public String getItemCondition() {
        return itemCondition;
    }

    public void setItemCondition(String itemCondition) {
        this.itemCondition = itemCondition;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }
}
