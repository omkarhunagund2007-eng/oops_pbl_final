﻿Write-Host "=========================================================" -ForegroundColor Yellow
Write-Host "   GM UNIVERSITY — SMART CAMPUS MANAGEMENT SYSTEM       " -ForegroundColor Yellow
Write-Host "=========================================================" -ForegroundColor Yellow

$mvnCmd = "mvn"
if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
    $fallbackMvn = "$env:USERPROFILE\.maven\apache-maven-3.10.0\bin\mvn.cmd"
    if (Test-Path $fallbackMvn) {
        $mvnCmd = $fallbackMvn
    } else {
        Write-Error "Maven (mvn) not found in PATH or at $fallbackMvn. Please install Apache Maven 3.8+."
        exit 1
    }
}

Write-Host "`n[1/2] Running automated test verification suite..." -ForegroundColor Cyan
& $mvnCmd test
if ($LASTEXITCODE -ne 0) {
    Write-Error "Tests failed. Fix configuration or inspect logs above."
    exit $LASTEXITCODE
}

Write-Host "`n[2/2] Launching GM University Smart Campus on http://localhost:8080 ..." -ForegroundColor Green
Write-Host "[INFO] Open your browser at: http://localhost:8080" -ForegroundColor Cyan
& $mvnCmd spring-boot:run "-Dspring-boot.run.profiles=standalone"
