package com.gmu.smartcampus.security;

import com.gmu.smartcampus.model.Student;
import com.gmu.smartcampus.model.UserAccount;
import com.gmu.smartcampus.repository.StudentRepository;
import com.gmu.smartcampus.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;

    public CustomUserDetailsService(UserRepository userRepository, StudentRepository studentRepository) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String identifier) throws UsernameNotFoundException {
        Optional<UserAccount> userOpt = userRepository.findByUsername(identifier.trim());
        if (userOpt.isEmpty()) {
            // Also allow login using Student ID (e.g., GMU25CS001)
            Optional<Student> studentOpt = studentRepository.findByStudentCode(identifier.trim());
            if (studentOpt.isPresent()) {
                userOpt = userRepository.findById(studentOpt.get().getUserId());
            }
        }
        UserAccount user = userOpt.orElseThrow(
                () -> new UsernameNotFoundException("Account not found for identifier: " + identifier));
        return new CustomUserDetails(user);
    }
}
