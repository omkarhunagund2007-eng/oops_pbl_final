package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Student> rowMapper = (rs, rowNum) -> {
        Student s = new Student();
        s.setId(rs.getLong("id"));
        s.setUserId(rs.getLong("user_id"));
        s.setUsername(rs.getString("username"));
        s.setStudentId(rs.getString("student_id"));
        s.setName(rs.getString("name"));
        s.setDepartmentId(rs.getLong("department_id"));
        s.setDepartmentCode(rs.getString("dept_code"));
        s.setDepartmentName(rs.getString("dept_name"));
        s.setBranch(rs.getString("branch"));
        s.setSemester(rs.getInt("semester"));
        s.setSection(rs.getString("section"));
        s.setPhone(rs.getString("phone"));
        s.setAdmissionYear(rs.getInt("admission_year"));
        s.setAccountStatus(rs.getString("account_status"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) s.setCreatedAt(ts.toLocalDateTime());
        return s;
    };

    private static final String BASE_SELECT =
            "SELECT s.*, u.username, d.code AS dept_code, d.name AS dept_name " +
            "FROM students s " +
            "JOIN users u ON s.user_id = u.id " +
            "JOIN departments d ON s.department_id = d.id ";

    public List<Student> findAll() {
        return jdbcTemplate.query(BASE_SELECT + "ORDER BY s.created_at DESC", rowMapper);
    }

    public List<Student> findByStatus(String status) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE s.account_status = ? ORDER BY s.created_at DESC",
                rowMapper, status);
    }

    public Optional<Student> findById(Long id) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE s.id = ?", rowMapper, id).stream().findFirst();
    }

    public Optional<Student> findByUserId(Long userId) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE s.user_id = ?", rowMapper, userId).stream().findFirst();
    }

    public Optional<Student> findByStudentCode(String studentId) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE s.student_id = ?", rowMapper, studentId).stream().findFirst();
    }

    public boolean existsByStudentId(String studentId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM students WHERE LOWER(student_id) = LOWER(?)", Integer.class, studentId);
        return count != null && count > 0;
    }

    public Long save(Student student) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO students (user_id, student_id, name, department_id, branch, semester, section, phone, admission_year, account_status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setLong(1, student.getUserId());
            ps.setString(2, student.getStudentId());
            ps.setString(3, student.getName());
            ps.setLong(4, student.getDepartmentId());
            ps.setString(5, student.getBranch());
            ps.setInt(6, student.getSemester());
            ps.setString(7, student.getSection());
            ps.setString(8, student.getPhone());
            ps.setInt(9, student.getAdmissionYear());
            ps.setString(10, student.getAccountStatus());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Student student) {
        return jdbcTemplate.update(
                "UPDATE students SET name = ?, department_id = ?, branch = ?, semester = ?, section = ?, phone = ?, admission_year = ?, account_status = ? WHERE id = ?",
                student.getName(), student.getDepartmentId(), student.getBranch(),
                student.getSemester(), student.getSection(), student.getPhone(),
                student.getAdmissionYear(), student.getAccountStatus(), student.getId());
    }

    public int updateStatus(Long id, String status) {
        return jdbcTemplate.update("UPDATE students SET account_status = ? WHERE id = ?", status, id);
    }

    public int deleteById(Long id) {
        Optional<Student> existing = findById(id);
        if (existing.isEmpty()) return 0;
        return jdbcTemplate.update("DELETE FROM users WHERE id = ?", existing.get().getUserId());
    }
}
