package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.UserAccount;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<UserAccount> rowMapper = (rs, rowNum) -> {
        UserAccount u = new UserAccount();
        u.setId(rs.getLong("id"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setRole(rs.getString("role"));
        u.setAccountStatus(rs.getString("account_status"));
        u.setThemePreference(rs.getString("theme_preference"));
        Timestamp created = rs.getTimestamp("created_at");
        if (created != null) u.setCreatedAt(created.toLocalDateTime());
        Timestamp updated = rs.getTimestamp("updated_at");
        if (updated != null) u.setUpdatedAt(updated.toLocalDateTime());
        return u;
    };

    public Optional<UserAccount> findByUsername(String username) {
        List<UserAccount> list = jdbcTemplate.query(
                "SELECT * FROM users WHERE username = ?", rowMapper, username);
        return list.stream().findFirst();
    }

    public Optional<UserAccount> findById(Long id) {
        List<UserAccount> list = jdbcTemplate.query(
                "SELECT * FROM users WHERE id = ?", rowMapper, id);
        return list.stream().findFirst();
    }

    public boolean existsByUsername(String username) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM users WHERE LOWER(username) = LOWER(?)", Integer.class, username);
        return count != null && count > 0;
    }

    public Long save(UserAccount user) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users (username, password_hash, full_name, email, role, account_status, theme_preference) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPasswordHash());
            ps.setString(3, user.getFullName());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getRole());
            ps.setString(6, user.getAccountStatus());
            ps.setString(7, user.getThemePreference() != null ? user.getThemePreference() : "light");
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public void updateAccountStatus(Long userId, String status) {
        jdbcTemplate.update(
                "UPDATE users SET account_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                status, userId);
    }

    public void updateThemePreference(Long userId, String theme) {
        jdbcTemplate.update(
                "UPDATE users SET theme_preference = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                theme, userId);
    }

    public void updatePasswordHash(Long userId, String newHash) {
        jdbcTemplate.update(
                "UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                newHash, userId);
    }
}
