package com.gmu.smartcampus.config;

import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Initializes the secure BCrypt-hashed Administrator account, sample students (Approved/Pending/Rejected),
 * sample events, bookings, and announcements on first run.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final ClassroomRepository classroomRepository;
    private final EventRepository eventRepository;
    private final BookingRepository bookingRepository;
    private final AnnouncementRepository announcementRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${campus.admin.username:admin}")
    private String adminUsername;

    @Value("${campus.admin.password:Admin@GMU2026}")
    private String adminPassword;

    @Value("${campus.admin.fullname:Dr. Meenakshi Deshmukh}")
    private String adminFullName;

    @Value("${campus.admin.email:registrar@gmu.edu.in}")
    private String adminEmail;

    public DataInitializer(UserRepository userRepository,
                           DepartmentRepository departmentRepository,
                           StudentRepository studentRepository,
                           CourseRepository courseRepository,
                           ClassroomRepository classroomRepository,
                           EventRepository eventRepository,
                           BookingRepository bookingRepository,
                           AnnouncementRepository announcementRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
        this.classroomRepository = classroomRepository;
        this.eventRepository = eventRepository;
        this.bookingRepository = bookingRepository;
        this.announcementRepository = announcementRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        Long adminUserId = ensureAdminAccount();
        Long cseDeptId = departmentRepository.findByCode("CSE").map(Department::getId).orElse(1L);
        Long aimlDeptId = departmentRepository.findByCode("AIML").map(Department::getId).orElse(cseDeptId);

        // Approved sample students
        ensureStudent("aarav.patel", "GMU25CS001", "Aarav Patel", cseDeptId, "Computer Science & Engg", 3, "A", "9880112201", 2025, "APPROVED");
        ensureStudent("diya.kulkarni", "GMU25CS002", "Diya Kulkarni", cseDeptId, "Computer Science & Engg", 3, "A", "9880112202", 2025, "APPROVED");
        ensureStudent("rohan.verma", "GMU25AI003", "Rohan Verma", aimlDeptId, "AI & Machine Learning", 3, "B", "9880112203", 2025, "APPROVED");

        // Pending student registration requests for Admin Approval Queue
        ensureStudent("meera.nair", "GMU25CS014", "Meera Nair", cseDeptId, "Computer Science & Engg", 3, "B", "9880112214", 2025, "PENDING");
        ensureStudent("vikram.singh", "GMU25AI019", "Vikram Singh", aimlDeptId, "AI & Machine Learning", 3, "A", "9880112219", 2025, "PENDING");

        // Rejected sample student
        ensureStudent("test.rejected", "GMU25CS099", "Sanjay Rao", cseDeptId, "Computer Science & Engg", 3, "C", "9880112299", 2025, "REJECTED");

        seedEventsAndAnnouncements(adminUserId);
        seedSampleBookings();
    }

    private Long ensureAdminAccount() {
        return userRepository.findByUsername(adminUsername).map(UserAccount::getId).orElseGet(() -> {
            UserAccount admin = new UserAccount();
            admin.setUsername(adminUsername);
            admin.setPasswordHash(passwordEncoder.encode(adminPassword));
            admin.setFullName(adminFullName);
            admin.setEmail(adminEmail);
            admin.setRole("ADMIN");
            admin.setAccountStatus("APPROVED");
            admin.setThemePreference("light");
            return userRepository.save(admin);
        });
    }

    private void ensureStudent(String username, String studentCode, String fullName,
                               Long deptId, String branch, int sem, String section,
                               String phone, int year, String status) {
        if (userRepository.existsByUsername(username) || studentRepository.existsByStudentId(studentCode)) {
            return;
        }
        UserAccount user = new UserAccount();
        user.setUsername(username);
        user.setPasswordHash(passwordEncoder.encode("Student@2026"));
        user.setFullName(fullName);
        user.setEmail(username + "@student.gmu.edu.in");
        user.setRole("STUDENT");
        user.setAccountStatus(status);
        user.setThemePreference("light");
        Long userId = userRepository.save(user);

        Student student = new Student();
        student.setUserId(userId);
        student.setStudentId(studentCode);
        student.setName(fullName);
        student.setDepartmentId(deptId);
        student.setBranch(branch);
        student.setSemester(sem);
        student.setSection(section);
        student.setPhone(phone);
        student.setAdmissionYear(year);
        student.setAccountStatus(status);
        Long studentDbId = studentRepository.save(student);

        if ("APPROVED".equals(status)) {
            courseRepository.findAll().stream()
                    .filter(c -> c.getSemester() == sem)
                    .limit(3)
                    .forEach(c -> courseRepository.enrollStudent(studentDbId, c.getId()));
        }
    }

    private void seedEventsAndAnnouncements(Long adminUserId) {
        if (eventRepository.findAll().isEmpty()) {
            CampusEvent e1 = new CampusEvent();
            e1.setTitle("Annual Java & Spring Boot Innovation Hackathon");
            e1.setCategory("Technical Symposium");
            e1.setDescription("24-hour campus coding marathon building scalable university microservices using Java 21, Spring Boot, and JDBC.");
            e1.setEventDate(LocalDate.now().plusDays(7));
            e1.setStartTime(LocalTime.of(9, 0));
            e1.setEndTime(LocalTime.of(17, 30));
            e1.setLocation("Turing Block Auditorium");
            e1.setCapacity(120);
            e1.setStatus("PUBLISHED");
            e1.setCreatedBy(adminUserId);
            eventRepository.save(e1);

            CampusEvent e2 = new CampusEvent();
            e2.setTitle("AI & Robotics Research Colloquium 2026");
            e2.setCategory("Research Seminar");
            e2.setDescription("Keynote presentations from GM University faculty and industry researchers on autonomous systems and edge AI.");
            e2.setEventDate(LocalDate.now().plusDays(14));
            e2.setStartTime(LocalTime.of(10, 30));
            e2.setEndTime(LocalTime.of(15, 0));
            e2.setLocation("Maxwell Seminar Hall 104");
            e2.setCapacity(80);
            e2.setStatus("PUBLISHED");
            e2.setCreatedBy(adminUserId);
            eventRepository.save(e2);
        }

        if (announcementRepository.findAll().isEmpty()) {
            Announcement a1 = new Announcement();
            a1.setTitle("Semester 3 OOPS PBL (UE25CS2303) Demonstration Schedule");
            a1.setContent("Final viva and working software demonstrations for UE25CS2303 Smart Campus projects will take place in Turing Block Lab 01 next week.");
            a1.setAudience("STUDENTS");
            a1.setPriority("IMPORTANT");
            a1.setPostedBy(adminUserId);
            announcementRepository.save(a1);

            Announcement a2 = new Announcement();
            a2.setTitle("Central Laboratory Extended Evening Hours");
            a2.setContent("OOPS & Enterprise Java Lab and NVIDIA Deep Learning Studio are open until 8:30 PM on weekdays via advance Resource Booking.");
            a2.setAudience("ALL");
            a2.setPriority("NORMAL");
            a2.setPostedBy(adminUserId);
            announcementRepository.save(a2);
        }
    }

    private void seedSampleBookings() {
        if (!bookingRepository.findAll().isEmpty()) return;
        userRepository.findByUsername("aarav.patel").ifPresent(studentUser ->
            classroomRepository.findAll().stream().findFirst().ifPresent(room -> {
                ResourceBooking b = new ResourceBooking();
                b.setBookingCode("BK-GMU-1001");
                b.setResourceType("CLASSROOM");
                b.setResourceId(room.getId());
                b.setResourceName(room.getResourceTitle());
                b.setRequestedByUserId(studentUser.getId());
                b.setRequesterName(studentUser.getFullName());
                b.setBookingDate(LocalDate.now().plusDays(2));
                b.setStartTime(LocalTime.of(14, 0));
                b.setEndTime(LocalTime.of(16, 0));
                b.setPurpose("UE25CS2303 PBL Team Practice Session");
                b.setStatus("APPROVED");
                bookingRepository.save(b);
            })
        );
    }
}
