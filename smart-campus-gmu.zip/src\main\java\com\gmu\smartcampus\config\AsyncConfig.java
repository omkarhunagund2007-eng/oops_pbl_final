package com.gmu.smartcampus.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class AsyncConfig {

    /**
     * Thread pool demonstrating ExecutorService multithreading for concurrent booking operations.
     */
    @Bean(name = "bookingExecutorService", destroyMethod = "shutdown")
    public ExecutorService bookingExecutorService() {
        return Executors.newFixedThreadPool(8);
    }
}
