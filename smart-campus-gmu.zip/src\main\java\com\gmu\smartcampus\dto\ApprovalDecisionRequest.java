package com.gmu.smartcampus.dto;

public class ApprovalDecisionRequest {
    private String reason;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
