package com.gmu.smartcampus.service;

import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Demonstrates Java File I/O (java.nio.file, BufferedWriter) for CSV report generation and export.
 */
@Service
public class CsvExportService {

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;
    private final BookingRepository bookingRepository;
    private final EventRepository eventRepository;
    private final EquipmentRepository equipmentRepository;

    @Value("${campus.export.dir:./exports}")
    private String exportDirectory;

    public CsvExportService(StudentRepository studentRepository,
                            FacultyRepository facultyRepository,
                            BookingRepository bookingRepository,
                            EventRepository eventRepository,
                            EquipmentRepository equipmentRepository) {
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
        this.bookingRepository = bookingRepository;
        this.eventRepository = eventRepository;
        this.equipmentRepository = equipmentRepository;
    }

    public String exportReportCsv(String reportType) throws IOException {
        StringWriter sw = new StringWriter();
        try (BufferedWriter writer = new BufferedWriter(sw)) {
            switch (reportType.toLowerCase()) {
                case "students" -> writeStudentsCsv(writer, studentRepository.findAll());
                case "faculty" -> writeFacultyCsv(writer, facultyRepository.findAll());
                case "bookings" -> writeBookingsCsv(writer, bookingRepository.findAll());
                case "events" -> writeEventsCsv(writer, eventRepository.findAll());
                case "equipment" -> writeEquipmentCsv(writer, equipmentRepository.findAll());
                default -> throw new IllegalArgumentException("Unknown report export type: " + reportType);
            }
            writer.flush();
        }
        String csv = sw.toString();
        persistCsvArchive(reportType.toLowerCase(), csv);
        return csv;
    }

    private void persistCsvArchive(String type, String csvContent) throws IOException {
        Path dir = Paths.get(exportDirectory).toAbsolutePath().normalize();
        Files.createDirectories(dir);
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path target = dir.resolve("gmu_" + type + "_" + stamp + ".csv").normalize();
        if (!target.startsWith(dir)) {
            throw new SecurityException("Invalid export file path.");
        }
        Files.writeString(target, csvContent, StandardCharsets.UTF_8);
    }

    private void writeStudentsCsv(BufferedWriter w, List<Student> students) throws IOException {
        w.write("Student ID,Name,Username,Department,Branch,Semester,Section,Phone,Admission Year,Status\n");
        for (Student s : students) {
            w.write(String.join(",",
                    esc(s.getStudentId()), esc(s.getName()), esc(s.getUsername()),
                    esc(s.getDepartmentCode()), esc(s.getBranch()),
                    String.valueOf(s.getSemester()), esc(s.getSection()),
                    esc(s.getPhone()), String.valueOf(s.getAdmissionYear()),
                    esc(s.getAccountStatus())));
            w.newLine();
        }
    }

    private void writeFacultyCsv(BufferedWriter w, List<Faculty> list) throws IOException {
        w.write("Faculty ID,Name,Department,Designation,Email,Phone,Specialization,Joining Date\n");
        for (Faculty f : list) {
            w.write(String.join(",",
                    esc(f.getFacultyId()), esc(f.getName()), esc(f.getDepartmentCode()),
                    esc(f.getDesignation()), esc(f.getEmail()), esc(f.getPhone()),
                    esc(f.getSpecialization()), String.valueOf(f.getJoiningDate())));
            w.newLine();
        }
    }

    private void writeBookingsCsv(BufferedWriter w, List<ResourceBooking> list) throws IOException {
        w.write("Booking Code,Resource Type,Resource Name,Requester,Date,Start Time,End Time,Purpose,Status\n");
        for (ResourceBooking b : list) {
            w.write(String.join(",",
                    esc(b.getBookingCode()), esc(b.getResourceType()), esc(b.getResourceName()),
                    esc(b.getRequesterName()), String.valueOf(b.getBookingDate()),
                    String.valueOf(b.getStartTime()), String.valueOf(b.getEndTime()),
                    esc(b.getPurpose()), esc(b.getStatus())));
            w.newLine();
        }
    }

    private void writeEventsCsv(BufferedWriter w, List<CampusEvent> list) throws IOException {
        w.write("Event ID,Title,Category,Date,Start,End,Location,Registered,Capacity,Status\n");
        for (CampusEvent e : list) {
            w.write(String.join(",",
                    String.valueOf(e.getId()), esc(e.getTitle()), esc(e.getCategory()),
                    String.valueOf(e.getEventDate()), String.valueOf(e.getStartTime()), String.valueOf(e.getEndTime()),
                    esc(e.getLocation()), String.valueOf(e.getRegisteredCount()),
                    String.valueOf(e.getCapacity()), esc(e.getStatus())));
            w.newLine();
        }
    }

    private void writeEquipmentCsv(BufferedWriter w, List<Equipment> list) throws IOException {
        w.write("Equipment ID,Name,Category,Total Qty,Available Qty,Condition,Location,Purchase Date\n");
        for (Equipment eq : list) {
            w.write(String.join(",",
                    esc(eq.getEquipmentId()), esc(eq.getName()), esc(eq.getCategory()),
                    String.valueOf(eq.getQuantity()), String.valueOf(eq.getAvailableQuantity()),
                    esc(eq.getItemCondition()), esc(eq.getLocation()), String.valueOf(eq.getPurchaseDate())));
            w.newLine();
        }
    }

    // Neutralizes CSV formula injection and escapes quotes cleanly
    private String esc(String value) {
        if (value == null) return "";
        String safe = value;
        if (!safe.isEmpty() && ("=+-@".indexOf(safe.charAt(0)) >= 0)) {
            safe = "'" + safe;
        }
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }
}
