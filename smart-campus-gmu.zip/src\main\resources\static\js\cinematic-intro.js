(function () {
  const scene1 = document.getElementById('scene-1');
  const scene2 = document.getElementById('scene-2');
  const scene3 = document.getElementById('scene-3');
  const lampRig = document.getElementById('lamp-rig');
  const pullHit = document.getElementById('pull-chain-hit');
  const pullLinks = document.getElementById('pull-chain-links');
  const lampHint = document.getElementById('lamp-hint');
  const enterBtn = document.getElementById('enter-portal-btn');

  let currentScene = 1;
  let lampLit = false;
  let dragging = false;
  let startY = 0;

  // Apply persisted theme & reduced-motion preference
  const savedTheme = localStorage.getItem('gmu-theme') || 'light';
  if (savedTheme === 'dark') document.documentElement.classList.add('dark');

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || localStorage.getItem('gmu-reduced-motion') === 'true') {
    document.body.classList.add('reduced-motion');
  }

  function showScene(num) {
    currentScene = num;
    [scene1, scene2, scene3].forEach((el, idx) => {
      if (!el) return;
      el.classList.toggle('active', idx + 1 === num);
    });
    document.querySelectorAll('[data-goto-scene]').forEach(btn => {
      btn.classList.toggle('active', Number(btn.getAttribute('data-goto-scene')) === num);
    });
  }

  // If returning with login error or logout message, jump straight to Scene 3
  const hasServerNotice = document.getElementById('auth-server-alert');
  if (hasServerNotice) {
    lampLit = true;
    if (scene2) scene2.classList.add('lamp-lit');
    showScene(3);
  } else {
    // Auto-advance Scene 1 -> Scene 2 after campus arrival animation
    setTimeout(() => {
      if (currentScene === 1) showScene(2);
    }, 4500);
  }

  document.getElementById('to-lamp-btn')?.addEventListener('click', () => showScene(2));

  document.querySelectorAll('[data-goto-scene]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = Number(btn.getAttribute('data-goto-scene'));
      if (target === 3) {
        lampLit = true;
        scene2?.classList.add('lamp-lit');
      }
      showScene(target);
    });
  });

  document.getElementById('replay-intro-btn')?.addEventListener('click', () => {
    lampLit = false;
    scene2?.classList.remove('lamp-lit');
    lampRig?.classList.remove('swinging');
    if (enterBtn) enterBtn.classList.add('d-none');
    if (lampHint) lampHint.textContent = 'Drag or tap the brass pull chain downward to turn on the lamp and reveal the portal.';
    showScene(1);
    setTimeout(() => {
      if (currentScene === 1) showScene(2);
    }, 4500);
  });

  document.querySelectorAll('[data-skip-intro]').forEach(btn => {
    btn.addEventListener('click', () => {
      lampLit = true;
      scene2?.classList.add('lamp-lit');
      showScene(3);
    });
  });

  document.getElementById('reduced-motion-toggle')?.addEventListener('click', () => {
    document.body.classList.toggle('reduced-motion');
    localStorage.setItem('gmu-reduced-motion', document.body.classList.contains('reduced-motion'));
  });

  function igniteLampAndProceed() {
    if (lampLit) {
      showScene(3);
      return;
    }
    lampLit = true;
    scene2?.classList.add('lamp-lit');
    lampRig?.classList.add('swinging');
    if (lampHint) lampHint.textContent = 'Illumination activated. Welcome to GM University Portal.';
    if (enterBtn) enterBtn.classList.remove('d-none');
    setTimeout(() => {
      if (currentScene === 2) showScene(3);
    }, 1150);
  }

  if (pullHit && pullLinks) {
    pullHit.addEventListener('pointerdown', (e) => {
      dragging = true;
      startY = e.clientY;
      pullHit.setPointerCapture(e.pointerId);
    });

    pullHit.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const delta = Math.max(0, Math.min(60, e.clientY - startY));
      pullLinks.style.height = (72 + delta) + 'px';
    });

    pullHit.addEventListener('pointerup', (e) => {
      if (!dragging) return;
      const delta = e.clientY - startY;
      dragging = false;
      pullLinks.style.height = '72px';
      if (delta >= 22 || Math.abs(delta) < 6) {
        igniteLampAndProceed();
      }
    });

    pullHit.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        igniteLampAndProceed();
      }
    });
  }

  enterBtn?.addEventListener('click', () => showScene(3));

  // Role Switcher (Student / Admin)
  const roleInput = document.getElementById('login-role-tab');
  const loginHint = document.getElementById('login-role-hint');
  document.querySelectorAll('[data-role-switch]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-role-switch]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const role = btn.getAttribute('data-role-switch');
      if (roleInput) roleInput.value = role;
      if (loginHint) {
        loginHint.textContent = role === 'ADMIN'
          ? 'Sign in with GM University Administrator credentials.'
          : 'Sign in with your approved Student Username or Student ID.';
      }
    });
  });

  // Show/Hide Password
  const togglePwdBtn = document.getElementById('toggle-password-btn');
  const pwdField = document.getElementById('login-password');
  togglePwdBtn?.addEventListener('click', () => {
    if (!pwdField) return;
    const isPwd = pwdField.type === 'password';
    pwdField.type = isPwd ? 'text' : 'password';
    togglePwdBtn.textContent = isPwd ? 'Hide' : 'Show';
  });

  // Registration Form Submission
  const regForm = document.getElementById('student-register-form');
  const regFeedback = document.getElementById('register-feedback');

  regForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!regFeedback) return;
    regFeedback.className = 'alert d-none';

    const formData = new FormData(regForm);
    const payload = {
      name: formData.get('name'),
      studentId: formData.get('studentId'),
      username: formData.get('username'),
      password: formData.get('password'),
      departmentId: Number(formData.get('departmentId')),
      branch: formData.get('branch'),
      semester: Number(formData.get('semester')),
      section: formData.get('section'),
      phone: formData.get('phone'),
      admissionYear: Number(formData.get('admissionYear'))
    };

    const csrfToken = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
    const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content') || 'X-XSRF-TOKEN';

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (csrfToken) headers[csrfHeader] = csrfToken;

      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });
      const text = await res.text();
      let json = null;
      try { json = text ? JSON.parse(text) : null; } catch (_) {}

      if (!res.ok || !json?.success) {
        regFeedback.className = 'alert alert-danger mt-2';
        regFeedback.textContent = json?.message || `Registration failed (HTTP ${res.status}). Check server & MySQL logs.`;
        return;
      }
      regFeedback.className = 'alert alert-success mt-2';
      regFeedback.textContent = json.message;
      regForm.reset();
    } catch (err) {
      regFeedback.className = 'alert alert-danger mt-2';
      regFeedback.textContent = 'Cannot reach the Spring Boot server. Verify MySQL 8 (smart_campus_db) is running and started via mvn spring-boot:run.';
    }
  });
})();
