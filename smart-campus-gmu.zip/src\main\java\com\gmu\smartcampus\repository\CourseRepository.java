package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Course;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepository {

    private final JdbcTemplate jdbcTemplate;

    public CourseRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Course> rowMapper = (rs, rowNum) -> {
        Course c = new Course();
        c.setId(rs.getLong("id"));
        c.setCourseCode(rs.getString("course_code"));
        c.setCourseName(rs.getString("course_name"));
        c.setDepartmentId(rs.getLong("department_id"));
        c.setDepartmentCode(rs.getString("dept_code"));
        c.setDepartmentName(rs.getString("dept_name"));
        c.setSemester(rs.getInt("semester"));
        c.setCredits(rs.getInt("credits"));
        c.setDescription(rs.getString("description"));
        c.setActive(rs.getBoolean("active"));
        long facId = rs.getLong("assigned_faculty_id");
        if (!rs.wasNull()) c.setAssignedFacultyId(facId);
        c.setAssignedFacultyName(rs.getString("assigned_faculty_name"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) c.setCreatedAt(ts.toLocalDateTime());
        return c;
    };

    private static final String BASE_SELECT =
            "SELECT c.*, d.code AS dept_code, d.name AS dept_name, " +
            "fc.faculty_id AS assigned_faculty_id, f.name AS assigned_faculty_name " +
            "FROM courses c " +
            "JOIN departments d ON c.department_id = d.id " +
            "LEFT JOIN faculty_courses fc ON c.id = fc.course_id " +
            "LEFT JOIN faculty f ON fc.faculty_id = f.id ";

    public List<Course> findAll() {
        return jdbcTemplate.query(BASE_SELECT + "ORDER BY c.semester ASC, c.course_code ASC", rowMapper);
    }

    public Optional<Course> findById(Long id) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE c.id = ?", rowMapper, id).stream().findFirst();
    }

    public List<Course> findByStudentId(Long studentDbId) {
        return jdbcTemplate.query(
                BASE_SELECT + "JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.course_code ASC",
                rowMapper, studentDbId);
    }

    public boolean existsByCourseCode(String courseCode) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM courses WHERE LOWER(course_code) = LOWER(?)", Integer.class, courseCode);
        return count != null && count > 0;
    }

    public Long save(Course course) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, course.getCourseCode());
            ps.setString(2, course.getCourseName());
            ps.setLong(3, course.getDepartmentId());
            ps.setInt(4, course.getSemester());
            ps.setInt(5, course.getCredits());
            ps.setString(6, course.getDescription());
            ps.setBoolean(7, course.isActive());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Course course) {
        return jdbcTemplate.update(
                "UPDATE courses SET course_name = ?, department_id = ?, semester = ?, credits = ?, description = ?, active = ? WHERE id = ?",
                course.getCourseName(), course.getDepartmentId(), course.getSemester(),
                course.getCredits(), course.getDescription(), course.isActive(), course.getId());
    }

    public void assignFaculty(Long courseId, Long facultyId) {
        jdbcTemplate.update("DELETE FROM faculty_courses WHERE course_id = ?", courseId);
        if (facultyId != null) {
            jdbcTemplate.update(
                    "INSERT INTO faculty_courses (faculty_id, course_id, academic_term) VALUES (?, ?, '2026-ODD')",
                    facultyId, courseId);
        }
    }

    public void enrollStudent(Long studentDbId, Long courseId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM student_courses WHERE student_id = ? AND course_id = ?",
                Integer.class, studentDbId, courseId);
        if (count == null || count == 0) {
            jdbcTemplate.update(
                    "INSERT INTO student_courses (student_id, course_id, status) VALUES (?, ?, 'ENROLLED')",
                    studentDbId, courseId);
        }
    }

    public int unenrollStudent(Long studentDbId, Long courseId) {
        return jdbcTemplate.update(
                "DELETE FROM student_courses WHERE student_id = ? AND course_id = ?",
                studentDbId, courseId);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM courses WHERE id = ?", id);
    }
}
