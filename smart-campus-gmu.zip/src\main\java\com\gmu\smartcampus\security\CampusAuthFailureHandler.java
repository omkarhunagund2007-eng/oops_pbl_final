package com.gmu.smartcampus.security;

import com.gmu.smartcampus.model.UserAccount;
import com.gmu.smartcampus.repository.UserRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Component
public class CampusAuthFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    private final UserRepository userRepository;

    public CampusAuthFailureHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception) throws IOException, ServletException {
        String username = request.getParameter("username");
        String code = "INVALID";
        String message = "Invalid username/Student ID or password.";

        if (exception instanceof LockedException) {
            code = "REJECTED";
            message = "Your student registration was rejected by the administrator. Please contact the GMU Registrar.";
        } else if (exception instanceof DisabledException) {
            Optional<UserAccount> userOpt = username != null ? userRepository.findByUsername(username.trim()) : Optional.empty();
            if (userOpt.isPresent() && "REJECTED".equalsIgnoreCase(userOpt.get().getAccountStatus())) {
                code = "REJECTED";
                message = "Your student registration was rejected by the administrator.";
            } else if (userOpt.isPresent() && "INACTIVE".equalsIgnoreCase(userOpt.get().getAccountStatus())) {
                code = "INACTIVE";
                message = "Your account has been deactivated by an administrator.";
            } else {
                code = "PENDING";
                message = "Your registration is pending administrator approval. Please check back once approved.";
            }
        }

        String redirectUrl = "/login?error=" + URLEncoder.encode(message, StandardCharsets.UTF_8) + "&status=" + code;
        getRedirectStrategy().sendRedirect(request, response, redirectUrl);
    }
}
