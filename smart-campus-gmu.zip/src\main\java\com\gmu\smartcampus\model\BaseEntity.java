package com.gmu.smartcampus.model;

import java.time.LocalDateTime;

/**
 * Abstract base class demonstrating encapsulation, inheritance, and abstract contracts.
 */
public abstract class BaseEntity implements AuditableResource {

    protected Long id;
    protected LocalDateTime createdAt;

    protected BaseEntity() {
        this.createdAt = LocalDateTime.now();
    }

    protected BaseEntity(Long id, LocalDateTime createdAt) {
        this.id = id;
        this.createdAt = createdAt != null ? createdAt : LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public abstract String getEntityType();
}
