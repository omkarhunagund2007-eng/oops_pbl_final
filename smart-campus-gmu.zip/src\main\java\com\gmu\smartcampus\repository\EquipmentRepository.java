package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Equipment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class EquipmentRepository {

    private final JdbcTemplate jdbcTemplate;

    public EquipmentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Equipment> rowMapper = (rs, rowNum) -> {
        Equipment e = new Equipment();
        e.setId(rs.getLong("id"));
        e.setEquipmentId(rs.getString("equipment_id"));
        e.setName(rs.getString("name"));
        e.setCategory(rs.getString("category"));
        e.setQuantity(rs.getInt("quantity"));
        e.setAvailableQuantity(rs.getInt("available_quantity"));
        e.setItemCondition(rs.getString("item_condition"));
        e.setLocation(rs.getString("location"));
        Date pd = rs.getDate("purchase_date");
        if (pd != null) e.setPurchaseDate(pd.toLocalDate());
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) e.setCreatedAt(ts.toLocalDateTime());
        return e;
    };

    public List<Equipment> findAll() {
        return jdbcTemplate.query("SELECT * FROM equipment ORDER BY equipment_id ASC", rowMapper);
    }

    public Optional<Equipment> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM equipment WHERE id = ?", rowMapper, id).stream().findFirst();
    }

    public boolean existsByEquipmentId(String equipmentId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM equipment WHERE LOWER(equipment_id) = LOWER(?)", Integer.class, equipmentId);
        return count != null && count > 0;
    }

    public Long save(Equipment eq) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO equipment (equipment_id, name, category, quantity, available_quantity, item_condition, location, purchase_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, eq.getEquipmentId());
            ps.setString(2, eq.getName());
            ps.setString(3, eq.getCategory());
            ps.setInt(4, eq.getQuantity());
            ps.setInt(5, eq.getAvailableQuantity());
            ps.setString(6, eq.getItemCondition());
            ps.setString(7, eq.getLocation());
            ps.setDate(8, Date.valueOf(eq.getPurchaseDate()));
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Equipment eq) {
        return jdbcTemplate.update(
                "UPDATE equipment SET name = ?, category = ?, quantity = ?, available_quantity = ?, item_condition = ?, location = ?, purchase_date = ? WHERE id = ?",
                eq.getName(), eq.getCategory(), eq.getQuantity(), eq.getAvailableQuantity(),
                eq.getItemCondition(), eq.getLocation(), Date.valueOf(eq.getPurchaseDate()), eq.getId());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM equipment WHERE id = ?", id);
    }
}
