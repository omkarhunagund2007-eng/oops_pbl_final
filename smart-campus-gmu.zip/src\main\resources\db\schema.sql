-- =============================================================================
-- GM University Smart Campus Integrated Management System
-- Normalized MySQL 8 Database Schema (smart_campus_db)
-- Compatible with MySQL 8.0+ and H2 MySQL-mode for automated testing
-- =============================================================================

CREATE TABLE IF NOT EXISTS departments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL UNIQUE,
    hod_name VARCHAR(120) NOT NULL,
    building VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(60) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) UNIQUE,
    role VARCHAR(20) NOT NULL, -- ADMIN, STUDENT
    account_status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED, INACTIVE
    theme_preference VARCHAR(10) NOT NULL DEFAULT 'light',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_role_status ON users (role, account_status);

CREATE TABLE IF NOT EXISTS students (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    student_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    department_id BIGINT NOT NULL,
    branch VARCHAR(80) NOT NULL,
    semester INT NOT NULL,
    section VARCHAR(10) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    admission_year INT NOT NULL,
    account_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_students_dept FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE INDEX idx_students_dept_sem ON students (department_id, semester);
CREATE INDEX idx_students_status ON students (account_status);

CREATE TABLE IF NOT EXISTS faculty (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    faculty_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    department_id BIGINT NOT NULL,
    designation VARCHAR(80) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    specialization VARCHAR(150) NOT NULL,
    joining_date DATE NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_faculty_dept FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE IF NOT EXISTS courses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(25) NOT NULL UNIQUE,
    course_name VARCHAR(150) NOT NULL,
    department_id BIGINT NOT NULL,
    semester INT NOT NULL,
    credits INT NOT NULL,
    description TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_courses_dept FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE INDEX idx_courses_dept_sem ON courses (department_id, semester);

CREATE TABLE IF NOT EXISTS faculty_courses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    faculty_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    academic_term VARCHAR(30) NOT NULL DEFAULT '2026-ODD',
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_faculty_course UNIQUE (faculty_id, course_id),
    CONSTRAINT fk_fc_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    CONSTRAINT fk_fc_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_courses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'ENROLLED',
    CONSTRAINT uq_student_course UNIQUE (student_id, course_id),
    CONSTRAINT fk_sc_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_sc_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS classrooms (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id VARCHAR(30) NOT NULL UNIQUE,
    building VARCHAR(100) NOT NULL,
    room_number VARCHAR(30) NOT NULL,
    capacity INT NOT NULL,
    availability_status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE', -- AVAILABLE, MAINTENANCE, UNAVAILABLE
    equipment_summary VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS laboratories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    lab_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    location VARCHAR(120) NOT NULL,
    capacity INT NOT NULL,
    lab_type VARCHAR(80) NOT NULL,
    equipment_summary VARCHAR(255) NOT NULL,
    availability_status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS equipment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    equipment_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(80) NOT NULL,
    quantity INT NOT NULL,
    available_quantity INT NOT NULL,
    item_condition VARCHAR(40) NOT NULL DEFAULT 'GOOD',
    location VARCHAR(120) NOT NULL,
    purchase_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS campus_events (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(60) NOT NULL,
    description TEXT NOT NULL,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    location VARCHAR(120) NOT NULL,
    capacity INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PUBLISHED', -- DRAFT, PUBLISHED, CANCELLED
    created_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_events_creator FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX idx_events_date_status ON campus_events (event_date, status);

CREATE TABLE IF NOT EXISTS event_registrations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_id BIGINT NOT NULL,
    student_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'REGISTERED', -- REGISTERED, CANCELLED
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_event_student UNIQUE (event_id, student_id),
    CONSTRAINT fk_er_event FOREIGN KEY (event_id) REFERENCES campus_events(id) ON DELETE CASCADE,
    CONSTRAINT fk_er_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS resource_bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_code VARCHAR(30) NOT NULL UNIQUE,
    resource_type VARCHAR(20) NOT NULL, -- CLASSROOM, LABORATORY, EQUIPMENT
    resource_id BIGINT NOT NULL,
    resource_name VARCHAR(140) NOT NULL,
    requested_by_user_id BIGINT NOT NULL,
    requester_name VARCHAR(120) NOT NULL,
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED, CANCELLED
    reviewed_by_admin_id BIGINT,
    review_note VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rb_user FOREIGN KEY (requested_by_user_id) REFERENCES users(id),
    CONSTRAINT fk_rb_admin FOREIGN KEY (reviewed_by_admin_id) REFERENCES users(id)
);

CREATE INDEX idx_bookings_slot ON resource_bookings (resource_type, resource_id, booking_date, status);

CREATE TABLE IF NOT EXISTS announcements (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    content TEXT NOT NULL,
    audience VARCHAR(30) NOT NULL DEFAULT 'ALL', -- ALL, STUDENTS, FACULTY
    priority VARCHAR(20) NOT NULL DEFAULT 'NORMAL', -- NORMAL, IMPORTANT, URGENT
    posted_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ann_user FOREIGN KEY (posted_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS approval_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    target_type VARCHAR(30) NOT NULL, -- STUDENT_REGISTRATION, RESOURCE_BOOKING
    target_id BIGINT NOT NULL,
    action VARCHAR(20) NOT NULL, -- APPROVED, REJECTED
    admin_user_id BIGINT NOT NULL,
    admin_username VARCHAR(60) NOT NULL,
    reason VARCHAR(255),
    decision_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ah_admin FOREIGN KEY (admin_user_id) REFERENCES users(id)
);
