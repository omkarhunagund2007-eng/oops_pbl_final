package com.gmu.smartcampus.model;

/**
 * Concrete Student entity extending Person.
 */
public class Student extends Person {

    private Long userId;
    private String username;
    private String studentId;
    private String branch;
    private int semester;
    private String section;
    private int admissionYear;
    private String accountStatus;

    public Student() {
        super();
    }

    @Override
    public String getEntityType() {
        return "STUDENT";
    }

    @Override
    public String getAuditIdentifier() {
        return studentId;
    }

    @Override
    public String getAcademicSummary() {
        return String.format("%s (%s) · Sem %d · Sec %s · Batch %d",
                name, studentId, semester, section, admissionYear);
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public int getAdmissionYear() {
        return admissionYear;
    }

    public void setAdmissionYear(int admissionYear) {
        this.admissionYear = admissionYear;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }
}
