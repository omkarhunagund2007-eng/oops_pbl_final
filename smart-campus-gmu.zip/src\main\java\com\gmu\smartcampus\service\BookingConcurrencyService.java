package com.gmu.smartcampus.service;

import com.gmu.smartcampus.dto.BookingRequest;
import com.gmu.smartcampus.exception.BookingConflictException;
import com.gmu.smartcampus.exception.ResourceNotFoundException;
import com.gmu.smartcampus.exception.UnauthorizedActionException;
import com.gmu.smartcampus.model.CampusResource;
import com.gmu.smartcampus.model.ResourceBooking;
import com.gmu.smartcampus.repository.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Demonstrates Multithreading, Synchronization (ReentrantLock per resource key),
 * ExecutorService, Runtime Polymorphism (CampusResource / Bookable), and SERIALIZABLE transactions
 * committed strictly inside the lock boundary.
 */
@Service
public class BookingConcurrencyService {

    private final BookingRepository bookingRepository;
    private final ClassroomRepository classroomRepository;
    private final LaboratoryRepository laboratoryRepository;
    private final EquipmentRepository equipmentRepository;
    private final ApprovalHistoryRepository approvalHistoryRepository;
    private final ExecutorService bookingExecutorService;
    private final TransactionTemplate serializableTxTemplate;

    private final ConcurrentHashMap<String, ReentrantLock> resourceLocks = new ConcurrentHashMap<>();

    public BookingConcurrencyService(BookingRepository bookingRepository,
                                     ClassroomRepository classroomRepository,
                                     LaboratoryRepository laboratoryRepository,
                                     EquipmentRepository equipmentRepository,
                                     ApprovalHistoryRepository approvalHistoryRepository,
                                     @Qualifier("bookingExecutorService") ExecutorService bookingExecutorService,
                                     PlatformTransactionManager transactionManager) {
        this.bookingRepository = bookingRepository;
        this.classroomRepository = classroomRepository;
        this.laboratoryRepository = laboratoryRepository;
        this.equipmentRepository = equipmentRepository;
        this.approvalHistoryRepository = approvalHistoryRepository;
        this.bookingExecutorService = bookingExecutorService;
        this.serializableTxTemplate = new TransactionTemplate(transactionManager);
        this.serializableTxTemplate.setIsolationLevel(TransactionDefinition.ISOLATION_SERIALIZABLE);
    }

    /**
     * Asynchronous dispatch on the configured ExecutorService thread pool.
     */
    public CompletableFuture<ResourceBooking> submitBookingAsync(BookingRequest request, Long userId, String requesterName) {
        return CompletableFuture.supplyAsync(() -> createBooking(request, userId, requesterName), bookingExecutorService);
    }

    /**
     * Thread-safe, lock-protected booking creation where the SERIALIZABLE transaction
     * commits inside the ReentrantLock critical section before releasing the lock.
     */
    public ResourceBooking createBooking(BookingRequest req, Long userId, String requesterName) {
        if (req.getStartTime() == null || req.getEndTime() == null || !req.getStartTime().isBefore(req.getEndTime())) {
            throw new IllegalArgumentException("End time must be strictly after start time.");
        }
        if (req.getBookingDate() == null) {
            throw new IllegalArgumentException("Booking date is required.");
        }

        String normalizedType = req.getResourceType().trim().toUpperCase();
        CampusResource resource = resolveBookableResource(normalizedType, req.getResourceId());

        if (!resource.isCurrentlyBookable()) {
            throw new BookingConflictException("Resource '" + resource.getResourceTitle() + "' is currently unavailable for booking.");
        }

        String lockKey = resource.buildLockKey(req.getBookingDate().toString());
        ReentrantLock lock = resourceLocks.computeIfAbsent(lockKey, k -> new ReentrantLock(true));

        lock.lock();
        try {
            return serializableTxTemplate.execute(status -> {
                boolean overlaps = bookingRepository.existsOverlappingBooking(
                        normalizedType, req.getResourceId(), req.getBookingDate(),
                        req.getStartTime(), req.getEndTime());

                if (overlaps) {
                    throw new BookingConflictException(
                            String.format("Time slot conflict: %s is already booked or pending approval on %s between %s and %s.",
                                    resource.getResourceTitle(), req.getBookingDate(), req.getStartTime(), req.getEndTime()));
                }

                ResourceBooking booking = new ResourceBooking();
                booking.setBookingCode("BK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
                booking.setResourceType(normalizedType);
                booking.setResourceId(req.getResourceId());
                booking.setResourceName(resource.getResourceTitle());
                booking.setRequestedByUserId(userId);
                booking.setRequesterName(requesterName);
                booking.setBookingDate(req.getBookingDate());
                booking.setStartTime(req.getStartTime());
                booking.setEndTime(req.getEndTime());
                booking.setPurpose(req.getPurpose().trim());
                booking.setStatus("PENDING");

                Long savedId = bookingRepository.save(booking);
                return bookingRepository.findById(savedId).orElse(booking);
            });
        } finally {
            lock.unlock();
        }
    }

    public boolean isSlotAvailable(String resourceType, Long resourceId,
                                   java.time.LocalDate date, LocalTime start, LocalTime end) {
        return !bookingRepository.existsOverlappingBooking(
                resourceType.trim().toUpperCase(), resourceId, date, start, end);
    }

    @Transactional
    public ResourceBooking reviewBooking(Long bookingId, boolean approve, Long adminUserId, String adminUsername, String note) {
        ResourceBooking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking request not found."));

        String newStatus = approve ? "APPROVED" : "REJECTED";
        String cleanNote = (note != null && !note.isBlank())
                ? note.trim()
                : (approve ? "Approved by campus administrator." : "Slot declined by administrator.");

        bookingRepository.updateReviewStatus(bookingId, newStatus, adminUserId, cleanNote);
        approvalHistoryRepository.record(
                "RESOURCE_BOOKING", bookingId, newStatus, adminUserId, adminUsername, cleanNote);

        return bookingRepository.findById(bookingId).orElseThrow();
    }

    @Transactional
    public ResourceBooking cancelBooking(Long bookingId, Long actingUserId, boolean isAdmin) {
        ResourceBooking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found."));

        if (!isAdmin && !booking.getRequestedByUserId().equals(actingUserId)) {
            throw new UnauthorizedActionException("You can only cancel your own resource bookings.");
        }
        if ("CANCELLED".equalsIgnoreCase(booking.getStatus()) || "REJECTED".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Booking is already " + booking.getStatus().toLowerCase() + ".");
        }
        bookingRepository.cancelById(bookingId);
        return bookingRepository.findById(bookingId).orElseThrow();
    }

    public List<ResourceBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public List<ResourceBooking> getBookingsForUser(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    private CampusResource resolveBookableResource(String type, Long id) {
        return switch (type) {
            case "CLASSROOM" -> classroomRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Classroom not found: " + id));
            case "LABORATORY" -> laboratoryRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Laboratory not found: " + id));
            case "EQUIPMENT" -> equipmentRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Equipment not found: " + id));
            default -> throw new IllegalArgumentException("Unsupported resource type: " + type);
        };
    }
}
