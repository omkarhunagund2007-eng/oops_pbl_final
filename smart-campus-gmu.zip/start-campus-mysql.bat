@echo off
setlocal enabledelayedexpansion
title GM University - Smart Campus (MySQL Mode)
echo =========================================================
echo    GM UNIVERSITY — SMART CAMPUS (MYSQL 8 MODE)
echo =========================================================

REM Detect Maven executable
where mvn >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set "MVN_EXEC=mvn"
) else if exist "%USERPROFILE%\.maven\apache-maven-3.10.0\bin\mvn.cmd" (
    set "MVN_EXEC=%USERPROFILE%\.maven\apache-maven-3.10.0\bin\mvn.cmd"
) else (
    echo [ERROR] Maven (mvn) was not found in PATH or in %USERPROFILE%\.maven\apache-maven-3.10.0\bin.
    pause
    exit /b 1
)

echo.
echo [INFO] Connecting to MySQL 8 on localhost:3306 (database: smart_campus_db)
echo [INFO] Make sure you initialized the database using src\main\resources\db\mysql_setup.sql
echo.
echo Launching Spring Boot on http://localhost:8080 ...
call "%MVN_EXEC%" spring-boot:run
pause
