package com.gmu.smartcampus.model;

/**
 * Abstraction interface representing any campus facility or asset
 * eligible for time-slotted reservation under concurrency control.
 */
public interface Bookable {
    Long getId();
    String getResourceCode();
    String getResourceTitle();
    String getResourceType();
    boolean isCurrentlyBookable();
    String getAvailabilitySummary();
}
