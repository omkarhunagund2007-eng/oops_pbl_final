package com.gmu.smartcampus.controller;

import com.gmu.smartcampus.dto.ApiResponse;
import com.gmu.smartcampus.dto.BookingRequest;
import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.security.CustomUserDetails;
import com.gmu.smartcampus.service.BookingConcurrencyService;
import com.gmu.smartcampus.service.CampusManagementService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@Controller
@PreAuthorize("hasRole('STUDENT')")
public class StudentDashboardController {

    private final CampusManagementService campusService;
    private final BookingConcurrencyService bookingService;

    public StudentDashboardController(CampusManagementService campusService,
                                      BookingConcurrencyService bookingService) {
        this.campusService = campusService;
        this.bookingService = bookingService;
    }

    @GetMapping("/student/dashboard")
    public String studentDashboard(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        model.addAttribute("currentUser", principal.getUser());
        model.addAttribute("student", student);
        return "student/dashboard";
    }

    @ResponseBody
    @GetMapping("/api/student/profile")
    public ApiResponse<Student> getMyProfile(@AuthenticationPrincipal CustomUserDetails principal) {
        return ApiResponse.ok("Student profile loaded", campusService.getStudentByUserId(principal.getUserId()));
    }

    @ResponseBody
    @GetMapping("/api/student/courses")
    public ApiResponse<Map<String, Object>> getCourses(@AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        List<Course> enrolled = campusService.getStudentCourses(student.getId());
        List<Course> catalog = campusService.getAllCourses();
        return ApiResponse.ok("Courses loaded", Map.of("enrolled", enrolled, "catalog", catalog));
    }

    @ResponseBody
    @PostMapping("/api/student/courses/{courseId}/enroll")
    public ApiResponse<Void> enrollCourse(@PathVariable Long courseId,
                                          @AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        campusService.enrollStudentInCourse(student.getId(), courseId);
        return ApiResponse.ok("Enrolled in course successfully", null);
    }

    @ResponseBody
    @DeleteMapping("/api/student/courses/{courseId}/enroll")
    public ApiResponse<Void> dropCourse(@PathVariable Long courseId,
                                        @AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        campusService.unenrollStudentFromCourse(student.getId(), courseId);
        return ApiResponse.ok("Course dropped successfully", null);
    }

    @ResponseBody
    @GetMapping("/api/student/faculty")
    public ApiResponse<List<Faculty>> getFacultyDirectory() {
        return ApiResponse.ok("Faculty directory loaded", campusService.getAllFaculty());
    }

    @ResponseBody
    @GetMapping("/api/student/events")
    public ApiResponse<Map<String, Object>> getEventsAndRegistrations(@AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        return ApiResponse.ok("Events loaded", Map.of(
                "events", campusService.getPublishedEvents(),
                "registrations", campusService.getStudentEventRegistrations(student.getId())
        ));
    }

    @ResponseBody
    @PostMapping("/api/student/events/{eventId}/register")
    public ApiResponse<Void> registerEvent(@PathVariable Long eventId,
                                           @AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        campusService.registerStudentForEvent(eventId, student.getId());
        return ApiResponse.ok("Registered for campus event", null);
    }

    @ResponseBody
    @PostMapping("/api/student/events/{eventId}/cancel")
    public ApiResponse<Void> cancelEvent(@PathVariable Long eventId,
                                         @AuthenticationPrincipal CustomUserDetails principal) {
        Student student = campusService.getStudentByUserId(principal.getUserId());
        campusService.cancelEventRegistration(eventId, student.getId());
        return ApiResponse.ok("Event registration cancelled", null);
    }

    @ResponseBody
    @GetMapping("/api/student/resources")
    public ApiResponse<Map<String, Object>> getBookableResources() {
        return ApiResponse.ok("Resources loaded", Map.of(
                "classrooms", campusService.getAllClassrooms(),
                "laboratories", campusService.getAllLaboratories(),
                "equipment", campusService.getAllEquipment()
        ));
    }

    @ResponseBody
    @GetMapping("/api/student/bookings/availability")
    public ApiResponse<Map<String, Boolean>> checkAvailability(
            @RequestParam String resourceType,
            @RequestParam Long resourceId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime endTime) {
        boolean available = bookingService.isSlotAvailable(resourceType, resourceId, date, startTime, endTime);
        return ApiResponse.ok("Availability checked", Map.of("available", available));
    }

    @ResponseBody
    @GetMapping("/api/student/bookings")
    public ApiResponse<List<ResourceBooking>> getMyBookings(@AuthenticationPrincipal CustomUserDetails principal) {
        return ApiResponse.ok("My bookings loaded", bookingService.getBookingsForUser(principal.getUserId()));
    }

    @ResponseBody
    @PostMapping("/api/student/bookings")
    public ApiResponse<ResourceBooking> createBooking(@Valid @RequestBody BookingRequest req,
                                                      @AuthenticationPrincipal CustomUserDetails principal) {
        ResourceBooking created = bookingService.createBooking(req, principal.getUserId(), principal.getFullName());
        return ApiResponse.ok("Booking request submitted", created);
    }

    @ResponseBody
    @PostMapping("/api/student/bookings/{id}/cancel")
    public ApiResponse<ResourceBooking> cancelMyBooking(@PathVariable Long id,
                                                        @AuthenticationPrincipal CustomUserDetails principal) {
        return ApiResponse.ok("Booking cancelled", bookingService.cancelBooking(id, principal.getUserId(), false));
    }

    @ResponseBody
    @GetMapping("/api/student/announcements")
    public ApiResponse<List<Announcement>> getAnnouncements() {
        return ApiResponse.ok("Announcements loaded", campusService.getStudentAnnouncements());
    }
}
