package com.gmu.smartcampus.service;

import com.gmu.smartcampus.dto.DashboardStatsDTO;
import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.repository.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Demonstrates Java Streams, Lambda Expressions, Functional Interfaces,
 * and Collections (ArrayList, HashMap, HashSet) for campus analytics.
 */
@Service
public class AnalyticsStreamService {

    /**
     * Custom Functional Interface for generic domain filtering via lambda expressions.
     */
    @FunctionalInterface
    public interface ResourcePredicate<T> {
        boolean test(T item);
    }

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;
    private final CourseRepository courseRepository;
    private final ClassroomRepository classroomRepository;
    private final LaboratoryRepository laboratoryRepository;
    private final EquipmentRepository equipmentRepository;
    private final EventRepository eventRepository;
    private final BookingRepository bookingRepository;

    public AnalyticsStreamService(StudentRepository studentRepository,
                                  FacultyRepository facultyRepository,
                                  CourseRepository courseRepository,
                                  ClassroomRepository classroomRepository,
                                  LaboratoryRepository laboratoryRepository,
                                  EquipmentRepository equipmentRepository,
                                  EventRepository eventRepository,
                                  BookingRepository bookingRepository) {
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
        this.courseRepository = courseRepository;
        this.classroomRepository = classroomRepository;
        this.laboratoryRepository = laboratoryRepository;
        this.equipmentRepository = equipmentRepository;
        this.eventRepository = eventRepository;
        this.bookingRepository = bookingRepository;
    }

    public DashboardStatsDTO computeDashboardStats() {
        List<Student> students = new ArrayList<>(studentRepository.findAll());
        List<Faculty> faculty = new ArrayList<>(facultyRepository.findAll());
        List<Course> courses = new ArrayList<>(courseRepository.findAll());
        List<Classroom> classrooms = new ArrayList<>(classroomRepository.findAll());
        List<Laboratory> labs = new ArrayList<>(laboratoryRepository.findAll());
        List<Equipment> equipmentList = new ArrayList<>(equipmentRepository.findAll());
        List<CampusEvent> events = new ArrayList<>(eventRepository.findAll());
        List<ResourceBooking> bookings = new ArrayList<>(bookingRepository.findAll());

        DashboardStatsDTO stats = new DashboardStatsDTO();
        stats.setTotalStudents(students.size());
        stats.setApprovedStudents(students.stream().filter(s -> "APPROVED".equalsIgnoreCase(s.getAccountStatus())).count());
        stats.setPendingRequests(students.stream().filter(s -> "PENDING".equalsIgnoreCase(s.getAccountStatus())).count());
        stats.setTotalFaculty(faculty.size());
        stats.setTotalCourses(courses.size());
        stats.setTotalClassrooms(classrooms.size());
        stats.setTotalLaboratories(labs.size());
        stats.setTotalEquipmentItems(equipmentList.stream().mapToInt(Equipment::getQuantity).sum());
        stats.setUpcomingActivities(events.stream().filter(e -> "PUBLISHED".equalsIgnoreCase(e.getStatus())).count());
        stats.setActiveBookings(bookings.stream().filter(b -> "APPROVED".equalsIgnoreCase(b.getStatus()) || "PENDING".equalsIgnoreCase(b.getStatus())).count());

        // Java Streams groupingBy -> HashMap<String, Long>
        Map<String, Long> byDept = students.stream()
                .collect(Collectors.groupingBy(
                        s -> s.getDepartmentCode() != null ? s.getDepartmentCode() : "OTHER",
                        HashMap::new,
                        Collectors.counting()));
        stats.setStudentsByDepartment(byDept);

        Map<String, Long> byBookingStatus = bookings.stream()
                .collect(Collectors.groupingBy(
                        ResourceBooking::getStatus,
                        HashMap::new,
                        Collectors.counting()));
        stats.setBookingsByStatus(byBookingStatus);

        return stats;
    }

    public <T> List<T> filterCollection(List<T> source, ResourcePredicate<T> predicate) {
        return source.stream()
                .filter(predicate::test)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public Set<String> getUniqueEquipmentCategories() {
        return equipmentRepository.findAll().stream()
                .map(Equipment::getCategory)
                .collect(Collectors.toCollection(HashSet::new));
    }

    public List<CampusResource> getAllBookableResourcesSorted() {
        List<CampusResource> combined = new ArrayList<>();
        combined.addAll(classroomRepository.findAll());
        combined.addAll(laboratoryRepository.findAll());
        combined.addAll(equipmentRepository.findAll());
        return combined.stream()
                .sorted(Comparator.comparing(CampusResource::getResourceType)
                        .thenComparing(CampusResource::getResourceCode))
                .collect(Collectors.toList());
    }
}
