-- =============================================================================
-- GM University Smart Campus - Initial MySQL 8 Setup Script
-- Run this once as MySQL root before starting the application on Windows
-- =============================================================================

CREATE DATABASE IF NOT EXISTS smart_campus_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'smartcampus_user'@'localhost' IDENTIFIED BY 'SmartCampus@2026';
GRANT ALL PRIVILEGES ON smart_campus_db.* TO 'smartcampus_user'@'localhost';
FLUSH PRIVILEGES;

USE smart_campus_db;
