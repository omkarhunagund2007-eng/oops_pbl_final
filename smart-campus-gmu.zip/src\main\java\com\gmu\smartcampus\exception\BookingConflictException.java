package com.gmu.smartcampus.exception;

import org.springframework.http.HttpStatus;

public class BookingConflictException extends CampusException {
    public BookingConflictException(String message) {
        super(message, HttpStatus.CONFLICT, "BOOKING_TIME_CONFLICT");
    }
}
