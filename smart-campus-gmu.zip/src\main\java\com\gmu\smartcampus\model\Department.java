package com.gmu.smartcampus.model;

public class Department extends BaseEntity {
    private String code;
    private String name;
    private String hodName;
    private String building;

    @Override
    public String getEntityType() {
        return "DEPARTMENT";
    }

    @Override
    public String getAuditIdentifier() {
        return code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHodName() {
        return hodName;
    }

    public void setHodName(String hodName) {
        this.hodName = hodName;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }
}
