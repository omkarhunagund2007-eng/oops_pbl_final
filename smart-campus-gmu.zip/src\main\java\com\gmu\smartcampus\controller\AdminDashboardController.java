package com.gmu.smartcampus.controller;

import com.gmu.smartcampus.dto.ApiResponse;
import com.gmu.smartcampus.dto.ApprovalDecisionRequest;
import com.gmu.smartcampus.dto.BookingRequest;
import com.gmu.smartcampus.dto.DashboardStatsDTO;
import com.gmu.smartcampus.model.*;
import com.gmu.smartcampus.security.CustomUserDetails;
import com.gmu.smartcampus.service.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@Controller
@PreAuthorize("hasRole('ADMIN')")
public class AdminDashboardController {

    private final CampusManagementService campusService;
    private final AuthRegistrationService authService;
    private final BookingConcurrencyService bookingService;
    private final AnalyticsStreamService analyticsService;
    private final CsvExportService csvExportService;

    public AdminDashboardController(CampusManagementService campusService,
                                    AuthRegistrationService authService,
                                    BookingConcurrencyService bookingService,
                                    AnalyticsStreamService analyticsService,
                                    CsvExportService csvExportService) {
        this.campusService = campusService;
        this.authService = authService;
        this.bookingService = bookingService;
        this.analyticsService = analyticsService;
        this.csvExportService = csvExportService;
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        model.addAttribute("currentUser", principal.getUser());
        model.addAttribute("stats", analyticsService.computeDashboardStats());
        model.addAttribute("departments", campusService.getAllDepartments());
        return "admin/dashboard";
    }

    @ResponseBody
    @GetMapping("/api/admin/stats")
    public ApiResponse<DashboardStatsDTO> getStats() {
        return ApiResponse.ok("Analytics computed", analyticsService.computeDashboardStats());
    }

    // --- Student Management & Approval Queue ---
    @ResponseBody
    @GetMapping("/api/admin/students")
    public ApiResponse<List<Student>> listStudents(@RequestParam(required = false) String status) {
        List<Student> list = (status != null && !status.isBlank())
                ? campusService.getAllStudents().stream()
                    .filter(s -> s.getAccountStatus().equalsIgnoreCase(status))
                    .toList()
                : campusService.getAllStudents();
        return ApiResponse.ok("Students loaded", list);
    }

    @ResponseBody
    @PutMapping("/api/admin/students/{id}")
    public ApiResponse<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
        return ApiResponse.ok("Student updated", campusService.updateStudent(id, student));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/students/{id}")
    public ApiResponse<Void> deleteStudent(@PathVariable Long id) {
        campusService.deleteStudent(id);
        return ApiResponse.ok("Student deleted", null);
    }

    @ResponseBody
    @PostMapping("/api/admin/approvals/students/{id}/approve")
    public ApiResponse<Student> approveStudent(@PathVariable Long id,
                                               @AuthenticationPrincipal CustomUserDetails admin) {
        Student approved = authService.approveStudent(id, admin.getUserId(), admin.getUsername());
        return ApiResponse.ok("Student registration approved", approved);
    }

    @ResponseBody
    @PostMapping("/api/admin/approvals/students/{id}/reject")
    public ApiResponse<Student> rejectStudent(@PathVariable Long id,
                                              @RequestBody(required = false) ApprovalDecisionRequest body,
                                              @AuthenticationPrincipal CustomUserDetails admin) {
        String reason = body != null ? body.getReason() : null;
        Student rejected = authService.rejectStudent(id, admin.getUserId(), admin.getUsername(), reason);
        return ApiResponse.ok("Student registration rejected", rejected);
    }

    @ResponseBody
    @GetMapping("/api/admin/approvals/history")
    public ApiResponse<List<ApprovalHistory>> getApprovalHistory() {
        return ApiResponse.ok("Approval history loaded", authService.getRecentApprovalHistory());
    }

    // --- Faculty Management ---
    @ResponseBody
    @GetMapping("/api/admin/faculty")
    public ApiResponse<List<Faculty>> listFaculty() {
        return ApiResponse.ok("Faculty loaded", campusService.getAllFaculty());
    }

    @ResponseBody
    @PostMapping("/api/admin/faculty")
    public ApiResponse<Faculty> createFaculty(@RequestBody Faculty faculty) {
        return ApiResponse.ok("Faculty added", campusService.createFaculty(faculty));
    }

    @ResponseBody
    @PutMapping("/api/admin/faculty/{id}")
    public ApiResponse<Faculty> updateFaculty(@PathVariable Long id, @RequestBody Faculty faculty) {
        return ApiResponse.ok("Faculty updated", campusService.updateFaculty(id, faculty));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/faculty/{id}")
    public ApiResponse<Void> deleteFaculty(@PathVariable Long id) {
        campusService.deleteFaculty(id);
        return ApiResponse.ok("Faculty deleted", null);
    }

    // --- Course Management ---
    @ResponseBody
    @GetMapping("/api/admin/courses")
    public ApiResponse<List<Course>> listCourses() {
        return ApiResponse.ok("Courses loaded", campusService.getAllCourses());
    }

    @ResponseBody
    @PostMapping("/api/admin/courses")
    public ApiResponse<Course> createCourse(@RequestBody Course course) {
        return ApiResponse.ok("Course created", campusService.createCourse(course));
    }

    @ResponseBody
    @PutMapping("/api/admin/courses/{id}")
    public ApiResponse<Course> updateCourse(@PathVariable Long id, @RequestBody Course course) {
        return ApiResponse.ok("Course updated", campusService.updateCourse(id, course));
    }

    @ResponseBody
    @PostMapping("/api/admin/courses/{id}/assign-faculty")
    public ApiResponse<Void> assignFaculty(@PathVariable Long id, @RequestBody Map<String, Long> payload) {
        campusService.assignFacultyToCourse(id, payload.get("facultyId"));
        return ApiResponse.ok("Faculty assigned to course", null);
    }

    @ResponseBody
    @DeleteMapping("/api/admin/courses/{id}")
    public ApiResponse<Void> deleteCourse(@PathVariable Long id) {
        campusService.deleteCourse(id);
        return ApiResponse.ok("Course deleted", null);
    }

    // --- Classroom Management ---
    @ResponseBody
    @GetMapping("/api/admin/classrooms")
    public ApiResponse<List<Classroom>> listClassrooms() {
        return ApiResponse.ok("Classrooms loaded", campusService.getAllClassrooms());
    }

    @ResponseBody
    @PostMapping("/api/admin/classrooms")
    public ApiResponse<Classroom> createClassroom(@RequestBody Classroom classroom) {
        return ApiResponse.ok("Classroom created", campusService.createClassroom(classroom));
    }

    @ResponseBody
    @PutMapping("/api/admin/classrooms/{id}")
    public ApiResponse<Classroom> updateClassroom(@PathVariable Long id, @RequestBody Classroom classroom) {
        return ApiResponse.ok("Classroom updated", campusService.updateClassroom(id, classroom));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/classrooms/{id}")
    public ApiResponse<Void> deleteClassroom(@PathVariable Long id) {
        campusService.deleteClassroom(id);
        return ApiResponse.ok("Classroom deleted", null);
    }

    // --- Laboratory Management ---
    @ResponseBody
    @GetMapping("/api/admin/laboratories")
    public ApiResponse<List<Laboratory>> listLabs() {
        return ApiResponse.ok("Laboratories loaded", campusService.getAllLaboratories());
    }

    @ResponseBody
    @PostMapping("/api/admin/laboratories")
    public ApiResponse<Laboratory> createLab(@RequestBody Laboratory lab) {
        return ApiResponse.ok("Laboratory created", campusService.createLaboratory(lab));
    }

    @ResponseBody
    @PutMapping("/api/admin/laboratories/{id}")
    public ApiResponse<Laboratory> updateLab(@PathVariable Long id, @RequestBody Laboratory lab) {
        return ApiResponse.ok("Laboratory updated", campusService.updateLaboratory(id, lab));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/laboratories/{id}")
    public ApiResponse<Void> deleteLab(@PathVariable Long id) {
        campusService.deleteLaboratory(id);
        return ApiResponse.ok("Laboratory deleted", null);
    }

    // --- Equipment Management ---
    @ResponseBody
    @GetMapping("/api/admin/equipment")
    public ApiResponse<List<Equipment>> listEquipment() {
        return ApiResponse.ok("Equipment loaded", campusService.getAllEquipment());
    }

    @ResponseBody
    @PostMapping("/api/admin/equipment")
    public ApiResponse<Equipment> createEquipment(@RequestBody Equipment eq) {
        return ApiResponse.ok("Equipment created", campusService.createEquipment(eq));
    }

    @ResponseBody
    @PutMapping("/api/admin/equipment/{id}")
    public ApiResponse<Equipment> updateEquipment(@PathVariable Long id, @RequestBody Equipment eq) {
        return ApiResponse.ok("Equipment updated", campusService.updateEquipment(id, eq));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/equipment/{id}")
    public ApiResponse<Void> deleteEquipment(@PathVariable Long id) {
        campusService.deleteEquipment(id);
        return ApiResponse.ok("Equipment deleted", null);
    }

    // --- Campus Activity Management ---
    @ResponseBody
    @GetMapping("/api/admin/events")
    public ApiResponse<List<CampusEvent>> listEvents() {
        return ApiResponse.ok("Events loaded", campusService.getAllEvents());
    }

    @ResponseBody
    @PostMapping("/api/admin/events")
    public ApiResponse<CampusEvent> createEvent(@RequestBody CampusEvent event,
                                                @AuthenticationPrincipal CustomUserDetails admin) {
        return ApiResponse.ok("Campus event created", campusService.createEvent(event, admin.getUserId()));
    }

    @ResponseBody
    @PutMapping("/api/admin/events/{id}")
    public ApiResponse<CampusEvent> updateEvent(@PathVariable Long id, @RequestBody CampusEvent event) {
        return ApiResponse.ok("Campus event updated", campusService.updateEvent(id, event));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/events/{id}")
    public ApiResponse<Void> deleteEvent(@PathVariable Long id) {
        campusService.deleteEvent(id);
        return ApiResponse.ok("Campus event deleted", null);
    }

    @ResponseBody
    @GetMapping("/api/admin/events/{id}/registrations")
    public ApiResponse<List<EventRegistration>> getEventRegistrations(@PathVariable Long id) {
        return ApiResponse.ok("Event registrations loaded", campusService.getEventRegistrations(id));
    }

    // --- Resource Booking Management ---
    @ResponseBody
    @GetMapping("/api/admin/bookings")
    public ApiResponse<List<ResourceBooking>> listBookings() {
        return ApiResponse.ok("Bookings loaded", bookingService.getAllBookings());
    }

    @ResponseBody
    @PostMapping("/api/admin/bookings")
    public ApiResponse<ResourceBooking> createAdminBooking(@Valid @RequestBody BookingRequest req,
                                                           @AuthenticationPrincipal CustomUserDetails admin) {
        return ApiResponse.ok("Booking created", bookingService.createBooking(req, admin.getUserId(), admin.getFullName()));
    }

    @ResponseBody
    @PostMapping("/api/admin/bookings/{id}/approve")
    public ApiResponse<ResourceBooking> approveBooking(@PathVariable Long id,
                                                       @RequestBody(required = false) ApprovalDecisionRequest body,
                                                       @AuthenticationPrincipal CustomUserDetails admin) {
        String note = body != null ? body.getReason() : null;
        return ApiResponse.ok("Booking approved",
                bookingService.reviewBooking(id, true, admin.getUserId(), admin.getUsername(), note));
    }

    @ResponseBody
    @PostMapping("/api/admin/bookings/{id}/reject")
    public ApiResponse<ResourceBooking> rejectBooking(@PathVariable Long id,
                                                      @RequestBody(required = false) ApprovalDecisionRequest body,
                                                      @AuthenticationPrincipal CustomUserDetails admin) {
        String note = body != null ? body.getReason() : null;
        return ApiResponse.ok("Booking rejected",
                bookingService.reviewBooking(id, false, admin.getUserId(), admin.getUsername(), note));
    }

    @ResponseBody
    @PostMapping("/api/admin/bookings/{id}/cancel")
    public ApiResponse<ResourceBooking> cancelBooking(@PathVariable Long id,
                                                      @AuthenticationPrincipal CustomUserDetails admin) {
        return ApiResponse.ok("Booking cancelled", bookingService.cancelBooking(id, admin.getUserId(), true));
    }

    @ResponseBody
    @PostMapping("/api/admin/bookings/simulate-race")
    public ApiResponse<Map<String, Object>> simulateRace(@RequestBody(required = false) Map<String, Object> body,
                                                         @AuthenticationPrincipal CustomUserDetails admin) {
        String resourceType = body != null && body.get("resourceType") != null ? body.get("resourceType").toString() : "LABORATORY";
        Long resourceId = body != null && body.get("resourceId") != null ? Long.valueOf(body.get("resourceId").toString()) : 1L;
        java.time.LocalDate date = java.time.LocalDate.now().plusDays(14 + Math.abs((int) (System.currentTimeMillis() % 20)));
        java.time.LocalTime start = java.time.LocalTime.of(15, 0);
        java.time.LocalTime end = java.time.LocalTime.of(17, 0);

        List<java.util.concurrent.CompletableFuture<Map<String, Object>>> futures = new java.util.ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            final int threadNum = i;
            BookingRequest req = new BookingRequest();
            req.setResourceType(resourceType);
            req.setResourceId(resourceId);
            req.setBookingDate(date);
            req.setStartTime(start);
            req.setEndTime(end);
            req.setPurpose("Concurrency Race Simulation Thread-" + threadNum);

            long t0 = System.currentTimeMillis();
            futures.add(bookingService.submitBookingAsync(req, admin.getUserId(), admin.getFullName() + " (T" + threadNum + ")")
                    .handle((saved, ex) -> {
                        long ms = Math.max(1, System.currentTimeMillis() - t0);
                        Map<String, Object> trace = new java.util.LinkedHashMap<>();
                        trace.put("thread", "BookingPool-T" + threadNum);
                        trace.put("durationMs", ms);
                        if (ex == null && saved != null) {
                            trace.put("outcome", "BOOKED");
                            trace.put("bookingCode", saved.getBookingCode());
                            trace.put("detail", "Acquired ReentrantLock & committed SERIALIZABLE TX (" + saved.getBookingCode() + ").");
                        } else {
                            Throwable cause = ex != null && ex.getCause() != null ? ex.getCause() : ex;
                            trace.put("outcome", "CONFLICT_BLOCKED");
                            trace.put("detail", cause != null ? cause.getMessage() : "409 Conflict blocked by overlap guard.");
                        }
                        return trace;
                    }));
        }

        List<Map<String, Object>> traces = futures.stream().map(java.util.concurrent.CompletableFuture::join).toList();
        long bookedCount = traces.stream().filter(t -> "BOOKED".equals(t.get("outcome"))).count();
        long conflictCount = traces.size() - bookedCount;

        Map<String, Object> result = new java.util.LinkedHashMap<>();
        result.put("bookingDate", date.toString());
        result.put("startTime", start.toString());
        result.put("endTime", end.toString());
        result.put("bookedCount", bookedCount);
        result.put("conflictCount", conflictCount);
        result.put("traces", traces);
        return ApiResponse.ok("5-Thread concurrency race finished", result);
    }

    // --- Announcements ---
    @ResponseBody
    @GetMapping("/api/admin/announcements")
    public ApiResponse<List<Announcement>> listAnnouncements() {
        return ApiResponse.ok("Announcements loaded", campusService.getAllAnnouncements());
    }

    @ResponseBody
    @PostMapping("/api/admin/announcements")
    public ApiResponse<Announcement> createAnnouncement(@RequestBody Announcement a,
                                                      @AuthenticationPrincipal CustomUserDetails admin) {
        return ApiResponse.ok("Announcement posted", campusService.createAnnouncement(a, admin.getUserId()));
    }

    @ResponseBody
    @DeleteMapping("/api/admin/announcements/{id}")
    public ApiResponse<Void> deleteAnnouncement(@PathVariable Long id) {
        campusService.deleteAnnouncement(id);
        return ApiResponse.ok("Announcement removed", null);
    }

    // --- CSV Reports Export ---
    @GetMapping("/api/admin/reports/export/{type}")
    public ResponseEntity<byte[]> exportCsv(@PathVariable String type) throws IOException {
        String csv = csvExportService.exportReportCsv(type);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"gmu_" + type + "_report.csv\"")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(csv.getBytes(StandardCharsets.UTF_8));
    }
}
