package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Announcement;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

@Repository
public class AnnouncementRepository {

    private final JdbcTemplate jdbcTemplate;

    public AnnouncementRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Announcement> rowMapper = (rs, rowNum) -> {
        Announcement a = new Announcement();
        a.setId(rs.getLong("id"));
        a.setTitle(rs.getString("title"));
        a.setContent(rs.getString("content"));
        a.setAudience(rs.getString("audience"));
        a.setPriority(rs.getString("priority"));
        long pb = rs.getLong("posted_by");
        if (!rs.wasNull()) a.setPostedBy(pb);
        a.setPostedByName(rs.getString("posted_by_name"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) a.setCreatedAt(ts.toLocalDateTime());
        return a;
    };

    public List<Announcement> findAll() {
        return jdbcTemplate.query(
                "SELECT a.*, COALESCE(u.full_name, 'Campus Registrar') AS posted_by_name " +
                "FROM announcements a LEFT JOIN users u ON a.posted_by = u.id " +
                "ORDER BY a.created_at DESC",
                rowMapper);
    }

    public List<Announcement> findForStudents() {
        return jdbcTemplate.query(
                "SELECT a.*, COALESCE(u.full_name, 'Campus Registrar') AS posted_by_name " +
                "FROM announcements a LEFT JOIN users u ON a.posted_by = u.id " +
                "WHERE a.audience IN ('ALL', 'STUDENTS') ORDER BY a.created_at DESC",
                rowMapper);
    }

    public Long save(Announcement a) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO announcements (title, content, audience, priority, posted_by) VALUES (?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, a.getTitle());
            ps.setString(2, a.getContent());
            ps.setString(3, a.getAudience());
            ps.setString(4, a.getPriority());
            if (a.getPostedBy() != null) {
                ps.setLong(5, a.getPostedBy());
            } else {
                ps.setNull(5, java.sql.Types.BIGINT);
            }
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM announcements WHERE id = ?", id);
    }
}
