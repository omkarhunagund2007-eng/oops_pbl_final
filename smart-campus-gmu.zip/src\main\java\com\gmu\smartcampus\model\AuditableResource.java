package com.gmu.smartcampus.model;

import java.time.LocalDateTime;

/**
 * Abstraction interface for domain entities with lifecycle timestamps and audit identifiers.
 */
public interface AuditableResource {
    String getEntityType();
    String getAuditIdentifier();
    LocalDateTime getCreatedAt();
}
