# GM University — Smart Campus Integrated Management System
**Course:** UE25CS2303 — Object Oriented Programming with Java (Semester 3 PBL)  
**Institution:** GM University  
**Tech Stack:** Java 21 · Spring Boot 3.3.5 · Spring MVC · Spring Security · Pure JDBC (`JdbcTemplate`) · MySQL 8 · Thymeleaf · Bootstrap 5 · Chart.js · JUnit 5

---

## 1. Architecture Overview

The application follows a clean, layered enterprise Java architecture:
- `com.gmu.smartcampus.model` — OOP domain hierarchy (`BaseEntity`, `Person`, `CampusResource`, `Bookable`, `AuditableResource`, `Student`, `Faculty`, `Classroom`, `Laboratory`, `Equipment`, `Course`, `CampusEvent`, `ResourceBooking`, `Announcement`, `ApprovalHistory`).
- `com.gmu.smartcampus.dto` — Validated request payloads & generic wrappers (`ApiResponse<T>`, `PageResult<T>`).
- `com.gmu.smartcampus.repository` — Parameterized JDBC repositories (`JdbcTemplate`, `RowMapper`, `GeneratedKeyHolder`) without JPA/Hibernate.
- `com.gmu.smartcampus.service` — Business logic, BCrypt auth registration & approval, `ExecutorService` + `ReentrantLock` concurrent booking engine, Java Streams analytics, and CSV `BufferedWriter` export.
- `com.gmu.smartcampus.security` & `config` — Spring Security 6 RBAC, CSRF protection, custom login status failure handling (`PENDING`, `REJECTED`, `INVALID`), and idempotent data seeding.
- `com.gmu.smartcampus.exception` — Custom exception hierarchy and `@RestControllerAdvice` global handler.
- `com.gmu.smartcampus.controller` — Thymeleaf MVC & REST API controllers.

---

## 2. Initial MySQL 8 Setup on Windows (From Scratch)

If MySQL 8 is not yet installed on Windows:
1. Download **MySQL Installer for Windows** from https://dev.mysql.com/downloads/installer/ (choose **MySQL Community Server 8.0+**).
2. During installation, choose **Developer Default** or **Server Only**, set a root password, and keep the default port `3306` and Windows Service (`MySQL80`) enabled.
3. Open **Windows PowerShell** and verify MySQL is running:
   ```powershell
   Get-Service MySQL80
   ```
4. Initialize the `smart_campus_db` database and application user using the included SQL script:
   ```powershell
   mysql -u root -p < src\main\resources\db\mysql_setup.sql
   ```
   *(If `mysql` is not in PATH, use `"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"`.)*

---

## 3. Running on Windows (PowerShell + VS Code)

1. Ensure **Java 21 (JDK 21)** and **Apache Maven 3.8+** are installed:
   ```powershell
   java -version
   mvn -version
   ```
2. Extract the project ZIP and navigate into the folder:
   ```powershell
   cd smart-campus-gmu
   ```
3. Configure environment variables (optional if using defaults from `application.properties`):
   ```powershell
   Copy-Item .env.example .env
   $env:DB_USERNAME="smartcampus_user"
   $env:DB_PASSWORD="SmartCampus@2026"
   ```
4. Build and run all JUnit 5 automated tests:
   ```powershell
   mvn test
   ```
5. Start the Spring Boot server on port `8080`:
   ```powershell
   mvn spring-boot:run
   ```
   Or double-click `start-campus.ps1` / `start-campus.bat`.

6. Open your browser at:
   **http://localhost:8080**

---

## 4. Default Seeded Demo Accounts

| Role | Username / Student ID | Password | Status |
| :--- | :--- | :--- | :--- |
| Administrator | `admin` | `Admin@GMU2026` | APPROVED |
| Student (Approved) | `aarav.patel` / `GMU25CS001` | `Student@2026` | APPROVED |
| Student (Approved) | `diya.kulkarni` / `GMU25CS002` | `Student@2026` | APPROVED |
| Student (Pending) | `meera.nair` / `GMU25CS014` | `Student@2026` | PENDING (Blocked until approved) |
| Student (Rejected) | `test.rejected` / `GMU25CS099` | `Student@2026` | REJECTED (Blocked) |
