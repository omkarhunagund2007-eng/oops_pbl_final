package com.gmu.smartcampus.repository;

import com.gmu.smartcampus.model.Faculty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class FacultyRepository {

    private final JdbcTemplate jdbcTemplate;

    public FacultyRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Faculty> rowMapper = (rs, rowNum) -> {
        Faculty f = new Faculty();
        f.setId(rs.getLong("id"));
        f.setFacultyId(rs.getString("faculty_id"));
        f.setName(rs.getString("name"));
        f.setDepartmentId(rs.getLong("department_id"));
        f.setDepartmentCode(rs.getString("dept_code"));
        f.setDepartmentName(rs.getString("dept_name"));
        f.setDesignation(rs.getString("designation"));
        f.setEmail(rs.getString("email"));
        f.setPhone(rs.getString("phone"));
        f.setSpecialization(rs.getString("specialization"));
        Date jd = rs.getDate("joining_date");
        if (jd != null) f.setJoiningDate(jd.toLocalDate());
        f.setActive(rs.getBoolean("active"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) f.setCreatedAt(ts.toLocalDateTime());
        return f;
    };

    private static final String BASE_SELECT =
            "SELECT f.*, d.code AS dept_code, d.name AS dept_name " +
            "FROM faculty f JOIN departments d ON f.department_id = d.id ";

    public List<Faculty> findAll() {
        return jdbcTemplate.query(BASE_SELECT + "ORDER BY f.faculty_id ASC", rowMapper);
    }

    public List<Faculty> findAllActive() {
        return jdbcTemplate.query(BASE_SELECT + "WHERE f.active = TRUE ORDER BY f.name ASC", rowMapper);
    }

    public Optional<Faculty> findById(Long id) {
        return jdbcTemplate.query(BASE_SELECT + "WHERE f.id = ?", rowMapper, id).stream().findFirst();
    }

    public boolean existsByFacultyId(String facultyId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM faculty WHERE LOWER(faculty_id) = LOWER(?)", Integer.class, facultyId);
        return count != null && count > 0;
    }

    public Long save(Faculty faculty) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"id"});
            ps.setString(1, faculty.getFacultyId());
            ps.setString(2, faculty.getName());
            ps.setLong(3, faculty.getDepartmentId());
            ps.setString(4, faculty.getDesignation());
            ps.setString(5, faculty.getEmail());
            ps.setString(6, faculty.getPhone());
            ps.setString(7, faculty.getSpecialization());
            ps.setDate(8, Date.valueOf(faculty.getJoiningDate()));
            ps.setBoolean(9, faculty.isActive());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public int update(Faculty faculty) {
        return jdbcTemplate.update(
                "UPDATE faculty SET name = ?, department_id = ?, designation = ?, email = ?, phone = ?, specialization = ?, joining_date = ?, active = ? WHERE id = ?",
                faculty.getName(), faculty.getDepartmentId(), faculty.getDesignation(),
                faculty.getEmail(), faculty.getPhone(), faculty.getSpecialization(),
                Date.valueOf(faculty.getJoiningDate()), faculty.isActive(), faculty.getId());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM faculty WHERE id = ?", id);
    }
}
