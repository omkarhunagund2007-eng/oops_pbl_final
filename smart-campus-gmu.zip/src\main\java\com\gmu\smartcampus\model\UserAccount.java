package com.gmu.smartcampus.model;

import java.time.LocalDateTime;

public class UserAccount extends BaseEntity {
    private String username;
    private String passwordHash;
    private String fullName;
    private String email;
    private String role; // ADMIN, STUDENT
    private String accountStatus; // PENDING, APPROVED, REJECTED, INACTIVE
    private String themePreference = "light";
    private LocalDateTime updatedAt;

    @Override
    public String getEntityType() {
        return "USER_ACCOUNT";
    }

    @Override
    public String getAuditIdentifier() {
        return username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getThemePreference() {
        return themePreference;
    }

    public void setThemePreference(String themePreference) {
        this.themePreference = themePreference;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
