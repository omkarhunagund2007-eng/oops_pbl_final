-- =============================================================================
-- GM University Smart Campus Integrated Management System - Seed Data
-- Idempotent seed script compatible with MySQL 8 and H2 MySQL mode
-- Note: User accounts with BCrypt hashes are initialized cleanly by DataInitializer
-- =============================================================================

INSERT INTO departments (code, name, hod_name, building)
SELECT 'CSE', 'Computer Science and Engineering', 'Dr. Raghavendra Kulkarni', 'Turing Block'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE code = 'CSE');

INSERT INTO departments (code, name, hod_name, building)
SELECT 'AIML', 'Artificial Intelligence and Machine Learning', 'Dr. Nandini Bhat', 'Turing Block'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE code = 'AIML');

INSERT INTO departments (code, name, hod_name, building)
SELECT 'ECE', 'Electronics and Communication Engineering', 'Dr. Suresh Hebbar', 'Maxwell Block'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE code = 'ECE');

INSERT INTO departments (code, name, hod_name, building)
SELECT 'ME', 'Mechanical Engineering', 'Dr. Prakash Gowda', 'Visvesvaraya Block'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE code = 'ME');

INSERT INTO departments (code, name, hod_name, building)
SELECT 'CIV', 'Civil Engineering', 'Dr. Kavitha Rao', 'Visvesvaraya Block'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE code = 'CIV');

-- Faculty Seed
INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active)
SELECT 'GMU-FAC-001', 'Dr. Raghavendra Kulkarni', (SELECT id FROM departments WHERE code='CSE'), 'Professor & HoD', 'raghavendra.k@gmu.edu.in', '9845011001', 'Distributed Systems & Java Architecture', '2016-07-15', TRUE
WHERE NOT EXISTS (SELECT 1 FROM faculty WHERE faculty_id = 'GMU-FAC-001');

INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active)
SELECT 'GMU-FAC-002', 'Prof. Ananya Sharma', (SELECT id FROM departments WHERE code='CSE'), 'Associate Professor', 'ananya.sharma@gmu.edu.in', '9845011002', 'Object Oriented Programming & Cloud Computing', '2019-08-01', TRUE
WHERE NOT EXISTS (SELECT 1 FROM faculty WHERE faculty_id = 'GMU-FAC-002');

INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active)
SELECT 'GMU-FAC-003', 'Dr. Nandini Bhat', (SELECT id FROM departments WHERE code='AIML'), 'Professor & HoD', 'nandini.bhat@gmu.edu.in', '9845011003', 'Deep Learning & Computer Vision', '2017-06-10', TRUE
WHERE NOT EXISTS (SELECT 1 FROM faculty WHERE faculty_id = 'GMU-FAC-003');

INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active)
SELECT 'GMU-FAC-004', 'Dr. Suresh Hebbar', (SELECT id FROM departments WHERE code='ECE'), 'Professor & HoD', 'suresh.hebbar@gmu.edu.in', '9845011004', 'VLSI Design & Embedded IoT', '2015-09-01', TRUE
WHERE NOT EXISTS (SELECT 1 FROM faculty WHERE faculty_id = 'GMU-FAC-004');

INSERT INTO faculty (faculty_id, name, department_id, designation, email, phone, specialization, joining_date, active)
SELECT 'GMU-FAC-005', 'Prof. Karthik Hegde', (SELECT id FROM departments WHERE code='ME'), 'Assistant Professor', 'karthik.hegde@gmu.edu.in', '9845011005', 'CAD/CAM & Robotics', '2021-01-18', TRUE
WHERE NOT EXISTS (SELECT 1 FROM faculty WHERE faculty_id = 'GMU-FAC-005');

-- Courses Seed (Including UE25CS2303)
INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active)
SELECT 'UE25CS2303', 'Object Oriented Programming with Java', (SELECT id FROM departments WHERE code='CSE'), 3, 4, 'Comprehensive Java OOP covering encapsulation, inheritance, polymorphism, exceptions, multithreading, collections, streams, file handling, and JDBC.', TRUE
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE course_code = 'UE25CS2303');

INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active)
SELECT 'UE25CS2301', 'Data Structures and Algorithms', (SELECT id FROM departments WHERE code='CSE'), 3, 4, 'Trees, graphs, hashing, balanced search trees, and algorithmic complexity analysis.', TRUE
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE course_code = 'UE25CS2301');

INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active)
SELECT 'UE25CS2304', 'Database Management Systems', (SELECT id FROM departments WHERE code='CSE'), 3, 4, 'Relational algebra, normalization, SQL, transactions, concurrency control, and indexing.', TRUE
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE course_code = 'UE25CS2304');

INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active)
SELECT 'UE25AI2302', 'Foundations of Machine Learning', (SELECT id FROM departments WHERE code='AIML'), 3, 4, 'Supervised and unsupervised statistical learning methods with Python and matrix calculus.', TRUE
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE course_code = 'UE25AI2302');

INSERT INTO courses (course_code, course_name, department_id, semester, credits, description, active)
SELECT 'UE25EC2301', 'Digital Signal Processing', (SELECT id FROM departments WHERE code='ECE'), 3, 3, 'Discrete-time signals, FFT, FIR/IIR filter design, and embedded DSP architectures.', TRUE
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE course_code = 'UE25EC2301');

-- Faculty-Course Assignments
INSERT INTO faculty_courses (faculty_id, course_id, academic_term)
SELECT (SELECT id FROM faculty WHERE faculty_id='GMU-FAC-002'), (SELECT id FROM courses WHERE course_code='UE25CS2303'), '2026-ODD'
WHERE NOT EXISTS (
    SELECT 1 FROM faculty_courses
    WHERE faculty_id=(SELECT id FROM faculty WHERE faculty_id='GMU-FAC-002')
      AND course_id=(SELECT id FROM courses WHERE course_code='UE25CS2303')
);

INSERT INTO faculty_courses (faculty_id, course_id, academic_term)
SELECT (SELECT id FROM faculty WHERE faculty_id='GMU-FAC-001'), (SELECT id FROM courses WHERE course_code='UE25CS2304'), '2026-ODD'
WHERE NOT EXISTS (
    SELECT 1 FROM faculty_courses
    WHERE faculty_id=(SELECT id FROM faculty WHERE faculty_id='GMU-FAC-001')
      AND course_id=(SELECT id FROM courses WHERE course_code='UE25CS2304')
);

INSERT INTO faculty_courses (faculty_id, course_id, academic_term)
SELECT (SELECT id FROM faculty WHERE faculty_id='GMU-FAC-003'), (SELECT id FROM courses WHERE course_code='UE25AI2302'), '2026-ODD'
WHERE NOT EXISTS (
    SELECT 1 FROM faculty_courses
    WHERE faculty_id=(SELECT id FROM faculty WHERE faculty_id='GMU-FAC-003')
      AND course_id=(SELECT id FROM courses WHERE course_code='UE25AI2302')
);

-- Classrooms Seed
INSERT INTO classrooms (room_id, building, room_number, capacity, availability_status, equipment_summary)
SELECT 'CR-TB-301', 'Turing Block', '301', 72, 'AVAILABLE', '4K Laser Projector, Smart Podium, Dual Whiteboards, Acoustic Audio'
WHERE NOT EXISTS (SELECT 1 FROM classrooms WHERE room_id = 'CR-TB-301');

INSERT INTO classrooms (room_id, building, room_number, capacity, availability_status, equipment_summary)
SELECT 'CR-TB-302', 'Turing Block', '302', 64, 'AVAILABLE', 'Interactive LED Board, Wireless Mic, Lecture Capture Camera'
WHERE NOT EXISTS (SELECT 1 FROM classrooms WHERE room_id = 'CR-TB-302');

INSERT INTO classrooms (room_id, building, room_number, capacity, availability_status, equipment_summary)
SELECT 'CR-MB-104', 'Maxwell Block', '104', 120, 'AVAILABLE', 'Tiered Auditorium Seating, Dual Projectors, PA System'
WHERE NOT EXISTS (SELECT 1 FROM classrooms WHERE room_id = 'CR-MB-104');

INSERT INTO classrooms (room_id, building, room_number, capacity, availability_status, equipment_summary)
SELECT 'CR-VB-205', 'Visvesvaraya Block', '205', 60, 'MAINTENANCE', 'Standard Projector, Drafting Tables'
WHERE NOT EXISTS (SELECT 1 FROM classrooms WHERE room_id = 'CR-VB-205');

-- Laboratories Seed
INSERT INTO laboratories (lab_id, name, location, capacity, lab_type, equipment_summary, availability_status)
SELECT 'LAB-JAVA-01', 'OOPS & Enterprise Java Lab', 'Turing Block, Floor 2', 40, 'Software Engineering', '40x i7 Workstations, Dual Monitors, Local Git & MySQL Server', 'AVAILABLE'
WHERE NOT EXISTS (SELECT 1 FROM laboratories WHERE lab_id = 'LAB-JAVA-01');

INSERT INTO laboratories (lab_id, name, location, capacity, lab_type, equipment_summary, availability_status)
SELECT 'LAB-AIML-02', 'NVIDIA Deep Learning Studio', 'Turing Block, Floor 4', 32, 'AI & Data Science', '16x RTX 4090 Nodes, CUDA Cluster, Interactive Wall', 'AVAILABLE'
WHERE NOT EXISTS (SELECT 1 FROM laboratories WHERE lab_id = 'LAB-AIML-02');

INSERT INTO laboratories (lab_id, name, location, capacity, lab_type, equipment_summary, availability_status)
SELECT 'LAB-IOT-03', 'Embedded Systems & IoT Lab', 'Maxwell Block, Floor 1', 30, 'Hardware & IoT', 'Oscilloscopes, FPGA Kits, Arduino/ESP32 Workbenches', 'AVAILABLE'
WHERE NOT EXISTS (SELECT 1 FROM laboratories WHERE lab_id = 'LAB-IOT-03');

-- Equipment Seed
INSERT INTO equipment (equipment_id, name, category, quantity, available_quantity, item_condition, location, purchase_date)
SELECT 'EQ-PROJ-01', 'Epson EB-L630U Laser Projector', 'Audio-Visual', 8, 6, 'EXCELLENT', 'Central AV Store', '2024-02-14'
WHERE NOT EXISTS (SELECT 1 FROM equipment WHERE equipment_id = 'EQ-PROJ-01');

INSERT INTO equipment (equipment_id, name, category, quantity, available_quantity, item_condition, location, purchase_date)
SELECT 'EQ-ROBO-02', 'ROS2 Autonomous Rover Kit', 'Robotics', 12, 10, 'GOOD', 'Mechatronics Bay', '2024-09-20'
WHERE NOT EXISTS (SELECT 1 FROM equipment WHERE equipment_id = 'EQ-ROBO-02');

INSERT INTO equipment (equipment_id, name, category, quantity, available_quantity, item_condition, location, purchase_date)
SELECT 'EQ-OSC-03', 'Tektronix Digital Oscilloscope 100MHz', 'Electronics', 15, 14, 'EXCELLENT', 'Maxwell Lab Store', '2023-11-05'
WHERE NOT EXISTS (SELECT 1 FROM equipment WHERE equipment_id = 'EQ-OSC-03');

INSERT INTO equipment (equipment_id, name, category, quantity, available_quantity, item_condition, location, purchase_date)
SELECT 'EQ-AUD-04', 'Sennheiser Wireless Collar Mic Set', 'Audio-Visual', 10, 8, 'GOOD', 'Auditorium Control Room', '2024-06-11'
WHERE NOT EXISTS (SELECT 1 FROM equipment WHERE equipment_id = 'EQ-AUD-04');
