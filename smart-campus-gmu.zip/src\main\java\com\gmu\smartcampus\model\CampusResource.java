package com.gmu.smartcampus.model;

/**
 * Abstract superclass for bookable physical campus assets (Classroom, Laboratory, Equipment).
 * Demonstrates inheritance, abstraction, method overriding, and compile-time + runtime polymorphism.
 */
public abstract class CampusResource extends BaseEntity implements Bookable {

    protected String availabilityStatus = "AVAILABLE";

    public String getAvailabilityStatus() {
        return availabilityStatus;
    }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

    @Override
    public boolean isCurrentlyBookable() {
        return "AVAILABLE".equalsIgnoreCase(availabilityStatus);
    }

    /**
     * Compile-time polymorphism (method overloading) for resource locking key generation.
     */
    public String buildLockKey() {
        return getResourceType() + ":" + getId();
    }

    public String buildLockKey(String dateIso) {
        return getResourceType() + ":" + getId() + ":" + dateIso;
    }
}
