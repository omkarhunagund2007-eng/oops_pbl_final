package com.gmu.smartcampus.model;

import java.time.LocalDate;

/**
 * Concrete Faculty entity extending Person.
 */
public class Faculty extends Person {

    private String facultyId;
    private String designation;
    private String email;
    private String specialization;
    private LocalDate joiningDate;
    private boolean active = true;

    public Faculty() {
        super();
    }

    @Override
    public String getEntityType() {
        return "FACULTY";
    }

    @Override
    public String getAuditIdentifier() {
        return facultyId;
    }

    @Override
    public String getAcademicSummary() {
        return String.format("%s · %s · %s", name, designation, specialization);
    }

    public String getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(String facultyId) {
        this.facultyId = facultyId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public LocalDate getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(LocalDate joiningDate) {
        this.joiningDate = joiningDate;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
