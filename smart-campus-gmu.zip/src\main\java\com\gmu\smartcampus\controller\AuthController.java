package com.gmu.smartcampus.controller;

import com.gmu.smartcampus.dto.ApiResponse;
import com.gmu.smartcampus.dto.RegistrationRequest;
import com.gmu.smartcampus.model.Department;
import com.gmu.smartcampus.model.Student;
import com.gmu.smartcampus.security.CustomUserDetails;
import com.gmu.smartcampus.service.AuthRegistrationService;
import com.gmu.smartcampus.service.CampusManagementService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class AuthController {

    private final AuthRegistrationService registrationService;
    private final CampusManagementService campusService;

    public AuthController(AuthRegistrationService registrationService,
                          CampusManagementService campusService) {
        this.registrationService = registrationService;
        this.campusService = campusService;
    }

    @GetMapping("/")
    public String root(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            boolean isAdmin = authentication.getAuthorities().stream()
                    .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
            return isAdmin ? "redirect:/admin/dashboard" : "redirect:/student/dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage(@RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "status", required = false) String status,
                            @RequestParam(value = "logout", required = false) String logout,
                            Model model) {
        model.addAttribute("departments", campusService.getAllDepartments());
        model.addAttribute("errorMsg", error);
        model.addAttribute("errorStatus", status);
        model.addAttribute("logoutSuccess", logout != null);
        return "login";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "access-denied";
    }

    @ResponseBody
    @GetMapping("/api/public/departments")
    public ApiResponse<List<Department>> listDepartments() {
        return ApiResponse.ok("Departments fetched", campusService.getAllDepartments());
    }

    @ResponseBody
    @PostMapping("/api/auth/register")
    public ResponseEntity<ApiResponse<Student>> registerStudent(@Valid @RequestBody RegistrationRequest request) {
        Student created = registrationService.registerStudent(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok(
                        "Registration submitted successfully! Your account status is PENDING administrator approval.",
                        created));
    }

    @ResponseBody
    @PostMapping("/api/user/theme")
    public ApiResponse<Map<String, String>> updateTheme(@AuthenticationPrincipal CustomUserDetails principal,
                                                        @RequestBody Map<String, String> payload) {
        String theme = payload.getOrDefault("theme", "light");
        if (principal != null) {
            registrationService.updateThemePreference(principal.getUserId(), theme);
        }
        return ApiResponse.ok("Theme preference saved", Map.of("theme", theme));
    }
}
